local egg = Instance.new("Part", script)
egg:SetNetworkOwner(owner)
egg.Size = Vector3.new(2,2,2)
egg.Shape = 'Ball'
egg.Locked = true
egg.CFrame = owner.Character.PrimaryPart.CFrame * CFrame.new(0,100,0)
egg.Material = 'Ice'
egg.Name = 'Head'
egg.Transparency = 0
egg.BrickColor = BrickColor.new("Deep orange")
egg.Massless = true
egg.CanCollide = true

local name = Instance.new("BillboardGui", egg)
name.Size = UDim2.fromScale(2,4)
name.StudsOffset = Vector3.new(0,5,0)
name.MaxDistance = 200
local tb = Instance.new("TextBox", name)
tb.Size = UDim2.new(1,0,1,0)
tb.BackgroundTransparency = 1
tb.TextSize = 15
tb.TextYAlignment = 'Top'
tb.TextColor = BrickColor.White()
tb.Text = owner.DisplayName..[[

]]..'@'..owner.Name

owner.Character.Parent = owner

local chatsound = Instance.new("Sound", egg)
chatsound.SoundId = 'rbxasset://sounds/bass.wav'
chatsound.Pitch = 1
chatsound.Volume = 10

Instance.new("Decal", egg).Texture = 'rbxasset://textures/face.png'

owner.Chatted:Connect(function(msg)
msg = game:GetService("Chat"):FilterStringForBroadcast(msg, owner)
local num = string.len(msg)
for i = 1,num do
chatsound.Pitch = math.clamp(math.random(-2,4),2,4)
chatsound:Play()
tb.Text = owner.DisplayName..[[

]]..'@'..owner.Name..[[

]]..string.sub(msg,0,i)
wait(.15)
end
end)

local Val = Instance.new("ObjectValue", owner.PlayerGui)
Val.Value = egg
Val.Name = 'SUSSY'

owner.Character:SetPrimaryPartCFrame(CFrame.new(0,40,0))

NLS([[
local egg = owner.PlayerGui.SUSSY.Value
humanoid = owner.Character.Humanoid
velocity = Vector3.new(0,0,0)

egg.CanCollide = true

workspace.CurrentCamera.CameraSubject = egg

game:GetService("RunService").RenderStepped:Connect(function()
velocity = velocity:Lerp(humanoid.MoveDirection*30, .1)

egg.Velocity = Vector3.new(velocity.X,egg.Velocity.Y,velocity.Z)

end)

]], owner.PlayerGui)