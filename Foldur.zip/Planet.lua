local planet = Instance.new("Part", script)
planet.CanCollide = false
planet.Shape = 'Ball'
planet.Material = 'Slate'
planet.Locked = true
planet.Name = 'PLANET'
planet:SetNetworkOwner(owner)

local shell = Instance.new("Part", script)
shell.CanCollide = false
shell.Shape = 'Ball'
shell.Material = 'Neon'
shell.Locked = true
shell.Transparency = .75
shell.Name = 'SHELL'
shell:SetNetworkOwner(owner)

weld = Instance.new("Weld", shell)
weld.Part1 = shell
weld.Part0 = planet

local audio = Instance.new("Sound", owner.Character.Head)
audio.MaxDistance = 100
audio.Looped = true
audio.SoundId = 'rbxassetid://7071427516'
audio.Pitch = 1
audio.Volume = .25
audio:Play()

local Loud = Instance.new("Part", script)
Loud.CanCollide = false
Loud.Transparency = 1
Loud.Massless = true
Loud.Size = Vector3.new(5,5,5)
Loud:SetNetworkOwner(owner)
Instance.new("ObjectValue", owner.Character).Value = Loud

Amplifyer = 1

effect = false
--lerpcolor = BrickColor.new("Magenta").Color

game:GetService("RunService").Heartbeat:Connect(function()
lerpcolor = Color3.fromHSV(tick()/5%1/1,1,1)
loudness = Loud.Position.X

siz = math.clamp(loudness/300 * Amplifyer+1,.25,5 * Amplifyer)

planet.Size = planet.Size:Lerp(Vector3.new(siz,siz,siz), .25)
shell.Size = planet.Size + Vector3.new(.25,.25,.25)
shell.Color = BrickColor.new("Institutional white").Color:Lerp(lerpcolor, siz / (5 * Amplifyer))

effect = not effect

if effect == true then
local E = Instance.new("BoxHandleAdornment", script)
E.Size = Vector3.new(.5,.5,.5)
if siz > 4 then
E.Size = Vector3.new(1.5,1.5,1.5)
end
E.Adornee = shell
E.Color3 = shell.Color
game:GetService("TweenService"):Create(E, TweenInfo.new(1), {Size = Vector3.new(0,0,0), CFrame = CFrame.new(math.random(-5,5),math.random(-5,5),math.random(-5,5)) * CFrame.Angles(math.random(-360,360),math.random(-360,360),math.random(-360,360))}):Play()
game:GetService("Debris"):AddItem(E, 1)
end

end)


local flange = Instance.new("FlangeSoundEffect", audio)
flange.Rate = .5
flange.Depth = 5
flange.Enabled = false

owner.Chatted:Connect(function(msg)
local message = string.split(msg, ' ')
if string.lower(message[1]) =='-music' then
audio:Stop()
audio.SoundId = 'rbxassetid://'..message[2]
audio:Play()
elseif string.lower(message[1]) =='-volume' then
audio.Volume = message[2]
elseif string.lower(message[1]) =='-pitch' then
audio.Pitch = message[2]
elseif string.lower(message[1]) =='-debug' then
Loud.Transparency = .5
elseif string.lower(message[1]) =='-bug' then
Loud.Transparency = 1
elseif string.lower(message[1]) =='-flange' then
flange.Enabled = true
elseif string.lower(message[1]) =='-unflange' then
flange.Enabled = false
elseif string.lower(message[1]) =='-amplify' then
Amplifyer = message[2]
end
end) 


NLS([[local target = owner.Character.Value.Value
local sound = owner.Character.Head.Sound
local planet = target.Parent.PLANET
sine = 1

local force1 = Instance.new("BodyPosition", target)
force1.MaxForce = Vector3.new(math.huge,math.huge,math.huge)
force1.P = 150000
force1.D = 1000

local force2 = Instance.new("BodyGyro", target)
force2.MaxTorque = Vector3.new(math.huge,math.huge,math.huge)
force2.P = 150000
force2.D = 1000

local planp = Instance.new("BodyPosition", planet)
planp.MaxForce = Vector3.new(math.huge,math.huge,math.huge)
planp.P = 150000
planp.D = 1000

local plang = Instance.new("BodyGyro", planet)
plang.MaxTorque = Vector3.new(math.huge,math.huge,math.huge)
plang.P = 150000
plang.D = 1000 

game:GetService("RunService").RenderStepped:Connect(function()

sine = sine + .5

force1.Position = Vector3.new(sound.PlaybackLoudness,0,0)
force2.CFrame = CFrame.new(0,0,0)

planp.Position = CFrame.new(owner.Character.HumanoidRootPart.CFrame * CFrame.new(0,7,0).Position).Position
plang.CFrame = CFrame.Angles(math.rad(sine),math.rad(sine),math.rad(sine))
end)

]], owner.Character)