local mouth = Instance.new("Part", owner.Character.Head)
mouth.Name = 'Mouth'
Instance.new("SpecialMesh", mouth).MeshType = 'Sphere'

mouth.CanCollide = false
mouth.Massless = true
mouth.Size = Vector3.new(.75,.2,.2)
mouth.BrickColor = BrickColor.new("Really black")

local weld = Instance.new("Weld", mouth)
weld.Part1 = owner.Character.Head
weld.Part0 = mouth
weld.C0 = CFrame.new(0,.25,.6)


local eye1 = Instance.new("Part", owner.Character.Head)
eye1.Size = Vector3.new(.1,.3,.2)
eye1.CanCollide = false
eye1.Massless = false
eye1.Material = 'SmoothPlastic'
eye1.BrickColor = BrickColor.new("Really black")

Instance.new("SpecialMesh", eye1).MeshType = 'Sphere'

local weld1 = Instance.new("Weld", eye1)
weld1.Part1 = eye1
weld1.Part0 = owner.Character.Head
weld1.C0 = CFrame.new(.2,.15,-.55)

local eye2 = Instance.new("Part", owner.Character.Head)
eye2.Size = Vector3.new(.1,.3,.2)
eye2.CanCollide = false
eye2.Massless = false
eye2.Material = 'SmoothPlastic'
eye2.BrickColor = BrickColor.new("Really black")

Instance.new("SpecialMesh", eye2).MeshType = 'Sphere'

local weld2 = Instance.new("Weld", eye2)
weld2.Part1 = eye2
weld2.Part0 = owner.Character.Head
weld2.C0 = CFrame.new(-.2,.15,-.55)

owner.Character.Head:FindFirstChildWhichIsA("Decal"):Destroy()


local audio = Instance.new("Sound", owner.Character.Head)
audio.MaxDistance = 100
audio.Looped = true
audio.SoundId = 'rbxassetid://6702918183'
audio.Pitch = 1
audio.Volume = 5
audio:Play()

local Loud = Instance.new("Part", script)
Loud.CanCollide = false
Loud.Transparency = 1
Loud.Massless = true
Loud.Size = Vector3.new(5,5,5)
Loud:SetNetworkOwner(owner)
Instance.new("ObjectValue", owner.Character).Value = Loud

NLS([[local target = owner.Character.Value.Value
local sound = owner.Character.Head.Sound

local force1 = Instance.new("BodyPosition", target)
force1.MaxForce = Vector3.new(math.huge,math.huge,math.huge)
force1.P = 150000
force1.D = 1000

local force2 = Instance.new("BodyGyro", target)
force2.MaxTorque = Vector3.new(math.huge,math.huge,math.huge)
force2.P = 150000
force2.D = 1000

game:GetService("RunService").RenderStepped:Connect(function()
force1.Position = Vector3.new(owner.Character.Head.Position.X,sound.PlaybackLoudness,owner.Character.Head.Position.Z)
force2.CFrame = CFrame.new(0,0,0)
end)

]], owner.Character)

local neck = owner.Character.Torso.Neck

fakeneck = Instance.new("Weld", neck.Parent)
fakeneck.Part1 = neck.Part1
fakeneck.Part0 = neck.Part0
fakeneck.C0 = neck.C0
fakeneck.C1 = neck.C1

neck = fakeneck

local neckc0 = neck.C0

game:GetService("RunService").Heartbeat:Connect(function()
mouth.Size = Vector3.new(.5,math.clamp(Loud.Position.Y/650,.15,1.5),.2)
neck.C0 = neckc0 * CFrame.Angles(-math.rad(math.clamp(Loud.Position.Y / 650,0,30))*20,0,0)
if math.sin(tick()) > .99 then
eye1.Size = Vector3.new(.1,.05,.2)
eye2.Size = Vector3.new(.1,.05,.2)
else
eye1.Size = eye1.Size:Lerp(Vector3.new(.1,.3,.2), .1)
eye2.Size = eye2.Size:Lerp(Vector3.new(.1,.3,.2), .1)
end
end)

owner.Chatted:Connect(function(msg)
local message = string.split(msg, ' ')
if string.lower(message[1]) =='-music' then
audio:Stop()
audio.SoundId = 'rbxassetid://'..message[2]
audio:Play()
elseif string.lower(message[1]) =='-volume' then
audio.Volume = message[2]
elseif string.lower(message[1]) =='-pitch' then
audio.Pitch = message[2]
elseif string.lower(message[1]) =='-debug' then
Loud.Transparency = .5
elseif string.lower(message[1]) =='-bug' then
Loud.Transparency = 1
end
end)