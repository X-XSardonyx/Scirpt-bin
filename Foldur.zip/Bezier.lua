function Bezier(Start, End, Control, resolution)
parts = {}
for i = 1,resolution do

local curve1 = Start:Lerp(Control, i/resolution)
local curve2 = Control:Lerp(End, i/resolution)
local lerp = curve1:Lerp(curve2, i/resolution)
local look = curve1:Lerp(curve2, i+1/resolution)

local part=Instance.new("SpawnLocation", script)
part.Size = Vector3.new(1,1,1)
part.Enabled = false
part.Anchored = true

part.CFrame = CFrame.new(lerp, look) * CFrame.new(0,0,0)

table.insert(parts, line)
task.wait()
end
return parts
end

testpos = Vector3.new(0,50,0):Lerp(owner.Character.Torso.Position, .5)
testpos = testpos + Vector3.new(math.random(-30,30),0,math.random(-30,30))

local parts = Bezier(Vector3.new(0,50,0), owner.Character.Torso.Position , testpos, 100)