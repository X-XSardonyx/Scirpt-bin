for i,v in pairs(owner.Character:GetDescendants()) do
if v:IsA("Motor6D") then
local weld = Instance.new("Weld", v.Parent)
weld.Part1 = v.Part1
weld.Part0 = v.Part0
weld.C0 = v.C0
weld.C1 = v.C1
weld.Name = v.Name
v:Destroy()
end
end

--Anim Defaults
AnimDefaults = {
Head = owner.Character.Torso.Neck.C0,
Torso = owner.Character.HumanoidRootPart.RootJoint.C0,
Larm = owner.Character.Torso["Left Shoulder"].C0,
Rarm = owner.Character.Torso["Right Shoulder"].C0,
Lleg = owner.Character.Torso["Left Hip"].C0,
Rleg = owner.Character.Torso["Right Hip"].C0
}
--Setting Joints
Head = owner.Character.Torso.Neck
Torso = owner.Character.HumanoidRootPart.RootJoint
Larm = owner.Character.Torso["Left Shoulder"]
Rarm = owner.Character.Torso["Right Shoulder"]
Lleg = owner.Character.Torso["Left Hip"]
Rleg = owner.Character.Torso["Right Hip"]

while true do   
task.wait()
 if owner.Character.HumanoidRootPart.Velocity.Magnitude > 1 then
 Rleg.C0 = AnimDefaults.Rleg * CFrame.Angles(0,0,math.rad(math.sin(tick()*5)*45))
 Lleg.C0 = AnimDefaults.Lleg * CFrame.Angles(0,0,math.rad(math.sin(tick()*5)*45))
 Rarm.C0 = AnimDefaults.Rarm * CFrame.Angles(0,0,-math.rad(math.sin(tick()*5)*45))
 Larm.C0 = AnimDefaults.Larm * CFrame.Angles(0,0,-math.rad(math.sin(tick()*5)*45))
 else
 Rleg.C0 = AnimDefaults.Rleg
 Lleg.C0 = AnimDefaults.Lleg
 Larm.C0 = AnimDefaults.Larm
 Rarm.C0 = AnimDefaults.Rarm
 
 end
end