local larmoffset = CFrame.new(-1,-1,-1)
local rarmoffset = CFrame.new(1,-1,-1)
local model = Instance.new("Model", script)

local head = Instance.new("Part", model)
head.Anchored = true
head.Locked = true
head.Size = Vector3.new(1,.5,.5)
head.Color = BrickColor.new("Insitutional white").Color
head.CanCollide = false

Instance.new("Decal", head).Texture = 'rbxassetid://144080495'

local larm = Instance.new("Part", model)
larm.Size = Vector3.new(.5,.5,1)
larm.Anchored = true
larm.Material = 'SmoothPlastic'
larm.CanCollide = false
larm.Color = BrickColor.new("Insitutional white").Color

local rarm = Instance.new("Part", model)
rarm.Size = Vector3.new(.5,.5,1)
rarm.Anchored = true
rarm.Material = 'SmoothPlastic'
rarm.CanCollide = false
rarm.Color = BrickColor.new("Insitutional white").Color

local HRP = Instance.new("Part", model)
HRP.CFrame = owner.Character.PrimaryPart.CFrame
HRP.Size = Vector3.new(1,1,1)
HRP.Transparency = 1
HRP.Name = 'HumanoidRootPart'
HRP.Locked = true

Instance.new("SpecialMesh", head).Scale = Vector3.new(1.25,1.25,1.25)

owner.Character = model

Instance.new("Humanoid", model)

local rem = Instance.new("RemoteEvent", owner.Character)
rem.Name = 'Mouse/Cam'

NLS([[

local cam = workspace.CurrentCamera
local mouse = owner:GetMouse()

local rem = owner.Character["Mouse/Cam"]

mouse.TargetFilter = workspace

game:GetService("RunService").RenderStepped:Connect(function()
cam.CFrame = owner.Character.HumanoidRootPart.CFrame:Lerp(CFrame.new(owner.Character.HumanoidRootPart.CFrame * CFrame.new(0,12,0).Position, mouse.Hit.Position),.5)
end)


while wait(1/30) do
rem:FireServer(mouse.Hit.Position, cam.CFrame)
end

]], owner.Character)



local Sword = Instance.new("Tool", owner.Backpack)
Sword.Name = 'Lazer'
Sword.RequiresHandle = false
Sword.CanBeDropped = false

local SWORDPIECE = Instance.new("Part", Sword)
SWORDPIECE.Anchored = true
SWORDPIECE.Size = Vector3.new(.1,.1,1000)
SWORDPIECE.Material = 'Neon'
SWORDPIECE.BrickColor = BrickColor.new("Really red")
SWORDPIECE.CanCollide = false
SWORDPIECE.Touched:Connect(function(part)
if part.Parent ~= owner.Character then
part:Destroy()
end
end)


rem.OnServerEvent:Connect(function(plr, pos, camcframe)
head.CFrame = camcframe
larm.CFrame = CFrame.new(camcframe * larmoffset.Position, pos)
rarm.CFrame = CFrame.new(camcframe * rarmoffset.Position, pos)

SWORDPIECE.CFrame = rarm.CFrame * CFrame.new(0,0,-500.5)

end)