NLS([[ local limbs = {
head = owner.Character.Head,
la = owner.Character["Left Arm"],
ra = owner.Character["Right Arm"]
}

for i,v in pairs(owner.Character:GetDescendants()) do
if v:IsA("Hat") or v:IsA("Accessory") then
v:FindFirstChildWhichIsA("BasePart").Transparency = 1
end
end
for i,v in pairs(limbs) do
local force1 = Instance.new("BodyPosition", v)
force1.MaxForce = Vector3.new(math.huge,math.huge,math.huge)
force1.P = 150000
force1.D = 1000

local force2 = Instance.new("BodyGyro", v)
force2.MaxTorque = Vector3.new(math.huge,math.huge,math.huge)
force2.P = 150000
force2.D = 1000
end



local cam = workspace.CurrentCamera
local mouse = owner:GetMouse()

 mouse.TargetFilter = workspace
 
 game:GetService("RunService").RenderStepped:Connect(function()
 cam.CFrame = owner.Character.HumanoidRootPart.CFrame:Lerp(CFrame.new(owner.Character.HumanoidRootPart.CFrame * CFrame.new(0,1.5 * 2,0).Position, mouse.Hit.Position),.5)
 limbs.head.BodyPosition.Position = cam.CFrame.Position
 limbs.head.BodyGyro.CFrame = cam.CFrame 
 
limbs.la.BodyPosition.Position = CFrame.new(owner.Character.HumanoidRootPart.CFrame * CFrame.new(1,1,0).Position, mouse.Hit.Position) * CFrame.Angles(0,0,math.rad(90)) * CFrame.new(0,-1,0).Position
limbs.la.BodyGyro.CFrame = CFrame.new(owner.Character.HumanoidRootPart.CFrame * CFrame.new(1,1,0).Position, mouse.Hit.Position) * CFrame.Angles(0,0,math.rad(90)) * CFrame.new(0,-1,0)

limbs.ra.BodyPosition.Position = CFrame.new(owner.Character.HumanoidRootPart.CFrame * CFrame.new(1,.5,0).Position, mouse.Hit.Position) * CFrame.Angles(math.rad(90),0,0) * CFrame.new(0,-1,0).Position
limbs.ra.BodyGyro.CFrame = CFrame.new(owner.Character.HumanoidRootPart.CFrame * CFrame.new(1,.5,0).Position, mouse.Hit.Position) * CFrame.Angles(math.rad(90),0,0) * CFrame.new(0,-1,0)

limbs.la.BodyPosition.Position = CFrame.new(owner.Character.HumanoidRootPart.CFrame * CFrame.new(-1,.5,0).Position, mouse.Hit.Position) * CFrame.Angles(math.rad(90),0,0) * CFrame.new(0,-1,0).Position
limbs.la.BodyGyro.CFrame = CFrame.new(owner.Character.HumanoidRootPart.CFrame * CFrame.new(-1,.5,0).Position, mouse.Hit.Position) * CFrame.Angles(math.rad(90),0,0) * CFrame.new(0,-1,0)

 end)
 
]], owner.Character)

owner.Character.Humanoid.HipHeight = 2
owner.Character.Humanoid.RequiresNeck = false
print("Humanoid Set")
print("Setting Body")
owner.Character["Left Leg"]:Destroy()
owner.Character["Right Leg"]:Destroy()
print("Legs Deleted")
owner.Character["Right Arm"]:SetNetworkOwner(owner)
owner.Character["Left Arm"]:SetNetworkOwner(owner)
owner.Character["Head"]:SetNetworkOwner(owner)
owner.Character["Torso"]:SetNetworkOwner(owner)
print("Network Ownership Set")
owner.Character.Torso.Neck:Destroy()
owner.Character.Torso["Left Shoulder"]:Destroy()
owner.Character.Torso["Right Shoulder"]:Destroy()
print("Breaking Joints For Movement")

owner.Character.Head.CFrame = CFrame.new(0,10000,0)
owner.Character["Left Arm"].CFrame = CFrame.new(0,10000,0)
owner.Character["Right Arm"].CFrame = CFrame.new(0,10000,0)

wait(1)

Instance.new("Model", script)
owner.Character.Head.Parent = script.Model
owner.Character["Left Arm"].Parent = script.Model
owner.Character["Right Arm"].Parent = script.Model
owner.Character.Shirt:Clone().Parent = script.Model
owner.Character.Pants:Clone().Parent = script.Model
owner.Character.Humanoid:Clone().Parent = script.Model

script.Model.Head.CanCollide = false
script.Model["Left Arm"].CanCollide = false
script.Model["Right Arm"].CanCollide = false


local name = Instance.new("BillboardGui", script.Model.Head)
name.Size = UDim2.new(.25,0,.125,00)
name.StudsOffset = Vector3.new(0,4.5,0)
name.MaxDistance = 200
local tb = Instance.new("TextBox", name)
tb.Size = UDim2.new(1,0,1,0)
tb.BackgroundTransparency = 1
tb.TextSize = 15
tb.TextYAlignment = 'Top'
tb.TextColor3 = BrickColor.new("Institutional white").Color
tb.TextStrokeTransparency = 0
tb.Text = owner.Name..[[

]]..'(@'..owner.DisplayName..')'


game:GetService("RunService").Heartbeat:Connect(function()
script.Model.Head:SetNetworkOwner(owner)
script.Model["Left Arm"]:SetNetworkOwner(owner)
script.Model["Right Arm"]:SetNetworkOwner(owner)
end)