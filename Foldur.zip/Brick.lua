local newchar = Instance.new("Model", script)
local brick = Instance.new("Seat", newchar)
brick.Size = Vector3.new(2,1,4)
brick.Name = 'HumanoidRootPart'
brick.Disabled = true

owner.Character = newchar

local hum = Instance.new("Humanoid", newchar)

local rem = Instance.new("RemoteEvent", newchar)
rem.Name = 'KEY'

NLS("local event = owner.Character.KEY owner:GetMouse().KeyDown:Connect(function(key) event:FireServer(key) end)", owner.Character)

warn("Brick by X_XSardonyx")
print("E = 'Attack'")
print("R = 'Spin'")
print("T = 'Explode'")
print("F = 'Spin Dash'")
print("G = 'Seat'")

local SEAT = false

rem.OnServerEvent:Connect(function(plr, key)

if key == 'e' then
	local clon = brick:Clone()
	clon.Parent = newchar
	clon.Name = 'ATTACK'
	clon.CanCollide = false
	local weld = Instance.new("Weld", clon)
	weld.Part1 = clon
	weld.Part0 = brick
	
	clon.Material = 'Glass'
	clon.BrickColor = BrickColor.new("Maroon")
	
	clon.Touched:Connect(function(part)
	if part ~= brick and part.Parent.ClassName == 'Model' then
	if part.Parent:FindFirstChild("Humanoid") then
	part.Parent:FindFirstChild("Humanoid"):TakeDamage(5)
	end
	end
	end)
	
	for i = 1,10 do
	wait()
	clon.Size = clon.Size:Lerp(Vector3.new(3,2,5), .15)
	clon.Transparency = clon.Transparency + .1
	end
	clon:Destroy()
	
	elseif key == 'r' then
	for i = 1,25 do
	brick.CFrame = brick.CFrame * CFrame.Angles(0,math.rad(i * 10),0)
	wait()
	end
	
	elseif key == 't' then
	brick.Anchored = true
	local ff = Instance.new("ForceField", newchar)
	ff.Visible = false
	game:GetService("Debris"):AddItem(ff, 1)
	Instance.new("Explosion", brick).Position = brick.Position
	wait(1)
	
	brick.Anchored = false
	
	elseif key == 'f' then
	
	local bricor = brick.Orientation
	
	local on = true
	local rot = 0
	brick.Anchored = true
	game:GetService("RunService").Heartbeat:Connect(function()
	if on == true then
	rot = rot + 1
	brick.CFrame = brick.CFrame * CFrame.Angles(math.rad(rot * 10),0,0)
	end
	end)
	
	wait(2)
	on = false
	brick.Orientation = bricor
	brick.Anchored = false
	brick.Velocity = brick.CFrame.LookVector * 100
	
	elseif key == 'g' then
	
	if SEAT == true then
	SEAT = false
	brick.Disabled = true
	warn("Seat is off")
	warn("Players can not sit on you")
	else
	
	SEAT = true
	brick.Disabled = false
	warn("Seat is on")
	warn("Players can sit on you")
	end
	
end

end)