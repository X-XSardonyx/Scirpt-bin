local HRP = owner.Character.HumanoidRootPart
--7200959510

local FLOOR = Instance.new("Part", script)
FLOOR.Anchored = true
FLOOR.CanCollide = false
FLOOR.Material = 'SmoothPlastic'
FLOOR.Locked = true
FLOOR.Size = Vector3.new(1,1,1)
FLOOR.Transparency = .5
FLOOR.Color = BrickColor.new("CGA brown").Color

Instance.new("BlockMesh", owner.Character["Left Leg"])
Instance.new("BlockMesh", owner.Character["Right Leg"])
Instance.new("BlockMesh", owner.Character["Left Arm"])
Instance.new("BlockMesh", owner.Character["Right Arm"])
Instance.new("BlockMesh", owner.Character["Torso"])
Instance.new("BlockMesh", owner.Character["Head"])

owner.Character.Head.Size = Vector3.new(1.25,1.25,1.25)

owner.Character.Torso.BrickColor = BrickColor.new("CGA brown")
owner.Character["Left Leg"].BrickColor = BrickColor.new("CGA brown")
owner.Character["Right Leg"].BrickColor = BrickColor.new("CGA brown")
owner.Character.Head.BrickColor = BrickColor.new("Pearl")
owner.Character["Left Arm"].BrickColor = BrickColor.new("Pearl")
owner.Character["Right Arm"].BrickColor = BrickColor.new("Pearl")

owner.Character.Torso.Material = 'Slate'
owner.Character["Left Leg"].Material = 'Slate'
owner.Character["Right Leg"].Material = 'Slate'


owner.Character.Head:FindFirstChildWhichIsA("Decal"):Destroy()

for i,v in pairs(owner.Character:GetChildren()) do
if v:IsA("Accessory") or v:IsA("Hat") or v:IsA("CharacterMesh") then
v:Destroy()
end
end

local mesh = Instance.new("SpecialMesh", FLOOR)
mesh.MeshId = 'rbxassetid://489415286'
mesh.MeshType = 'FileMesh'
mesh.Scale = Vector3.new(5,5,5)

game:GetService("RunService").Heartbeat:Connect(function()
FLOOR.CFrame = CFrame.new(owner.Character.HumanoidRootPart.CFrame * CFrame.new(0,-2,0).Position)
FLOOR.CFrame = FLOOR.CFrame * CFrame.Angles(0,math.rad(1),0)
mesh.Scale = Vector3.new(4 + math.sin(tick() * 2),4 + math.sin(tick() * 2),4+ math.sin(tick() * 2))
end)

for i,v in pairs(owner.Character:GetDescendants()) do
if v:IsA("Motor6D") then
local weld = Instance.new("Weld", v.Parent)
weld.Part1 = v.Part1
weld.Part0 = v.Part0
weld.C0 = v.C0
weld.C1 = v.C1
weld.Name = v.Name
v:Destroy()
end
end

Attack = false

--Anim Defaults
AnimDefaults = {
Head = owner.Character.Torso.Neck.C0,
Torso = owner.Character.HumanoidRootPart.RootJoint.C0,
Larm = owner.Character.Torso["Left Shoulder"].C0,
Rarm = owner.Character.Torso["Right Shoulder"].C0,
Lleg = owner.Character.Torso["Left Hip"].C0,
Rleg = owner.Character.Torso["Right Hip"].C0
}
--Setting Joints
Head = owner.Character.Torso.Neck
Torso = owner.Character.HumanoidRootPart.RootJoint
Larm = owner.Character.Torso["Left Shoulder"]
Rarm = owner.Character.Torso["Right Shoulder"]
Lleg = owner.Character.Torso["Left Hip"]
Rleg = owner.Character.Torso["Right Hip"]


game:GetService("RunService").Heartbeat:Connect(function()
if owner.Character.HumanoidRootPart.Velocity.X == 0 and owner.Character.HumanoidRootPart.Velocity.Z == 0 and owner.Character.HumanoidRootPart.Velocity.Y == 0 and Attack == false then
Lleg.C0 = Lleg.C0:Lerp(AnimDefaults.Lleg * CFrame.new(0,math.sin(tick()) / 8 ,0) * CFrame.Angles(math.rad(-0.057), 0, math.rad(15.011)), .1)
Rleg.C0 = Rleg.C0:Lerp(AnimDefaults.Rleg * CFrame.new(1, 0 + math.sin(tick()) / 8, 0) * CFrame.Angles(0, 0, math.rad(-30.023)), .1)
Rarm.C0 = Rarm.C0:Lerp(AnimDefaults.Rarm * CFrame.Angles(math.rad(25),0,math.rad(-20)), .2)
Larm.C0 = Larm.C0:Lerp(AnimDefaults.Larm * CFrame.Angles(math.rad(25),0,math.rad(20)), .2)Torso.C0 = Torso.C0:Lerp(AnimDefaults.Torso * CFrame.new(0,0,math.sin(tick()) / 5) * CFrame.Angles(math.rad(10 + math.sin(tick() / 5) * 2),0,0), .1)


--[[
Rarm.C0 = Rarm.C0:Lerp(AnimDefaults.Rarm * CFrame.new(0, math.sin(tick()) / 4, 0.3) * CFrame.Angles(0, math.rad(44.977), math.rad(165.012)), .2)
Larm.C0 = Larm.C0:Lerp(AnimDefaults.Larm * CFrame.new(0,math.sin(tick()) / 4,0) * CFrame.Angles(math.rad(-15.011), 0, 0), .2)
]]Head.C0 = Head.C0:Lerp(AnimDefaults.Head * CFrame.Angles(0, 0, math.rad(0)), .1)
Torso.C0 = Torso.C0:Lerp(AnimDefaults.Torso * CFrame.new(0, 0, 2 + math.sin(tick()) / 4), .1)
end
end)

game:GetService("RunService").Heartbeat:Connect(function()
if owner.Character.HumanoidRootPart.Velocity.X ~= 0 or owner.Character.HumanoidRootPart.Velocity.Z ~= 0 and owner.Character.HumanoidRootPart.Velocity.Y < .1 and Attack == false then
Torso.C0 = Torso.C0:Lerp(AnimDefaults.Torso, .1)
Lleg.C0 = Lleg.C0:Lerp(AnimDefaults.Lleg * CFrame.Angles(0,0,math.rad(math.sin(tick() * 5) * 30)), .1)
Rleg.C0 = Rleg.C0:Lerp(AnimDefaults.Rleg * CFrame.Angles(0,0,math.rad(math.sin(tick() * 5) * 30)), .1)
Rarm.C0 = Rarm.C0:Lerp(AnimDefaults.Rarm * CFrame.Angles(0,0,math.rad(-math.sin(tick() * 5) * 30)), .1)
Larm.C0 = Larm.C0:Lerp(AnimDefaults.Larm * CFrame.Angles(0,0,math.rad(-math.sin(tick() * 5) * 30)), .1)
Head.C0 = Head.C0:Lerp(AnimDefaults.Head, .1)
end
end)

game:GetService("RunService").Heartbeat:Connect(function()
if owner.Character.HumanoidRootPart.Velocity.Y > 1 and Attack == false then
Torso.C0 = Torso.C0:Lerp(AnimDefaults.Torso * CFrame.new(0,0,0), .2)
Lleg.C0 = Lleg.C0:Lerp(AnimDefaults.Lleg * CFrame.Angles(math.rad(-20),0,0), .2)
Rleg.C0 = Rleg.C0:Lerp(AnimDefaults.Rleg * CFrame.Angles(math.rad(-20),0,0), .2)
Rarm.C0 = Rarm.C0:Lerp(AnimDefaults.Rarm * CFrame.Angles(math.rad(-45),0,0), .2)
Larm.C0 = Larm.C0:Lerp(AnimDefaults.Larm * CFrame.Angles(math.rad(-45),0,0), .2)
Head.C0 = Head.C0:Lerp(AnimDefaults.Head * CFrame.Angles(math.rad(25),0,0), .2)
end
end)

local NLS = NLS([[

local rem = script.RemoteEvent
local mouse = owner:GetMouse()
local ui = game:GetService("UserInputService")

ui.InputBegan:Connect(function(input)
rem:FireServer(input.KeyCode, mouse.Hit.Position, mouse.Target)
end)

]], owner.Character)


local rem = Instance.new("RemoteEvent", NLS)

function RING(pos)

for i = 1,10 do
local x = math.cos(i * (2*math.pi / 10)) * 10
local z = math.sin(i * (2*math.pi / 10)) * 10
local part = Instance.new("Part", script)
part.Anchored = true
part.CFrame = CFrame.new(pos * CFrame.new(x,0,z).Position, pos.Position)
part.Material = 'Slate'
part.Size = Vector3.new(5,10,2)
part.Color = BrickColor.new("CGA brown").Color
game:GetService("Debris"):AddItem(part, 5)
game:GetService("TweenService"):Create(part, TweenInfo.new(1), {Size = Vector3.new(15,20,4), CFrame = part.CFrame * CFrame.new(0,5,10)}):Play()
wait(.2)
end
end

function StarBreaker(pos)
local effect = Instance.new("Part", script)
effect.Anchored = true
effect.Material = 'Neon'
effect.CanCollide = false
effect.Shape = 'Ball'
effect.Position = pos
effect.CastShadow = false
local exp = Instance.new("Explosion", effect)
exp.Position = pos
exp.BlastRadius = 30
exp.Visible = false
effect.BrickColor = BrickColor.new("CGA brown")
game:GetService("TweenService"):Create(effect, TweenInfo.new(1), {Size = Vector3.new(30,30,30), Transparency = 1}):Play()
game:GetService("Debris"):AddItem(effect, 1)
end

function spike(pos, target)
local SPIKE = Instance.new("Part", script)
SPIKE.Anchored = true
SPIKE.CanCollide = false
SPIKE.Material = 'SmoothPlastic'
SPIKE.Locked = true
SPIKE.Size = Vector3.new(1,1,1)
SPIKE.Transparency = .5
SPIKE.Color = BrickColor.new("CGA brown").Color
SPIKE.CFrame = CFrame.new(HRP.CFrame * CFrame.new(0,0,-4).Position, pos) * CFrame.Angles(0,math.rad(90),0)

local mesh = Instance.new("SpecialMesh", SPIKE)
mesh.MeshId = 'rbxassetid://7200959510'
mesh.MeshType = 'FileMesh'
mesh.Scale = Vector3.new(.1,.1,.1)

game:GetService("Debris"):AddItem(SPIKE, 10)

if target.Anchored == false then
target.Color = BrickColor.new("CGA brown").Color
target.Anchored = true
target.CanCollide = true
target:BreakJoints()
end

game:GetService("RunService").Heartbeat:Connect(function()
SPIKE.CFrame = SPIKE.CFrame * CFrame.new(1,0,0) * CFrame.Angles(math.rad(10),0,0)
end)

SPIKE.Touched:Connect(function(part)
if part.Parent ~= owner.Character then
part.Anchored = true
part.Parent = workspace
part:BreakJoints()
part.Color = BrickColor.new("CGA brown").Color
part.CanCollide = true
for i,v in pairs(part:GetDescendants()) do
if v:IsA("SpecialMesh") then
v.TextureId = ''
end
end
end
end)

end

function icewall(CF)
local wall = Instance.new("Part", script)
wall.Size = Vector3.new(10,.2,10)
wall.Material = 'Slate'
wall.BrickColor = BrickColor.new("CGA brown")
wall.Anchored = true
wall.CFrame = CF * CFrame.new(0,-4.9,0)

game:GetService("Debris"):AddItem(wall, 8)
game:GetService("TweenService"):Create(wall, TweenInfo.new(.5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0, false, 0), {Transparency = .75, Size = Vector3.new(10,10,2), CFrame = wall.CFrame * CFrame.new(0,4.9,0)}):Play()
end

function IceFloor()
local block = Instance.new("Part", script)
block.Size = Vector3.new(10,1,10)
block.CFrame = owner.Character.HumanoidRootPart.CFrame * CFrame.new(0,-3.5,0)
block.Material = 'Slate'
block.BrickColor = BrickColor.new("CGA brown")
block.Transparency = 0
block.Massless = true
block.Anchored = true
game:GetService("Debris"):AddItem(block, 5)

game:GetService("RunService").Heartbeat:Connect(function()
block.CFrame = block.CFrame:Lerp(owner.Character.HumanoidRootPart.CFrame * CFrame.new(0,-2.5,0), .05)
end)

end

function IceBlock(Pos)
local block = Instance.new("Part", script)
block.Size = Vector3.new(4,4,4)
block.Material = 'Slate'
block.BrickColor = BrickColor.new("CGA brown")
block.Transparency = 0
block.Massless = true
block.CFrame = HRP.CFrame * CFrame.new(0,0,-5)
game:GetService("Debris"):AddItem(block, 5)
end

function Clone()
owner.Character.Archivable = true
local clon = owner.Character:Clone()
wait(.1)

owner.Character:SetPrimaryPartCFrame(HRP.CFrame * CFrame.new(0,2,-5))


game:GetService("Debris"):AddItem(clon, 10.2)


for i,v in pairs(clon:GetDescendants()) do
if v:IsA("Humanoid") then
v:Destroy()
wait(.1)
elseif v:IsA("SpecialMesh") then
v.TextureId = ''
elseif v:IsA("Decal") or v:IsA("Texture") then
v:Destroy()
elseif v:IsA("BasePart") then
v.Material = 'Slate'
v.Anchored = true
v.BrickColor = BrickColor.new("CGA brown")
v.CanCollide = true
game:GetService("TweenService"):Create(v, TweenInfo.new(5, Enum.EasingStyle.Linear, Enum.EasingDirection.Out, 0,false,5), {Transparency = 1, CFrame = v.CFrame * CFrame.new(math.random(-10,10),math.random(-10,10),math.random(-10,10)) * CFrame.Angles(math.random(-10,10),math.random(-10,10),math.random(-10,10))}):Play()
end
end
clon.Parent = script
end

local db = false

rem.OnServerEvent:Connect(function(plr, input, Pos, target)
if input == Enum.KeyCode.E and db == false then
db = true
icewall(CFrame.new(HRP.CFrame * CFrame.new(0,0,-7).Position, HRP.Position))
icewall(CFrame.new(HRP.CFrame * CFrame.new(7,0,-3.5).Position, HRP.Position))
icewall(CFrame.new(HRP.CFrame * CFrame.new(-7,0,-3.5).Position, HRP.Position))
wait(.2)
db = false
elseif input == Enum.KeyCode.R and db == false then
db = true
Clone()
wait(.2)
db = false
elseif input == Enum.KeyCode.F and db == false then
db = true
IceFloor()
wait(.2)
db = false
elseif input == Enum.KeyCode.C and db == false then
db = true
IceBlock(Pos)
wait(.2)
db = false
elseif input == Enum.KeyCode.G and db == false then
db = true
spike(Pos, target)
wait(.2)
db = false
elseif input == Enum.KeyCode.V and db == false then
db = true
StarBreaker(Pos)
wait(.2)
db = false
elseif input == Enum.KeyCode.B and db == false then
db = true
RING(HRP.CFrame)
wait(.2)
db = false
end
end)