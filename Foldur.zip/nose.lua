--4932866072  4932869369

local nose = Instance.new("Part", owner.Character)
nose.Size = Vector3.new(.25,.25,.25)
nose.CanCollide = false
nose.Massless = true
nose.Color = owner.Character.Head.Color
local mesh = Instance.new("SpecialMesh", nose)
mesh.MeshId = 'rbxassetid://'..4932866072
mesh.MeshType = 'FileMesh'

local weld = Instance.new("Weld", nose)
weld.Part1 = nose
weld.Part0 = owner.Character.Head
weld.C0 = CFrame.new(0,0,-.6) * CFrame.Angles(math.rad(-40),0,0)