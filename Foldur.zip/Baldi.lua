owner.Character.Humanoid:ApplyDescription(Instance.new("HumanoidDescription"))
wait(1)
m1 = Instance.new("SpecialMesh", owner.Character["Torso"])
m1.MeshId = 'rbxasset://fonts//torso.mesh'
m1.MeshType = 'FileMesh'

m2 = Instance.new("SpecialMesh", owner.Character["Right Leg"])
m2.MeshId = 'rbxasset://fonts//rightleg.mesh'
m2.MeshType = 'FileMesh'

m3 = Instance.new("SpecialMesh", owner.Character["Right Arm"])
m3.MeshId = 'rbxasset://fonts//rightarm.mesh'
m3.MeshType = 'FileMesh'

m4 = Instance.new("SpecialMesh", owner.Character["Left Leg"])
m4.MeshId = 'rbxasset://fonts//leftleg.mesh'
m4.MeshType = 'FileMesh'

m5 = Instance.new("SpecialMesh", owner.Character["Left Arm"])
m5.MeshId = 'rbxasset://fonts//leftarm.mesh'
m5.MeshType = 'FileMesh'

owner.Character["Right Arm"].BrickColor = BrickColor.new("Lime green")
owner.Character["Left Arm"].BrickColor = BrickColor.new("Lime green")
owner.Character["Torso"].BrickColor = BrickColor.new("Lime green")
owner.Character["Left Leg"].BrickColor = BrickColor.new("Really blue")
owner.Character["Right Leg"].BrickColor = BrickColor.new("Really blue")
owner.Character.Head.BrickColor = BrickColor.new("Pastel brown")

for i,v in pairs(owner.Character:GetDescendants()) do
if v:IsA("Motor6D") then
local weld = Instance.new("Weld", v.Parent)
weld.Part1 = v.Part1
weld.Part0 = v.Part0
weld.C0 = v.C0
weld.C1 = v.C1
weld.Name = v.Name
v:Destroy()
end
end

owner.Character.Torso["Right Shoulder"].C0 = owner.Character.Torso["Right Shoulder"].C0 * CFrame.Angles(0,0,math.rad(90))

rem = Instance.new("RemoteEvent", owner.Character)

Ruler = Instance.new("Part", owner.Character)
Ruler.Size = Vector3.new(.25,.1,2)
Ruler.CanCollide = false
Ruler.Material = 'WoodPlanks'
Ruler.BrickColor = BrickColor.new("CGA brown")
Ruler.Massless = false

weld = Instance.new("Weld", Ruler)
weld.Part1 = Ruler
weld.Part0 = owner.Character["Right Arm"]
weld.C0 = CFrame.new(0,-1,-1)

local sound = Instance.new("Sound", owner.Character.HumanoidRootPart)
sound.SoundId = 'rbxassetid://1828370087'
sound.MaxDistance = 100
sound.Volume = .5
sound.Looped = true
sound:Play()

local Smack = Instance.new("Sound", owner.Character.HumanoidRootPart)
Smack.SoundId = 'rbxassetid://1909185477'
Smack.Volume = 1
Smack.MaxDistance = 100

local Catch = Instance.new("Sound", owner.Character.HumanoidRootPart)
Catch.SoundId = 'rbxassetid://2655138140'
Catch.Volume = 1
Catch.MaxDistance = 100

Smacking = false

rem.OnServerEvent:connect(function()
Smack:Play()
Smacking = true
weld.C0 = CFrame.new(-1,-1,0) * CFrame.Angles(0,math.rad(90),0)
wait(.25)
weld.C0 = CFrame.new(0,-1,-1) 
Smacking = false
end)	

Ruler.Touched:Connect(function(part)

if Smacking == true and part.Anchored == false then
part:BreakJoints()
Catch:Play()
end

end)

NLS([[
owner.Character.Humanoid.WalkSpeed = 0
owner.Character.Humanoid.JumpPower = 0
rem = script.Parent
HRP = owner.Character.HumanoidRootPart

mouse = owner:GetMouse()

gy = Instance.new("BodyGyro", HRP)
gy.MaxTorque = Vector3.new(math.huge,math.huge,math.huge)
gy.P = 150000
gy.D = 1000

lookblock = Instance.new("Part")

game:GetService("RunService").RenderStepped:Connect(function()
lookblock.CFrame = CFrame.new(HRP.Position, mouse.Hit.Position)
lookblock.Orientation = Vector3.new(0,lookblock.Orientation.Y,0)
gy.CFrame = lookblock.CFrame
end)

mouse.Button1Down:Connect(function()
HRP.CFrame = HRP.CFrame * CFrame.new(0,0,-3)
rem:FireServer()
end)

]], rem)