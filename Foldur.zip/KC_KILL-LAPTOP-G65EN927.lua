local tool = Instance.new("Tool", owner.Backpack)
tool.Name = 'KC EFFECT'
tool.CanBeDropped = false
tool.RequiresHandle = false

local colors = {BrickColor.new("Maroon"), BrickColor.new("Persimmon"), BrickColor.new("Really red")}

local rem = Instance.new("RemoteEvent", tool)
rem.Name = 'Fire'

NLS([[

local rem = script.Parent:WaitForChild("Fire")
local Mouse = game:GetService"Players".LocalPlayer:GetMouse()
local tool = script.Parent

tool.Activated:Connect(function()
rem:FireServer(Mouse.Target)
end)

]], tool)


rem.OnServerEvent:Connect(function(plr, target)
if target.Parent ~= workspace then

local sound = Instance.new("Sound", target)
sound.SoundId = 'rbxassetid://3545893736'
sound.MaxDistance = 100
sound.Volume = 2
sound:Play()

for i,v in pairs(target.Parent:GetDescendants()) do
if v:IsA("Decal") or v:IsA("Texture") then
v:Destroy()
elseif v:IsA("BasePart") then
v.BrickColor = colors[math.random(1, #colors)]
v.Material = 'Glass'
v.Anchored = true
v.CanCollide = false
end
end
wait(1.5)
for i,v in pairs(target.Parent:GetDescendants()) do
if v:IsA("Decal") or v:IsA("Texture") then
v:Destroy()
elseif v:IsA("BasePart") then
v:BreakJoints()
game:GetService("Debris"):AddItem(v, 5)
game:GetService("TweenService"):Create(v, TweenInfo.new(5), {Transparency = 1, CFrame = v.CFrame * CFrame.new(math.random(-10,10),math.random(-10,10),math.random(-10,10)) * CFrame.Angles(math.random(-10,10),math.random(-10,10),math.random(-10,10))}):Play()
end
end
end
end)