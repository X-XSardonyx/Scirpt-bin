:S 
local Target = game.Players.X_XSardonyx
local Character = Target.Character
local ids = {up = 6699157459, down = 6583630409, left = 6699156906, right = 6699158560}

local event = Instance.new("RemoteEvent", Character)
event.Name = 'FNF'

local TS = game:GetService("TweenService")
local info = TweenInfo.new(1)

function arrow(id, pos)
local effect = Instance.new("Part", Workspace)
effect.CFrame = pos
effect.Size = Vector3.new(2,2,.05)
effect.Transparency = 1
effect.Anchored = true
effect.CanCollide = false
local decal = Instance.new("Decal", effect)
decal.Texture = 'rbxassetid://'..id
local goal = {CFrame = pos * CFrame.new(0,10,0)}
TS:Create(effect, info, goal):Play()
wait(1.2)
effect:Destroy()
end
 
event.OnServerEvent:Connect(function(plr, key)
if key == 'w' then
arrow(ids.up, Character.HumanoidRootPart.CFrame * CFrame.new(3,0,3))
elseif key == 's' then
arrow(ids.down, Character.HumanoidRootPart.CFrame * CFrame.new(1,0,3))
elseif key == 'a' then
arrow(ids.left, Character.HumanoidRootPart.CFrame * CFrame.new(-1,0,3))
elseif key == 'd' then
arrow(ids.right, Character.HumanoidRootPart.CFrame * CFrame.new(-3,0,3))
end
end)

| 

:cs X_XSardonyx 
local plr = game.Players.LocalPlayer
local mouse = plr:GetMouse()
local event = plr.Character.FNF

mouse.KeyDown:Connect(function(key)
event:FireServer(key)
end)