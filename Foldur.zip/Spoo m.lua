local spoon = Instance.new("Tool", owner.Backpack)
spoon.Name = 'Spoo n'
spoon.CanBeDropped=true
spoon.Grip = CFrame.new(0,.75,5) * CFrame.Angles(math.rad(-90),math.rad(-180),math.rad(0))

local handle = Instance.new("Part", spoon)
handle.Size = Vector3.new(2,1,10)
handle.Name = 'Handle'
handle.Locked = true

--6427058280
--431177782
local mesh = Instance.new("SpecialMesh", handle)
mesh.Scale = Vector3.new(.1,.1,.1)
mesh.MeshType = 'FileMesh'
mesh.MeshId = 'rbxassetid://431177782'


--setting mode system
local mode = 4
local modes = {}
for i = 1,mode do
table.insert(modes, 'i')
end

mode = 1


--Sounds :')


local fwoosh = Instance.new("Sound", handle)
fwoosh.MaxDistance = 100
fwoosh.SoundId = 'rbxassetid://6427058280'
fwoosh.Pitch = 1
fwoosh.Volume = 10

local sound = Instance.new("Sound", handle)
sound.MaxDistance = 100
sound.Looped = true
sound.SoundId = 'rbxassetid://3113187018'
sound.Pitch = 1
sound.Volume = 5

local slap = Instance.new("Sound", handle)
slap.SoundId = 'rbxassetid://5189782994'
slap.Volume = 5
slap.Pitch = 3
slap.MaxDistance = 100

local ping = Instance.new("Sound", handle)
ping.SoundId = 'rbxassetid://6698657809'
ping.Volume = 10
ping.Pitch = 1
ping.MaxDistance = 100

local effect = Instance.new("FlangeSoundEffect", sound)
effect.Depth = .5
effect.Rate = 5

spoon.Equipped:Connect(function()
sound:Play()
fwoosh:Play()
end) 
spoon.Unequipped:Connect(function()
sound:Stop()
end) 

spoon.Activated:Connect(function()
slap:Play()
spoon.Grip = CFrame.new(0,.75,6) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(180))
handle.Touched:Connect(function() end)
for i,v in pairs(handle:GetTouchingParts()) do
if v.Parent:FindFirstChild("Humanoid") then
v.Parent:FindFirstChild("Humanoid"):TakeDamage(50)
end
end
wait(.1)
spoon.Grip = CFrame.new(0,.75,5) * CFrame.Angles(math.rad(-90),math.rad(-180),math.rad(0))
end)

local rem = Instance.new("RemoteEvent", spoon)
NLS([[local rem = script.Parent.RemoteEvent
local mouse = owner:GetMouse()
mouse.KeyDown:Connect(function(key)
if key == 'e' then
rem:FireServer()
end
end)

]], spoon)

rem.OnServerEvent:Connect(function()
if mode == #modes then
mode = 1
else
mode = mode + 1
end

if mode == 1 then
sound.SoundId = 'rbxassetid://'..3113187018
ping:Play()
effect.Enabled = true
elseif mode == 2 then
sound.SoundId = 'rbxassetid://'..5939072342
ping:Play()
effect.Enabled = false
elseif mode == 3 then
sound.SoundId = 'rbxassetid://'..4708447501
ping:Play()
effect.Enabled = false
elseif mode == 4 then
sound.SoundId = 'rbxassetid://'..5164348874
ping:Play()
effect.Enabled = false
end
end)

game:GetService("RunService").Heartbeat:Connect(function()
if mode == 1 then
handle.Color = Color3.fromHSV(tick() /5 %1/1,1,1)
mesh.Scale = mesh.Scale:Lerp(Vector3.new(.1,.1,.1), .1)
spoon.Grip = spoon.Grip:Lerp(CFrame.new(0,.75,5) * CFrame.Angles(math.rad(-90),math.rad(-180),math.rad(0)), .1)

elseif mode == 2 then
handle.Color = handle.Color:Lerp(BrickColor.new("Deep orange").Color, .1)
spoon.Grip = spoon.Grip:Lerp(CFrame.new(0,.75,5) * CFrame.Angles(math.rad(-90),math.rad(-180),math.rad(0)), .1)

mesh.Scale = mesh.Scale:Lerp(Vector3.new(.1,.1,.1), .1)
elseif mode == 3 then
handle.Color = handle.Color:Lerp(BrickColor.new("Lime green").Color, .1)
spoon.Grip = spoon.Grip:Lerp(CFrame.new(0,.75,5) * CFrame.Angles(math.rad(-90),math.rad(-180),math.rad(0)), .1)

mesh.Scale = Vector3.new(.1,.1,math.sin(tick()*2) / 10)
spoon.Grip = spoon.Grip:Lerp(CFrame.new(0,.75,5) * CFrame.Angles(math.rad(-90),math.rad(-180),math.rad(0)), .1)
elseif mode == 4 then
handle.Color = handle.Color:Lerp(BrickColor.new("Ghost grey").Color, .1)
mesh.Scale = mesh.Scale:Lerp(Vector3.new(.01,.01,.01), .1)
spoon.Grip = spoon.Grip:Lerp(CFrame.new(0,0,1) * CFrame.Angles(math.rad(-90),math.rad(-180),math.rad(0)), .25)
end
end)