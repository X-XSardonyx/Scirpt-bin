owner.Character.Humanoid:Destroy()
NLS([[

local head = owner.Character.Head
local torso = owner.Character.Torso
local larm = owner.Character["Left Arm"]
local rarm = owner.Character["Right Arm"]
local lleg = owner.Character["Left Leg"]
local rleg = owner.Character["Right Leg"]
local hrppos = CFrame.new(torso.Position + Vector3.new(0,2,0))
local camera = workspace.CurrentCamera
local LIMBS = {head, torso, larm, rarm, lleg, rleg}
torso:ClearAllChildren()

--local camblock = Instance.new("Part")

local fakehum = Instance.new("Model", workspace)
local hrp = Instance.new("Part", fakehum)
hrp.Name = 'HumanoidRootPart'
hrp.Size = Vector3.new(2,2,1)
hrp.Transparency = 1
hrp.CFrame = hrppos

camera.CameraSubject = hrp

for i,v in pairs(LIMBS) do
if v:IsA("BasePart") then
local pos = Instance.new("BodyPosition", v)
pos.MaxForce = Vector3.new(math.huge,math.huge,math.huge)
pos.P = 150000
pos.D = 1000
pos.Position = v.Position
pos.Name = 'POS'

local gyr = Instance.new("BodyGyro", v)
gyr.MaxTorque = Vector3.new(math.huge,math.huge,math.huge)
gyr.P = 150000
gyr.D = 1000
gyr.CFrame = v.CFrame
gyr.Name = 'GYRO'

end
end

owner.Character = fakehum
Instance.new("Humanoid", fakehum).HipHeight = 2
local CFNorma = {
head = CFrame.new(0,1.5,0),
torso = CFrame.new(0,0,0),
larm = CFrame.new(-1.5,0,0),
rarm = CFrame.new(1.5,0,0),
lleg = CFrame.new(.5,-2,0),
rleg = CFrame.new(-.5,-2,0)
}

local anim = 'Normal'
local sine = 1
game:GetService("RunService").RenderStepped:Connect(function()
sine = sine + 1

local copter = {
rleg = CFrame.new(0,0.5,1) * CFrame.Angles(math.rad(90),0,math.rad(sine * 15)),
larm = CFrame.new(0,-2,1.5) * CFrame.Angles(0,0,math.rad(-90)),
lleg = CFrame.new(0,-2,3) * CFrame.Angles(math.rad(90),math.rad(0),math.rad(0)),
head = CFrame.new(0,-1,-0.5) * CFrame.Angles(math.rad(45),math.rad(0),math.rad(0)),
torso = CFrame.new(0,-2,0) * CFrame.Angles(math.rad(-90),math.rad(0),math.rad(0)),
rarm = CFrame.new(0,-0.5,1) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0))
}

local FNF = {
rleg = CFrame.new(1,-1.9488887786865 + math.sin(sine * .5) / 20,-0.38822856545448) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(15 + math.sin(sine * .5) * 3)),
larm = CFrame.new(-1.5,-0.017037153244019 + math.sin(sine * .5) / 20,0.12940952181816) * CFrame.Angles(math.rad(-15 + math.sin(sine * .5) * 3),math.rad(0),math.rad(-15 + -math.sin(sine * .5) * 3)),
lleg = CFrame.new(-1,-1.9488887786865 + math.sin(sine * .5) / 20,-0.38822856545448) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(-15 + -math.sin(sine * .5) * 3)),
head = CFrame.new(0,1.4318513870239 + math.sin(sine * .5) / 20,0.017638087272644) * CFrame.Angles(math.rad(-15 + -math.sin(sine * .5) * 3),math.rad(0),math.rad(0)),
torso = CFrame.new(0,-0.017037153244019 + math.sin(sine * .5) / 20,0.12940952181816) * CFrame.Angles(math.rad(15 + -math.sin(sine * .5) * 3),math.rad(0),math.rad(0)),
rarm = CFrame.new(1.5,-0.017037153244019 + math.sin(sine * .5) / 20,0) * CFrame.Angles(math.rad(15 + math.sin(sine * .5) * 3),math.rad(0),math.rad(30 + math.sin(sine * .5) * 3))
}

hrppos = hrp.CFrame


if hrp.Velocity.Magnitude < 1 and anim == 'Normal' then
head.POS.Position = hrppos * CFNorma.head.Position
head.GYRO.CFrame = hrppos * CFNorma.head

torso.POS.Position = hrppos * CFNorma.torso.Position
torso.GYRO.CFrame = hrppos * CFNorma.torso

larm.POS.Position = hrppos * CFNorma.larm.Position
larm.GYRO.CFrame = hrppos * CFNorma.larm

rarm.POS.Position = hrppos * CFNorma.rarm.Position
rarm.GYRO.CFrame = hrppos * CFNorma.rarm

lleg.POS.Position = hrppos * CFNorma.lleg.Position
lleg.GYRO.CFrame = hrppos * CFNorma.lleg

rleg.POS.Position = hrppos * CFNorma.rleg.Position
rleg.GYRO.CFrame = hrppos * CFNorma.rleg
elseif hrp.Velocity.Magnitude > 1 and anim == 'Normal' then
head.POS.Position = hrppos * CFNorma.head.Position
head.GYRO.CFrame = hrppos * CFNorma.head

torso.POS.Position = hrppos * CFNorma.torso.Position
torso.GYRO.CFrame = hrppos * CFNorma.torso

larm.POS.Position = hrppos * CFNorma.larm * CFrame.new(0,0,-math.sin(tick() * 5) / 2).Position
larm.GYRO.CFrame = hrppos * CFNorma.larm * CFrame.Angles(math.rad(math.sin(tick() * 5) * 15),0,0)

rarm.POS.Position = hrppos * CFNorma.rarm * CFrame.new(0,0,math.sin(tick() * 5) / 2).Position
rarm.GYRO.CFrame = hrppos * CFNorma.rarm * CFrame.Angles(-math.rad(math.sin(tick() * 5) * 15),0,0)

lleg.POS.Position = hrppos * CFNorma.lleg * CFrame.new(0,0,-math.sin(tick() * 5) / 2).Position
lleg.GYRO.CFrame = hrppos * CFNorma.lleg * CFrame.Angles(math.rad(math.sin(tick() * 5) * 15),0,0)

rleg.POS.Position = hrppos * CFNorma.rleg * CFrame.new(0,0,math.sin(tick() * 5) / 2).Position
rleg.GYRO.CFrame = hrppos * CFNorma.rleg * CFrame.Angles(-math.rad(math.sin(tick() * 5) * 15),0,0)
elseif anim == 'copter' then
head.POS.Position = hrppos * copter.head.Position
head.GYRO.CFrame = hrppos * copter.head

torso.POS.Position = hrppos * copter.torso.Position
torso.GYRO.CFrame = hrppos * copter.torso

larm.POS.Position = hrppos * copter.larm.Position
larm.GYRO.CFrame = hrppos * copter.larm

rarm.POS.Position = hrppos * copter.rarm.Position
rarm.GYRO.CFrame = hrppos * copter.rarm

lleg.POS.Position = hrppos * copter.lleg.Position
lleg.GYRO.CFrame = hrppos * copter.lleg

rleg.POS.Position = hrppos * copter.rleg.Position
rleg.GYRO.CFrame = hrppos * copter.rleg

elseif anim == 'FNF' then

head.POS.Position = hrppos * FNF.head.Position
head.GYRO.CFrame = hrppos * FNF.head

torso.POS.Position = hrppos * FNF.torso.Position
torso.GYRO.CFrame = hrppos * FNF.torso

larm.POS.Position = hrppos * FNF.larm.Position
larm.GYRO.CFrame = hrppos * FNF.larm

rarm.POS.Position = hrppos * FNF.rarm.Position
rarm.GYRO.CFrame = hrppos * FNF.rarm

lleg.POS.Position = hrppos * FNF.lleg.Position
lleg.GYRO.CFrame = hrppos * FNF.lleg

rleg.POS.Position = hrppos * FNF.rleg.Position
rleg.GYRO.CFrame = hrppos * FNF.rleg

end
end)

owner.Chatted:Connect(function(msg)
if msg == '*copter' then
anim = 'copter'
elseif msg == '*fnf' then
anim = 'FNF'
elseif msg == '*idle' then
anim = 'Normal'
end
end)

]], owner.Character)
wait(2)
while wait(.5) do
for i,v in pairs(owner.Character:GetDescendants()) do
if v:IsA("BasePart") then
v:SetNetworkOwner(owner)
v.CanCollide = falset
v:BreakJoints()
end
end
end