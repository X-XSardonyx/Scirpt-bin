print("By X_XSardonyx. Idea from ScandalousScripter")

TargetName = 'KAUAN_123454'
gooduser = true

owner.Character.Archivable = true
local Model0 = owner.Character:Clone()
Model0.Parent = script

Model0.Humanoid.DisplayName = TargetName..' moment'

for i,v in pairs(Model0:GetDescendants()) do
if v:IsA("Shirt") or v:IsA("Pants") or v:IsA("ShirtGraphic") or v:IsA("CharacterMesh") or v:IsA("Hat") or v:IsA("Accessory") then
v:Destroy()
end
end

desc = game:GetService("Players"):GetHumanoidDescriptionFromUserId(owner.Parent:GetUserIdFromNameAsync(TargetName))

Model0.Humanoid:ApplyDescription(desc)

for i,v in pairs(Model0:GetDescendants()) do
if v:IsA("BasePart") then
v.CanTouch = false
v.Locked = true
end
end

charts={
expurgation={[[https://raw.githubusercontent.com/X-XSardonyx/VSB-Scripts/main/expurgation-hard.json]], 6900844331, "Expurgation"},
happy={[[https://raw.githubusercontent.com/X-XSardonyx/VSB-Scripts/main/really-happy-hard.json]], 7795670300, "Really Happy"},
roses={[[https://raw.githubusercontent.com/ninjamuffin99/Funkin/master/assets/preload/data/roses/roses.json]], 6337428158, "Roses"},
fresh={[[https://raw.githubusercontent.com/ninjamuffin99/Funkin/master/assets/preload/data/fresh/fresh.json]] ,6025191328,"Fresh"},
winterhorrorland={[[https://raw.githubusercontent.com/ninjamuffin99/Funkin/master/assets/preload/data/winter-horrorland/winter-horrorland.json]] ,6275837083,'Winter Horrorland'},
south={[[https://raw.githubusercontent.com/ninjamuffin99/Funkin/master/assets/preload/data/south/south.json]] ,6038765924 ,'South'},
nonsence={[[https://raw.githubusercontent.com/X-XSardonyx/VSB-Scripts/main/nonsence.json]], 7102185418 ,"nonsense"},
commonsense={[[https://raw.githubusercontent.com/X-XSardonyx/VSB-Scripts/main/Common%20sense.json]], 7112426008, 'Common Sense'},
opheebop={[[https://raw.githubusercontent.com/Radhew/Salt-Engine/master/assets/preload/data/opheebop/opheebop.json]], 6730593959, 'Opheebop'},
bsmilf={[[https://raw.githubusercontent.com/kckarnige/fnf-week-7-code/main/src/assets/data/milf/milf.json]], 7071427516, 'B-Side Milf'},
endless={[[https://raw.githubusercontent.com/CryBitDev/Sonic.exe-source-1.5/master/assets/preload/data/endless/endless-hard.json]] ,7313871314 ,"Endless"},
sunshine={[[https://raw.githubusercontent.com/wildythomas/mmmbob/main/assets/preload/data/sunshine/sunshine.json]] , 6822649446 ,'Sunshine'},
withered={[[https://raw.githubusercontent.com/wildythomas/mmmbob/main/assets/preload/data/withered/withered.json]] , 6822655743 ,'Withered'},
run={[[https://raw.githubusercontent.com/wildythomas/mmmbob/main/assets/preload/data/run/run.json]], 6822647318, 'RUN'},
release={[[https://raw.githubusercontent.com/Rageminer996/Smoke-Em-Out-Struggle-Mod/main/assets/preload/data/release/release.json]], 6767491531, 'Release'},
nerves={[[https://raw.githubusercontent.com/Rageminer996/Smoke-Em-Out-Struggle-Mod/main/assets/preload/data/nerves/nerves.json]], 6763964321, 'Nerves'},
headache={[[https://raw.githubusercontent.com/Rageminer996/Smoke-Em-Out-Struggle-Mod/main/assets/preload/data/headache/headache.json]], 6765405147,'Headache'},
fading={[[https://raw.githubusercontent.com/Rageminer996/Smoke-Em-Out-Struggle-Mod/main/assets/preload/data/fading/fading.json]], 6770738952 , 'Fading'},
magelo={[[https://fnf-songs.errortp.repl.co/megalostrikeback.html]], 6745517883,'Magelostrikeback'},
otherfriends={[[https://raw.githubusercontent.com/theevity1/VS-Spinel/master/assets/preload/data/other-friends/other-friends.json]], 7490567703, 'Other Friends'},
flippyroll={[[https://raw.githubusercontent.com/Yirius125/FNF-VsFliqpy-1.5-Full-Week-Engine/main/assets/preload/data/flippy-roll/flippy-roll.json]], 7047986662, 'Flippy-Roll'},
finaldestination={[[https://raw.githubusercontent.com/GithubSPerez/shaggy-matt/main/assets/preload/data/final-destination/final-destination-god.json]], 7057969804 , 'Final Destination'},
nonsensical={[[https://raw.githubusercontent.com/X-XSardonyx/VSB-Scripts/main/nonsensical.json]], 7361704969, "Nonsensical"},
playtime={[[https://raw.githubusercontent.com/X-XSardonyx/VSB-Scripts/main/Playtime.json]], 7838052823,'Playtime'},
nohero={[[https://raw.githubusercontent.com/X-XSardonyx/VSB-Scripts/main/no-hero.json]], 7951754097, 'No-Hero'},
change={[[https://raw.githubusercontent.com/X-XSardonyx/VSB-Scripts/main/you'll-make-the-change-hard.json]], 8055850993, "Youll Make The Change"},
MONOCHROME = {[[https://raw.githubusercontent.com/Yoshubs/Hypnos-Lullaby/master/assets/preload/data/monochrome/monochrome.json]], 7860856702, "Monochrome"},
SUS = {[[https://raw.githubusercontent.com/Clowfoe/ImpostorWeek2/main/assets/preload/data/sussus-moogus/sussus-moogus-hard.json]], 6893222195,'sussus moogus'},
Ejected = {[[https://raw.githubusercontent.com/Clowfoe/ImpostorWeek2/main/assets/preload/data/ejected/ejected-hard.json]], 7358303663, 'Ejected'}
}

Complaints = {"WAAAAAAAAAAAAAA","VUL BAN HIM","Underaged!","I CAN SCIRPT","r/bfg","r/bad","Bruh","Skids","Cringe!?!?!","Shut up sard","qwerty ur a kid","LOL","BRO!","ew","MOD BAN HIM","reporting","CHARACTER MODIFICATION"}
goods = {"yay", "very pro", "beans" , "é", "HEHEHHEE", "new phone who dis", "😳😳", "cheese", "who you", "no."}

frame = Instance.new("Frame", Instance.new("ScreenGui", owner.PlayerGui))
frame.Size = UDim2.new(.25,0,.75,0)
frame.BackgroundTransparency = .9
frame.Position = UDim2.new(.375,0,.125,0)
num = 0

NUM = 0

for i,v in pairs(charts) do
NUM = NUM + 1
end

currentchart = nil

for I,v in pairs(charts) do
num = num + 1
button = Instance.new("TextButton",frame)
button.Size = UDim2.new(1,0,1/NUM,0)
button.BackgroundTransparency = .5
button.BackgroundColor = BrickColor.new("Really black")
button.TextColor = BrickColor.new("Institutional white")
button.TextScaled = true
button.BorderSizePixel = 0
button.Text = v[3]

button.Position = UDim2.new(0,0,num/NUM,0) - UDim2.new(0,0,1/NUM,0)

button.MouseButton1Click:Connect(function()
frame.Parent:Destroy()
currentchart = v
end)

end

repeat task.wait() until currentchart ~= nil

HTTP = game:GetService("HttpService")
Data = HTTP:JSONDecode(HTTP:GetAsync(currentchart[1]))
keys = Data.song.notes
bpm = Data.song.bpm

print(bpm)
print(Data.song.song)
print(currentchart[1])

Head = Model0.Torso.Neck
Torso = Model0.HumanoidRootPart.RootJoint
Larm = Model0.Torso["Left Shoulder"]
Rarm = Model0.Torso["Right Shoulder"]
Lleg = Model0.Torso["Left Hip"]
Rleg = Model0.Torso["Right Hip"]

AnimDefaults = {
Head = Head.C0,
Torso = Torso.C0,
Larm = Larm.C0,
Rarm = Rarm.C0,
Lleg = Lleg.C0,
Rleg = Rleg.C0,
}

IDLE = {

Head = AnimDefaults.Head * CFrame.Angles(math.rad(-5),0,math.rad(30)),
Torso = AnimDefaults.Torso * CFrame.Angles(math.rad(-10),0,0),
Larm = AnimDefaults.Larm * CFrame.new(-.5,0,0)*CFrame.Angles(0,math.rad(30),math.rad(130)),
Rarm = AnimDefaults.Rarm* CFrame.new(.5,0,0)*CFrame.Angles(0,math.rad(-30),math.rad(-130)),
Lleg = AnimDefaults.Lleg*CFrame.Angles(0,0,math.rad(10)),
Rleg = AnimDefaults.Rleg*CFrame.Angles(0,0,math.rad(-10))

}


DOWN = {

Head = AnimDefaults.Head * CFrame.Angles(0,0,math.rad(20)),
Torso = AnimDefaults.Torso * CFrame.Angles(0,0,math.rad(10)),
Larm = AnimDefaults.Larm * CFrame.Angles(0,0,math.rad(20)),
Rarm = AnimDefaults.Rarm * CFrame.Angles(0,0,math.rad(105)),
Lleg = AnimDefaults.Lleg * CFrame.Angles(0,0,math.rad(10)),
Rleg = AnimDefaults.Rleg * CFrame.Angles(0,0,math.rad(10))

}

LEFT = {

Head = AnimDefaults.Head * CFrame.Angles(0,0,math.rad(-10)),
Torso = AnimDefaults.Torso * CFrame.Angles(0,0,math.rad(-15)),
Larm = AnimDefaults.Larm * CFrame.Angles(0,0,math.rad(20)),
Rarm = AnimDefaults.Rarm * CFrame.Angles(0,math.rad(30),math.rad(105)),
Lleg = AnimDefaults.Lleg * CFrame.Angles(0,0,math.rad(-10)),
Rleg = AnimDefaults.Rleg * CFrame.Angles(0,0,math.rad(-10))

}

UP = {

Torso = AnimDefaults.Torso,
Head = AnimDefaults.Head,
Rarm = AnimDefaults.Rarm * CFrame.Angles(0,math.rad(45), math.rad(80)),
Larm = AnimDefaults.Larm *  CFrame.new(-.5,-.25,.5) * CFrame.Angles(0,math.rad(130), math.rad(80)),
Lleg = AnimDefaults.Lleg * CFrame.new(0,0,0) * CFrame.Angles(0,math.rad(15),0),
Rleg = AnimDefaults.Rleg * CFrame.new(0,0,0) *  CFrame.Angles(0,math.rad(0),0)
}

RIGHT = {

Torso = AnimDefaults.Torso * CFrame.new(0,0,0),
Rarm = AnimDefaults.Rarm * CFrame.new(.5,0,.5) * CFrame.Angles(0,math.rad(-90), math.rad(90)),
Larm = AnimDefaults.Larm *  CFrame.new(0,-.25,0) * CFrame.Angles(0,math.rad(10), math.rad(10)),
Lleg = AnimDefaults.Lleg * CFrame.new(0,0,0) * CFrame.Angles(0,math.rad(15),0),
Rleg = AnimDefaults.Rleg * CFrame.new(0,0,0) *  CFrame.Angles(0,math.rad(0),0),
Head = AnimDefaults.Head
}

TweenService = game:GetService("TweenService")
Speed = TweenInfo.new(.15)
Chat = game:GetService("Chat")
local resetC0 = false
Playing = false

function key(num)

Chat.BubbleChatEnabled = true
if gooduser == true then
Chat:Chat(Model0.Head, goods[math.random(1,#goods)])
else
Chat:Chat(Model0.Head, Complaints[math.random(1,#Complaints)])
end
if resetC0 == true then
Torso.C0 = AnimDefaults.Torso
Head.C0 = AnimDefaults.Head
Larm.C0 = AnimDefaults.Larm
Rarm.C0 = AnimDefaults.Rarm
Lleg.C0 = AnimDefaults.Lleg
Rleg.C0 = AnimDefaults.Rleg
end

if num == 0 then
TweenService:Create(Torso, Speed, {C0 = LEFT.Torso}):Play()
TweenService:Create(Head, Speed, {C0 = LEFT.Head}):Play()
TweenService:Create(Larm, Speed, {C0 = LEFT.Larm}):Play()
TweenService:Create(Rarm, Speed, {C0 = LEFT.Rarm}):Play()
TweenService:Create(Lleg, Speed, {C0 = LEFT.Lleg}):Play()
TweenService:Create(Rleg, Speed, {C0 = LEFT.Rleg}):Play()

elseif num == 1 then
TweenService:Create(Torso, Speed, {C0 = DOWN.Torso}):Play()
TweenService:Create(Head, Speed, {C0 = DOWN.Head}):Play()
TweenService:Create(Larm, Speed, {C0 = DOWN.Larm}):Play()
TweenService:Create(Rarm, Speed, {C0 = DOWN.Rarm}):Play()
TweenService:Create(Lleg, Speed, {C0 = DOWN.Lleg}):Play()
TweenService:Create(Rleg, Speed, {C0 = DOWN.Rleg}):Play()

elseif num == 2 then
TweenService:Create(Torso, Speed, {C0 = UP.Torso}):Play()
TweenService:Create(Head, Speed, {C0 = UP.Head}):Play()
TweenService:Create(Larm, Speed, {C0 = UP.Larm}):Play()
TweenService:Create(Rarm, Speed, {C0 = UP.Rarm}):Play()
TweenService:Create(Lleg, Speed, {C0 = UP.Lleg}):Play()
TweenService:Create(Rleg, Speed, {C0 = UP.Rleg}):Play()
elseif num == 3 then
TweenService:Create(Torso, Speed, {C0 = RIGHT.Torso}):Play()
TweenService:Create(Head, Speed, {C0 = RIGHT.Head}):Play()
TweenService:Create(Larm, Speed, {C0 = RIGHT.Larm}):Play()
TweenService:Create(Rarm, Speed, {C0 = RIGHT.Rarm}):Play()
TweenService:Create(Lleg, Speed, {C0 = RIGHT.Lleg}):Play()
TweenService:Create(Rleg, Speed, {C0 = RIGHT.Rleg}):Play()
end
end

local sound = Instance.new("Sound", Model0.HumanoidRootPart)
sound.SoundId = 'rbxassetid://'..currentchart[2]
sound.Volume = .05
sound.MaxDistance = 100
sound:Play()

wait(5)

sound.Volume = 1
sound:Play()

local NotOurTurn

for i = 1, #keys do

		sectionkeys = keys[i]["sectionNotes"]
		bpm = keys[i]["bpm"] or 0
		if not keys[i]["mustHitSection"] then
		for b = 1, #sectionkeys do
		NotOurTurn = false
			local what = sectionkeys[b]
			coroutine.wrap(function()
				task.wait(what[1]/1000)
				if what[2] == 0 then
					key(0)
				end
				if what[2] == 1 then
					key(1)
				end
				if what[2] == 2 then
					key(2)
				end
				if what[2] == 3 then
					key(3)
				end
			end)()
		end
		else
		for b = 1, #sectionkeys do
		NotOurTurn = true
			local what = sectionkeys[b]
			coroutine.wrap(function()
				task.wait(what[1]/1000)
				if what[2] == 4 then
					key(0)
				end
				if what[2] == 5 then
					key(1)
				end
				if what[2] == 6 then
					key(2)
				end
				if what[2] == 7 then
					key(3)
				end
			end)
		end
		end
	end



while true do

task.wait(bpm/100)
if NotOurTurn == true then
coroutine.wrap(function()
TweenService:Create(Torso, Speed, {C0 = IDLE.Torso * CFrame.Angles(math.rad(5),0,0)}):Play()
TweenService:Create(Head, Speed, {C0 = IDLE.Head * CFrame.Angles(math.rad(5),0,0)}):Play()
TweenService:Create(Larm, Speed, {C0 = IDLE.Larm * CFrame.new(0,-.2,0) * CFrame.Angles(math.rad(5),math.rad(5),math.rad(5))}):Play()
TweenService:Create(Rarm, Speed, {C0 = IDLE.Rarm * CFrame.new(0,-.2,0) * CFrame.Angles(math.rad(5),math.rad(5),math.rad(-5))}):Play()
TweenService:Create(Lleg, Speed, {C0 = IDLE.Lleg * CFrame.new(0,-.2,0) * CFrame.Angles(math.rad(5),math.rad(5),math.rad(-5))}):Play()
TweenService:Create(Rleg, Speed, {C0 = IDLE.Rleg * CFrame.new(0,-.2,0) * CFrame.Angles(math.rad(5),math.rad(5),math.rad(5))}):Play()

task.wait(.05)

TweenService:Create(Torso, Speed, {C0 = IDLE.Torso}):Play()
TweenService:Create(Head, Speed, {C0 = IDLE.Head}):Play()
TweenService:Create(Larm, Speed, {C0 = IDLE.Larm}):Play()
TweenService:Create(Rarm, Speed, {C0 = IDLE.Rarm}):Play()
TweenService:Create(Lleg, Speed, {C0 = IDLE.Lleg}):Play()
TweenService:Create(Rleg, Speed, {C0 = IDLE.Rleg}):Play()
end)()
end
end
