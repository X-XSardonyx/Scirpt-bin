local rem = Instance.new("RemoteEvent", owner.Character)
rem.Name = 'STAND'

local stand = Instance.new("Model", owner.Character)
local head = Instance.new("Part", stand)
local torso = Instance.new("Part", stand)
local la = Instance.new("Part", stand)
local ra = Instance.new("Part", stand)
local ll = Instance.new("Part", stand)
local rl = Instance.new("Part", stand)

head.Size = Vector3.new(1.25,1.25,1.25)
torso.Size = Vector3.new(2,2,1)
la.Size = Vector3.new(1,2,1)
ra.Size = Vector3.new(1,2,1)
ll.Size = Vector3.new(1,2,1)
rl.Size = Vector3.new(1,2,1)

local neck = Instance.new("Weld", torso)
neck.Part1 = torso
neck.Part0 = head
neck.C1 = CFrame.new(0,-.5,0)
neck.C0 = CFrame.new(0,-2,0) * CFrame.new(0,-.125,0)

local root = Instance.new("Weld", torso)
root.Part1 = torso
root.Part0 = owner.Character.HumanoidRootPart
root.C1 = CFrame.new(0,0,0)
root.C0 = CFrame.new(0,0,0)

local ls = Instance.new("Weld", torso)
ls.Part1 = torso
ls.Part0 = la
ls.C1 = CFrame.new(0,1,0)
ls.C0 = CFrame.new(1.5,1,0)

local rs = Instance.new("Weld", torso)
rs.Part1 = torso
rs.Part0 = ra
rs.C1 = CFrame.new(0,1,0)
rs.C0 = CFrame.new(-1.5,1,0)

local lh = Instance.new("Weld", torso)
lh.Part1 = torso
lh.Part0 = ll
lh.C1 = CFrame.new(0,1,0)
lh.C0 = CFrame.new(.5,3,0)

local rh = Instance.new("Weld", torso)
rh.Part1 = torso
rh.Part0 = rl
rh.C1 = CFrame.new(0,1,0)
rh.C0 = CFrame.new(-.5,3,0)

for i,v in pairs(stand:GetChildren()) do
if v:IsA("BasePart") then
v.Transparency = 1
v.CanCollide = false
v.Material = 'SmoothPlastic'
end
end

local animdefaults = {neck = neck.C0,root = root.C0,ls = ls.C0,rs = rs.C0}

summoned = false
sine = 1
attacking = false
barraging = false

function summon()
if attacking == false then
if summoned == false then
summoned = true
for i,v in pairs(stand:GetChildren()) do
if v:IsA("BasePart") then
game:GetService("TweenService"):Create(v,TweenInfo.new(1), {Transparency = 0}):Play()
end
end
else
summoned = false
for i,v in pairs(stand:GetChildren()) do
if v:IsA("BasePart") then
game:GetService("TweenService"):Create(v,TweenInfo.new(1), {Transparency = 1}):Play()
end
end
end
end
end

rem.OnServerEvent:Connect(function(plr, input, direction)
if direction == true then
if input == Enum.KeyCode.Q then
summon()
end
end
end)

NLS([[
local rem = owner.Character.STAND
local ui = game:GetService("UserInputService")
ui.InputBegan:Connect(function(input, gp)
if not gp then
rem:FireServer(input.KeyCode, true)
end
end)

ui.InputEnded:Connect(function(input, gp)
rem:FireServer(input.KeyCode, false)
end)

]], owner.Character)