local Prefix = '_'
local seperate = ' '
local admins = {owner.Name, "Owlv"}

local Players = game:GetService("Players")

local Sound = nil
wait(1)

function M(message)
for i,v in pairs(game.Players:GetPlayers()) do
local gui = Instance.new("ScreenGui", v.PlayerGui)
gui.IgnoreGuiInset = true
local textgui = Instance.new("TextLabel", gui)
textgui.Size = UDim2.new(.8,0,.1,0)
textgui.Position = UDim2.new(.1,0,-.1,0)
textgui.BackgroundColor3 = BrickColor.new("Black").Color
textgui.BorderSizePixel = 0
textgui.Text = message
textgui.TextScaled = true
textgui.TextColor = BrickColor.new("Institutional white")
textgui:TweenPosition(UDim2.new(.1,0,.15,0))
wait(3)
textgui:TweenPosition(UDim2.new(.1,0,-.1,0))
wait(1)
gui:Destroy()
end
end

function cmds(plr)

local cmds = {'music', 'pitch', 'volume', 'kill', 're', 'tp', 'admin', 'sit', 'explode', 'steal'}


local gui = Instance.new("ScreenGui", plr.PlayerGui)
local frame = Instance.new("Frame", gui)
frame.Size = UDim2.new(0,350,0,350)
frame.Position = UDim2.new(.45,0,.45,0)
frame.BackgroundColor3 = BrickColor.new("Really black").Color
frame.BackgroundTransparency = .75

frame.Draggable = true
frame.Selectable = true
frame.Active = true

local Exit = Instance.new("TextButton", frame)
Exit.Size = UDim2.new(.1,0,.1,0)
Exit.BackgroundColor3 = BrickColor.new("Really red").Color
Exit.Text = ''
Exit.BackgroundTransparency = .5
Exit.MouseButton1Click:Connect(function()
frame:TweenSize(UDim2.new(0,0,0,0))
wait(1)
gui:Destroy()
end)


local frame2 = Instance.new("ScrollingFrame", frame)
frame2.Size = UDim2.new(1,0,.9,0)
frame2.Position = UDim2.new(0,0,.1,0)
frame2.BackgroundColor3 = BrickColor.new("Really black").Color
frame2.BackgroundTransparency = .75
frame2.CanvasSize = UDim2.new(0,0,2,0)

for i,v in pairs(cmds) do
local box = Instance.new("TextLabel", frame2)
box.Size = UDim2.new(.8,0,.025,0)
box.Position = UDim2.new(0,0, i/12, 0)
box.BackgroundColor3 = BrickColor.new("Really black").Color
box.BackgroundTransparency = 1
box.Text = Prefix..v
box.TextScaled = true
box.TextColor = BrickColor.new("Pearl")
end
end

function giveadmin(plr)
print("Loaded X_X ADMIN Onto Player: "..plr.Name)
plr.Chatted:Connect(function(msg)
if string.find(msg, Prefix) then
local command = string.split(msg, seperate)

if command[2] == 'me' then
command[2] = plr.Name
end 

if command[3] == 'me' then
command[3] = plr.Name
end 

if command[2] then
for k,v in pairs(Players:GetPlayers()) do 
 if string.find(v.Name:lower(), command[2]:lower()) then
 command[2] = v.Name
 end  
 end
 end
 
if command[3] then
for k,v in pairs(Players:GetPlayers()) do 
 if string.find(v.Name:lower(), command[3]:lower()) then
 command[3] = v.Name
 end  
 end
end

if command[1] == Prefix..'music' then
Sound = Instance.new("Sound", workspace)
Sound.Looped = true
Sound.SoundId = 'rbxassetid://'..command[2]
Sound:Play()


elseif command[1] == Prefix..'volume' then
Sound.Volume = command[2]


elseif command[1] == Prefix..'pitch' then
Sound.Pitch = command[2]



elseif command[1] == Prefix..'sit' then
if game:GetService("Players"):FindFirstChild(command[2]) then
game:GetService("Players")[command[2]].Character.Humanoid.Sit = true
end
elseif command[1] == Prefix..'cmds' then
cmds(plr)




elseif command[1] == Prefix..'kill' then
if game:GetService("Players"):FindFirstChild(command[2]) then
game:GetService("Players")[command[2]].Character:BreakJoints()
end

elseif command[1] == Prefix..'steal' then
if game:GetService("Players"):FindFirstChild(command[2]) then
for i,v in pairs(game:GetService("Players"):FindFirstChild(command[2]).Backpack:GetChildren()) do
v:Clone().Parent = plr.Backpack
end
end


elseif command[1] == Prefix..'admin' then
if game:GetService("Players"):FindFirstChild(command[2]) then
giveadmin(game:GetService("Players")[command[2]])
end

elseif command[1] == Prefix..'tp' then
if game:GetService("Players"):FindFirstChild(command[2]) then

if game:GetService("Players"):FindFirstChild(command[3]) then

game:GetService("Players")[command[2]].Character:SetPrimaryPartCFrame(game:GetService("Players")[command[3]].Character.PrimaryPart.CFrame * CFrame.new(0,0,-5))

end

end


elseif command[1] == Prefix..'re' then
if game:GetService("Players"):FindFirstChild(command[2]) then
game:GetService("Players")[command[2]]:LoadCharacter()
end

elseif command[1] == Prefix..'explode' then
if game:GetService("Players"):FindFirstChild(command[2]) then
Instance.new("Explosion", Workspace).Position = game:GetService("Players")[command[2]].Character.PrimaryPart.Position
end


end
end

end)
end


for i,v in pairs(admins) do
if game:GetService("Players"):FindFirstChild(v) then

giveadmin(game:GetService("Players"):FindFirstChild(v))

end
end