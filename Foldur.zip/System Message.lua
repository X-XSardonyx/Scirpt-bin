function makebox(MSG)

for i,plr in pairs(game:GetService("Players"):GetPlayers()) do
coroutine.wrap(function()
local gui = Instance.new("ScreenGui", plr.PlayerGui)

local tb = Instance.new("TextBox", gui)

tb.Size = UDim2.new(.15,0,.05,0)
tb.BackgroundColor = BrickColor.new("Black")
tb.TextColor = BrickColor.new("Institutional white")
tb.TextEditable = false
tb.ClearTextOnFocus = false
tb.RichText = true
tb.TextScaled = true
tb.Position = UDim2.new(.425,0,-.2,0)
wait(.05)
tb.Text = MSG
tb.PlaceholderText = MSG

tb:TweenPosition(UDim2.new(.425,0,.15,0))

wait(string.len(MSG)/2)

tb:TweenPosition(UDim2.new(.425,0,-.2,0))

wait(1.5)

gui:Destroy()
end)()
end

end

replacements = {
{":skull:", "💀"},
{":flushed:", "😳"},
{":rage:", "😡"},
{":eyes:", "👀"},
{":weary:", "😩"},
{":clown:", '🤡'}
}

owner.Chatted:Connect(function(msg)
msg2 = string.split(msg, " ")
if string.lower(msg2[1]) == '-m' then

for i,v in pairs(replacements) do
rep = string.gsub(msg, v[1],v[2])
msg = rep
end

makebox(string.sub(msg,3,string.len(msg)))

end
end)

warn("-m Message")