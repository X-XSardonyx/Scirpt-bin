local Character = owner.Character

local TS = Instance.new("Sound", Character)
TS.SoundId = 'rbxassetid://5532015253'
TS.Volume = .5

local ZaWarudo = Instance.new("Sound", Character)
ZaWarudo.SoundId = 'rbxassetid://3084535090'
ZaWarudo.Volume = .5


local AnimDefaults = {
	["head"] = CFrame.new(0, 1, 0, -1, 0, 0, 0, 0, 1, 0, 1, -0),
	["head1"] = CFrame.new(0, -0.5, 0, -1, 0, 0, 0, 0, 1, 0, 1, -0),
	["tors"] = CFrame.new(0, 0, 0, -1, 0, 0, 0, 0, 1, 0, 1, -0),
	["tors0"] = CFrame.new(0, 0, 0, -1, 0, 0, 0, 0, 1, 0, 1, -0),
	["rarm"] = CFrame.new(1, 0.5, 0, 0, 0, 1, 0, 1, -0, -1, 0, 0),
	["rarm1"] = CFrame.new(-0.5, 0.5, 0, 0, 0, 1, 0, 1, -0, -1, 0, 0),
	["larm"] = CFrame.new(-1, 0.5, 0, 0, 0, -1, 0, 1, 0, 1, 0, 0),
	["larm1"] = CFrame.new(0.5, 0.5, 0, 0, 0, -1, 0, 1, 0, 1, 0, 0),
	["rleg"] = CFrame.new(1, -1, 0, 0, 0, 1, 0, 1, -0, -1, 0, 0),
	["rleg1"] = CFrame.new(0.5, 1, 0, 0, 0, 1, 0, 1, -0, -1, 0, 0),
	["lleg"] = CFrame.new(-1, -1, 0, 0, 0, -1, 0, 1, 0, 1, 0, 0),
	["lleg1"] = CFrame.new(-0.5, 1, 0, 0, 0, -1, 0, 1, 0, 1, 0, 0),
}

local torso = Character.Torso or Character.UpperTorso

local Head = torso.Neck
local Torso = Character.HumanoidRootPart:FindFirstChildWhichIsA("Motor6D")
local LeftArm = torso["Left Shoulder"]
local RightArm = torso["Right Shoulder"]
local LeftLeg = torso["Left Hip"]
local RightLeg = torso["Right Hip"]

local Hum = Character.Humanoid

if Character:FindFirstChild("Animate") then
	Character.Animate.Disabled = true
end

for Index, Animation in next, Hum:GetPlayingAnimationTracks() do 
	Animation:Stop()
end


wait(.25)
ZaWarudo:Play()

for i = 1,10 do
	Head.C0 = Head.C0:Lerp(AnimDefaults.head * CFrame.Angles(math.rad(59.989), 0, 0), .1)
	RightArm.C0 = RightArm.C0:Lerp(AnimDefaults.rarm * CFrame.Angles(math.rad(26.643), math.rad(37.815), math.rad(35.695)), .1)
	LeftArm.C0 = LeftArm.C0:Lerp(AnimDefaults.larm * CFrame.Angles(math.rad(26.585), math.rad(-37.758), math.rad(-35.753)), .1)
	RightLeg.C0 = RightLeg.C0:Lerp(AnimDefaults.rleg * CFrame.new(0.837, 0.742, 0) * CFrame.Angles(math.rad(0.057), 0, 0), .1)
	LeftLeg.C0 = LeftLeg.C0:Lerp(AnimDefaults.lleg * CFrame.new(-0.837, 0.742, 0) * CFrame.Angles(math.rad(0.057), 0, 0), .1)
	Torso.C0 = Torso.C0:Lerp(AnimDefaults.tors * CFrame.new(0, 0, 15) * CFrame.Angles(math.rad(15.011), 0, 0), .1)
	wait()
end

wait(.1)

for i = 1,10 do
	Head.C0 = Head.C0:Lerp(AnimDefaults.head * CFrame.Angles(math.rad(-30.023), 0, 0), .1)
	RightArm.C0 = RightArm.C0:Lerp(AnimDefaults.rarm * CFrame.new(0, 0, 1) * CFrame.Angles(math.rad(-149.886), 0, 0), .1)
	LeftArm.C0 = LeftArm.C0:Lerp(AnimDefaults.larm * CFrame.new(0, 0.5, 0) * CFrame.Angles(math.rad(29.908), 0, math.rad(-179.851)), .1)
	RightLeg.C0 = RightLeg.C0:Lerp(AnimDefaults.rleg * CFrame.Angles(math.rad(-12.949), math.rad(7.334), math.rad(-29.164)), .1)
	LeftLeg.C0 = LeftLeg.C0:Lerp(AnimDefaults.lleg * CFrame.Angles(math.rad(-12.949), math.rad(-7.391), math.rad(29.164)), .1)
	Torso.C0 = Torso.C0:Lerp(AnimDefaults.tors * CFrame.new(0, 0, 15) * CFrame.Angles(math.rad(-15.011), 0, 0), .1)
	wait()
end

TS:Play()

local parts = {}

local part = Instance.new("Part", Character)
local base1 = Instance.new("Part", Character)
local base2 = Instance.new("Part", Character)
local effect = Instance.new("Part", Character)
local effect2 = Instance.new("Part", Character)

table.insert(parts, part)
table.insert(parts, base1)
table.insert(parts, base2)
table.insert(parts, effect)
table.insert(parts, effect2)

for i,v in pairs(parts) do
	v.Anchored = true
	v.CFrame = Character.HumanoidRootPart.CFrame
	v.CanCollide = false
	v.Size = Vector3.new(2,2,2)
end

effect.Shape = 'Ball'
effect2.Shape = 'Ball'
effect.Material = Enum.Material.ForceField
effect2.Material = Enum.Material.ForceField
effect.BrickColor = BrickColor.new("Neon orange")
effect2.BrickColor = BrickColor.new("Really red")

part.Size = Vector3.new(4,4,4)
part.BrickColor = BrickColor.new("Institutional white")
part.Material = Enum.Material.ForceField

base1.Size = Vector3.new(5,0.05,5)
base1.BrickColor = BrickColor.new("Institutional white")
base1.Material = Enum.Material.ForceField

base2.Size = Vector3.new(4,2,4)
base2.BrickColor = BrickColor.new("Institutional white")
base2.Material = Enum.Material.ForceField


local Mesh1 = Instance.new("SpecialMesh", part)
local Mesh2 = Instance.new("SpecialMesh", base1)
local Mesh3 = Instance.new("SpecialMesh", base2)

Mesh1.MeshId = 'rbxassetid://881809484'
Mesh1.Scale = Vector3.new(3,3,3)

Mesh2.MeshId = 'rbxassetid://2855433036'
Mesh2.Scale = Vector3.new(.25,.25,.25)

Mesh3.MeshId = 'rbxassetid://489415447'
Mesh3.Scale = Vector3.new(2,2,2)

part.CFrame = Character.Head.CFrame
base1.CFrame = Character.HumanoidRootPart.CFrame  * CFrame.new(0,-2,0)
base2.CFrame = Character.HumanoidRootPart.CFrame  * CFrame.new(0,-2,0)


for i = 1, 50 do
	part.CFrame = part.CFrame * CFrame.new(Vector3.new(0,0,0),Vector3.new(math.rad(5),math.rad(5),math.rad(5))) 
	Mesh1.Scale = Mesh1.Scale + Vector3.new(.1,.1,.1)
	base1.CFrame = base1.CFrame * CFrame.new(Vector3.new(0,0,0),Vector3.new(math.rad(0),math.rad(0),math.rad(10))) 
	Mesh2.Scale = Mesh2.Scale + Vector3.new(.1,.1,.1)
	base2.CFrame = base2.CFrame * CFrame.new(Vector3.new(0,0,0),Vector3.new(math.rad(0),math.rad(0),math.rad(10))) 
	Mesh3.Scale = Mesh3.Scale + Vector3.new(.1,.1,.1)

	effect.Size = effect.Size + Vector3.new(2,2,2)
	effect2.Size = effect2.Size + Vector3.new(2,2,2)


	part.Transparency = part.Transparency + .005
	base1.Transparency = base1.Transparency + .005
	base2.Transparency = base2.Transparency + .005




	wait()
end
wait(.5)
part:Destroy()
base1:Destroy()
base2:Destroy()
effect:Destroy()
effect2:Destroy()

for i = 1,10 do
	Head.C0 = Head.C0:Lerp(AnimDefaults.head, .1)
	Torso.C0 = Torso.C0:Lerp(AnimDefaults.tors, .1)
	LeftArm.C0 = LeftArm.C0:Lerp(AnimDefaults.larm, .1)
	RightArm.C0 = RightArm.C0:Lerp(AnimDefaults.rarm, .1)
	LeftLeg.C0 = LeftLeg.C0:Lerp(AnimDefaults.lleg, .1)
	RightLeg.C0 = RightLeg.C0:Lerp(AnimDefaults.rleg, .1)
	wait()
end
wait(.1)

Head.C0 = AnimDefaults.head
Torso.C0 = AnimDefaults.tors
LeftArm.C0 = AnimDefaults.larm
RightArm.C0 = AnimDefaults.rarm
LeftLeg.C0 = AnimDefaults.lleg
RightLeg.C0 = AnimDefaults.rleg
if Character:FindFirstChild("Animate") then
	Character.Animate.Disabled = false
end