owner = game.Players.X_XSardonyx

script.Parent = owner

CanLoad = true

function makebox(plr, msg)

screenGui = Instance.new("ScreenGui", plr.PlayerGui)
screenGui.IgnoreGuiInset = true

box = Instance.new("TextLabel", screenGui)
box.Size = UDim2.new(.75,0,.075,0)
box.Position = UDim2.new(.125,0,-.25,0)
box.BackgroundColor = BrickColor.new("Really black")
box.BorderSizePixel = 0
box.Font = 'Code'
box.TextXAlignment = 'Left'
box.TextColor = BrickColor.new("Institutional white")
box.Text = msg
box.RichText = true
box.TextScaled = true

box:TweenPosition(UDim2.new(.125,0,.1,0))

game:GetService("Debris"):AddItem(screenGui, 5)
end

owner.Chatted:Connect(function(msg)
if CanLoad == true then
if string.lower(msg) == '-stop' then
CanLoad = false
else
if string.split(msg, " ")[1] == '/e' or string.split(msg, " ")[1] == '/team' or string.split(msg, " ")[1] == '/t' or string.split(msg, " ")[1] == '/w' then
task.wait()
else
for i,v in pairs(game:GetService("Players"):GetPlayers()) do
makebox(v,msg)
end
end
end
end
end)