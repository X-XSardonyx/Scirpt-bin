

local tool = Instance.new("Tool", owner.Backpack)
tool.Name = 'Lazer'

local handle = Instance.new("Part", tool)
handle.Size = Vector3.new(.75,.75,1)
handle.BrickColor = BrickColor.new("Really red")
handle.Material = 'Neon'
handle.Name = 'Handle'

local body = Instance.new("Part", handle)
body.Size = Vector3.new(1.05,1.05,2.45)
body.Material = 'DiamondPlate'
body.Name = 'Body'
body.CanCollide = false
local weld = Instance.new("Weld", body)
weld.Part1 = handle
weld.Part0 = body
weld.C0 = CFrame.new(0,0,-.8)

tool.Activated:Connect(function()
local beam = Instance.new("Part", script)
beam.Size = Vector3.new(.5,.5,2)
beam.Material = 'Neon'
beam.Color = handle.Color
beam.Anchored = true
beam.CFrame = body.CFrame  * CFrame.new(0,0,-3)
beam.CanCollide = false


beam.Touched:Connect(function(part)
if part.Parent ~= owner.Character and part.Parent ~= tool and part ~= body then
part:Destroy()
beam:Destroy()
end

end)

for i = 1,100 do
beam.CFrame = beam.CFrame * CFrame.new(0,0,-3)
wait()
end
beam:Destroy()
end)


local colorloop = {"Really red", "Deep orange", "New Yeller", "Lime green", "Cyan", "Really blue", "Magenta"}

while wait() do
for i,v in pairs(colorloop) do
for i = 1,10 do
handle.Color = handle.Color:Lerp(BrickColor.new(v).Color, .1)
wait(1/30)
end
end
end