local pacman = Instance.new("Part", Instance.new("WorldModel", script))
pacman.Size = Vector3.new(5,5,5)
pacman.Material = 'SmoothPlastic'
pacman.Locked = true
pacman.Anchored = true
pacman.CanCollide = false
pacman.Shape = 'Ball'
pacman.BrickColor = BrickColor.new("New Yeller")

local wedge = Instance.new("WedgePart", pacman.Parent)
wedge.Size = Vector3.new(7 ,4,4)
wedge.CFrame = CFrame.new(0,0,-3) * CFrame.Angles(math.rad(-45),0,0)
wedge.Anchored = true

local Pac = pacman:SubtractAsync({wedge})
Pac.Parent = pacman.Parent
Pac.Position = Vector3.new(0,2.5,0)

wedge:Destroy()

pacman.Transparency = 1

local sound = Instance.new("Sound", Pac)
sound.SoundId = 'rbxassetid://182129114'
sound.Looped = true

owner.Character.Parent = owner
local humanoid = owner.Character.Humanoid

game:GetService("RunService").Heartbeat:Connect(function()

Pac.Position = Pac.Position + humanoid.MoveDirection


owner.Character:SetPrimaryPartCFrame(Pac.CFrame)

if humanoid.MoveDirection.Magnitude > 0 then
Pac.CFrame = CFrame.new(Pac.Position, Pac.Position + humanoid.MoveDirection)

if math.cos(tick()*10) > 0 then
pacman.Transparency = 1
else
pacman.Transparency = 0
end

else
pacman.Transparency = 0
end

pacman.CFrame = Pac.CFrame * CFrame.new(0,0,-.5)

end)

while wait(1) do
if humanoid.MoveDirection.Magnitude > 0 then
sound:Play()
else
sound:Pause()
end
end