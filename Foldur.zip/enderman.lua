for i,v in pairs(owner.Character:GetChildren()) do
if v:IsA("Shirt") or v:IsA("Pants") or v:IsA("CharacterMesh") or v:IsA("Hat") or v:IsA("Accessory") or v:IsA("ShirtGraphic") or v:IsA("Decal") or v:IsA("Texture") or v:IsA("SpecialMesh") then
v:Destroy()
elseif v:IsA("BasePart") then
v.BrickColor = BrickColor.new("Really black")
v.Material = 'SmoothPlastic'
Instance.new("BlockMesh", v)
end
end

owner.Character["Left Arm"].Size = Vector3.new(.5,3,.5)
owner.Character["Right Arm"].Size = Vector3.new(.5,3,.5)
owner.Character["Left Leg"].Size = Vector3.new(.5,3,.5)
owner.Character["Right Leg"].Size = Vector3.new(.5,3,.5)
owner.Character["Torso"].Size = Vector3.new(1.5,2,.5)
owner.Character["Head"].Size = Vector3.new(1.5,1.5,1.5)

owner.Character.Head:ClearAllChildren()


hrpcf = owner.Character.HumanoidRootPart.CFrame

owner.Character.HumanoidRootPart:Destroy()

owner.Character.Humanoid:Destroy()

local newchar = Instance.new("Model", script)

for i,v in pairs(owner.Character:GetDescendants()) do

if v:IsA("Motor6D") then
v:Destroy()
elseif v:IsA("BasePart") then
v:SetNetworkOwner(owner)
v.CanTouch = false
v.CanCollide = true
end

end

for i,v in pairs(owner.Character:GetChildren()) do
v.Parent = newchar
end

local value = Instance.new("ObjectValue", owner.PlayerGui)
value.Value = newchar
value.Name = 'SCRIPT_VALUE'

local humanoidrootpart = Instance.new("Part", owner.Character)
humanoidrootpart.Size = Vector3.new(2,2,1)
humanoidrootpart.CFrame = hrpcf
humanoidrootpart.Name = 'HumanoidRootPart'
humanoidrootpart.Transparency = 1

owner.Character.PrimaryPart = humanoidrootpart

Instance.new("Humanoid", owner.Character)

local Larm = newchar["Left Arm"]
local Rarm= newchar["Right Arm"]
local Lleg = newchar["Left Leg"]
local Rleg = newchar["Right Leg"]
local Head = newchar["Head"]


local eye1 = Instance.new("Part", Head)
eye1.Size = Vector3.new(.4,.25,.25)
eye1.CanCollide = false
eye1.Massless = false
eye1.Material = 'Neon'
eye1.BrickColor = BrickColor.new("Sunrise")
eye1:SetNetworkOwner(owner)

local weld1 = Instance.new("Weld", eye1)
weld1.Part1 = eye1
weld1.Part0 = Head
weld1.C0 = CFrame.new(.3,0,-.75)

local eye2 = Instance.new("Part", Head)
eye2.Size = Vector3.new(.4,.25,.25)
eye2.CanCollide = false
eye2.Massless = false
eye2.Material = 'Neon'
eye2.BrickColor = BrickColor.new("Sunrise")
eye2:SetNetworkOwner(owner)

local weld2 = Instance.new("Weld", eye2)
weld2.Part1 = eye2
weld2.Part0 = Head
weld2.C0 = CFrame.new(-.3,0,-.75)

NLS([[

local CurrentAnim = 'IDLE'

model = script.Parent.Value

local Head = model.Head
local Torso = model.Torso
local Larm = model["Left Arm"]
local Rarm= model["Right Arm"]
local Lleg = model["Left Leg"]
local Rleg = model["Right Leg"]

local campart = Instance.new("Part")

workspace.CurrentCamera.CameraSubject = campart

for i,v in pairs({Head,Torso,Larm,Rarm,Lleg,Rleg}) do
v.CanCollide = false
local pos = Instance.new("BodyPosition", v)
pos.MaxForce = Vector3.new(math.huge,math.huge,math.huge)
pos.P = 150000
pos.D = 1000

local gy = Instance.new("BodyGyro", v)
gy.MaxTorque= Vector3.new(math.huge,math.huge,math.huge)
gy.P = 150000
gy.D = 1000

end

sine = 0
HRP = owner.Character.HumanoidRootPart

owner.Character.Humanoid.HipHeight = 2.5
owner.Character.Humanoid.JumpPower = 50

game:GetService("RunService").Heartbeat:Connect(function()
sine = sine + .2

campart.CFrame = campart.CFrame:Lerp(Head.CFrame, .25)

if CurrentAnim == 'IDLE' then

if HRP.Velocity.Magnitude > 1 then

TorsoCF = HRP.CFrame
Torso.BodyPosition.Position = TorsoCF.Position
Torso.BodyGyro.CFrame = TorsoCF

HeadCF = HRP.CFrame * CFrame.new(0,1.75,0)
Head.BodyPosition.Position = HeadCF.Position
Head.BodyGyro.CFrame = HeadCF

LarmCF = HRP.CFrame * CFrame.new(1,1,0)  * CFrame.Angles(math.rad(math.sin(sine) * 45),0,0) * CFrame.new(0,-1.5,0)
Larm.BodyPosition.Position = LarmCF.Position
Larm.BodyGyro.CFrame = LarmCF

RarmCF = HRP.CFrame * CFrame.new(-1,1,0) *CFrame.Angles(-math.rad(math.sin(sine) * 45),0, 0) * CFrame.new(0,-1.5,0)
Rarm.BodyPosition.Position = RarmCF.Position
Rarm.BodyGyro.CFrame = RarmCF

LlegCF= HRP.CFrame * CFrame.new(.5,-1,0) * CFrame.Angles(-math.rad(math.sin(sine)*30),0,0)* CFrame.new(0,-1.5,0)
Lleg.BodyPosition.Position = LlegCF.Position
Lleg.BodyGyro.CFrame = LlegCF

RlegCF = HRP.CFrame * CFrame.new(-.5,-1,0) * CFrame.Angles(math.rad(math.sin(sine)*30),0,0)* CFrame.new(0,-1.5,0)
Rleg.BodyPosition.Position = RlegCF.Position
Rleg.BodyGyro.CFrame = RlegCF

else

TorsoCF = HRP.CFrame
Torso.BodyPosition.Position = TorsoCF.Position
Torso.BodyGyro.CFrame = TorsoCF

HeadCF = HRP.CFrame * CFrame.new(0,1.75,0)
Head.BodyPosition.Position = HeadCF.Position
Head.BodyGyro.CFrame = HeadCF

LarmCF = HRP.CFrame * CFrame.new(1,1,0)  * CFrame.Angles(math.rad(math.sin(sine/5) * 5),0,0) * CFrame.new(0,-1.5,0)
Larm.BodyPosition.Position = LarmCF.Position
Larm.BodyGyro.CFrame = LarmCF

RarmCF = HRP.CFrame * CFrame.new(-1,1,0) *CFrame.Angles(-math.rad(math.sin(sine/5) * 5),0, 0) * CFrame.new(0,-1.5,0)
Rarm.BodyPosition.Position = RarmCF.Position
Rarm.BodyGyro.CFrame = RarmCF

LlegCF= HRP.CFrame * CFrame.new(.5,-1,0) * CFrame.Angles(-math.rad(math.sin(sine/5)*5),0,0)* CFrame.new(0,-1.5,0)
Lleg.BodyPosition.Position = LlegCF.Position
Lleg.BodyGyro.CFrame = LlegCF

RlegCF = HRP.CFrame * CFrame.new(-.5,-1,0) * CFrame.Angles(math.rad(math.sin(sine/5)*5),0,0)* CFrame.new(0,-1.5,0)
Rleg.BodyPosition.Position = RlegCF.Position
Rleg.BodyGyro.CFrame = RlegCF

if owner.Character.Humanoid.Sit then

LlegCF= HRP.CFrame * CFrame.new(.5,-1,0) * CFrame.Angles(math.rad(90),0,0) * CFrame.new(0,-1.5,0)
Lleg.BodyPosition.Position = LlegCF.Position
Lleg.BodyGyro.CFrame = LlegCF

RlegCF = HRP.CFrame * CFrame.new(-.5,-1,0) * CFrame.Angles(math.rad(90),0,0) * CFrame.new(0,-1.5,0)
Rleg.BodyPosition.Position = RlegCF.Position
Rleg.BodyGyro.CFrame = RlegCF

end

end
end

end)

game:GetService("UserInputService").InputBegan:Connect(function(input, gp)
if not gp then
if input.KeyCode == Enum.KeyCode.Space then
owner.Character.Humanoid.Jump = true
end
end
end)

owner.Chatted:Connect(function(msg)
if string.lower(msg) == '-anim tpose' then
CurrentAnim = 'TPOSE'
elseif string.lower(msg) == '-stopanim' then
CurrentAnim = 'IDLE'
end
end)

]], value)