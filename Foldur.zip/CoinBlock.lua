pos = owner.Character.HumanoidRootPart.Position + Vector3.new(0,10,0)

local block = Instance.new("Part", script)
block.Size = Vector3.new(3,3,3)
block.Anchored = true
block.Position = pos
block.BrickColor = BrickColor.new("Bright yellow")

local collision = Instance.new("Part", block)
collision.Size = Vector3.new(1,1,1)
collision.Transparency = 1
collision.Position = pos - Vector3.new(0,1.5,0)
collision.Anchored = true
collision.CanCollide = false

sound = Instance.new("Sound", block)
sound.SoundId = 'rbxassetid://2225156563'
sound.MaxDistance = 100
sound.Volume = 2

local mesh = Instance.new("SpecialMesh", block)
mesh.MeshType = 'FileMesh'
mesh.MeshId = 'rbxassetid://435368892'
mesh.Scale = Vector3.new(.04,.04,.04)

local MS = Instance.new("SpecialMesh", collision)
MS.MeshType = 'FileMesh'
MS.MeshId = 'rbxasset://Fonts//RightArm.Mesh'

local Num = 10

local db = false

collision.Touched:Connect(function()
if not db then
db = true

Num = Num - 1

if Num == 0 then
game:GetService("TweenService"):Create(block, TweenInfo.new(.1), {Position = pos + Vector3.new(0,1.5,0)}):Play()

wait(.1)

game:GetService("TweenService"):Create(block, TweenInfo.new(.1), {Position = pos}):Play()

block.BrickColor = BrickColor.new("CGA brown")
mesh.MeshId = 'rbxasset://Fonts//RightArm.Mesh'
mesh.Scale = Vector3.new(3,1.5,3)
end

if Num > 0 then

local coin = Instance.new("Part", script)
coin.Size = Vector3.new(.25,2,2)
coin.CFrame = CFrame.new(pos) * CFrame.Angles(math.rad(90),0,0)
coin.Shape = 'Cylinder'
coin.BrickColor = BrickColor.new("New Yeller")
coin.Anchored = true
coin.Material = 'Metal'

sound:Play()

game:GetService("Debris"):AddItem(coin, .5)

game:GetService("TweenService"):Create(block, TweenInfo.new(.1), {Position = pos + Vector3.new(0,1.5,0)}):Play()
game:GetService("TweenService"):Create(coin, TweenInfo.new(.3), {CFrame = CFrame.new(pos + Vector3.new(0,5,0)) * CFrame.Angles(math.rad(90),0,math.rad(180))}):Play()

wait(.1)

game:GetService("TweenService"):Create(block, TweenInfo.new(.1), {Position = pos}):Play()

wait(.25)
db = false
end
end
end)