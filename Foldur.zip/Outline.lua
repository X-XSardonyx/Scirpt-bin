local owner = game.Players.Alfie1728

for i,v in pairs({owner.Character["Left Arm"],owner.Character["Right Arm"],owner.Character["Left Leg"],owner.Character["Right Leg"]}) do
local outline = Instance.new("Part", v)
outline.Size = v.Size
outline.CanCollide = false
outline.Locked = true
outline.BrickColor = BrickColor.new("Really black")

weld = Instance.new("Weld", outline)
weld.Part1 = outline
weld.Part0 = v

mesh = Instance.new("SpecialMesh", outline)
mesh.MeshId = 'rbxasset://Fonts//RightLeg.mesh'
mesh.MeshType = 'FileMesh'
mesh.Scale = Vector3.new(-1.1,1.1,1.1)
end

local outline = Instance.new("Part", owner.Character.Torso)
outline.Size = owner.Character.Torso.Size
outline.CanCollide = false
outline.Locked = true
outline.BrickColor = BrickColor.new("Really black")

weld = Instance.new("Weld", outline)
weld.Part1 = outline
weld.Part0 = owner.Character.Torso

mesh = Instance.new("SpecialMesh", outline)
mesh.MeshId = 'rbxasset://Fonts//Torso.mesh'
mesh.MeshType = 'FileMesh'
mesh.Scale = Vector3.new(-1.1,1.1,1.1)

local outline = Instance.new("Part", owner.Character.Head)
outline.Size = owner.Character.Head.Size
outline.CanCollide = false
outline.Locked = true
outline.BrickColor = BrickColor.new("Really black")

weld = Instance.new("Weld", outline)
weld.Part1 = outline
weld.Part0 = owner.Character.Head

mesh = Instance.new("SpecialMesh", outline)
mesh.Scale = Vector3.new(1.4,-1.4,-1.4)
