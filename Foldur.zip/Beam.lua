local rem = Instance.new("RemoteEvent", owner.Character)
rem.Name = 'BEAM'

NLS("owner:GetMouse().KeyDown:Connect(function(key) if key == 'e' then owner.Character.BEAM:FireServer(owner:GetMouse().Hit.Position) end end)", owner.Character)

rem.OnServerEvent:Connect(function(plr, mousepos)

local MAGNITUDE = (owner.Character.HumanoidRootPart.Position - mousepos).Magnitude

if MAGNITUDE < 1000 then

local beampart = Instance.new("Part", script)
beampart.Anchored = true
beampart.Material = 'ForceField'
beampart.BrickColor = BrickColor.new("Really red")
beampart.CFrame = CFrame.new(owner.Character.HumanoidRootPart.CFrame * CFrame.new(0,0,-5).Position, mousepos)
beampart.Position = beampart.Position:Lerp(mousepos, .5)
beampart.CanCollide = false
beampart.Size = Vector3.new(10,10,MAGNITUDE)
game:GetService'Debris':AddItem(beampart, 1)

local bg = beampart:Clone()
bg.Parent = beampart
bg.BrickColor = BrickColor.new("New Yeller")
bg.Material = 'SmoothPlastic'
bg.Size = bg.Size - Vector3.new(3,3,1)

beampart.Touched:Connect(function(part)
if part.Parent ~= owner.Character and part.Parent:FindFirstChild("Humanoid") then
part.Parent:FindFirstChild("Humanoid"):TakeDamage(10)
end

end)

game:GetService'RunService'.Heartbeat:Connect(function()
beampart.Size = beampart.Size:Lerp(Vector3.new(0,0,beampart.Size.Z), .1)
bg.Size = bg.Size:Lerp(Vector3.new(0,0,bg.Size.Z), .1)

end)
end
end)