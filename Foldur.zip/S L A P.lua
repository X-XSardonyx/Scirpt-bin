local db = false
Instance.new("ForceField", owner.Character).Visible = false

local head = Instance.new("Weld", owner.Character.Head)
head.Part1 = owner.Character.Torso.Neck.Part1
head.Part0 = owner.Character.Torso.Neck.Part0
head.C1 = owner.Character.Torso.Neck.C1
head.C0 = owner.Character.Torso.Neck.C0
head.Enabled = false

local torso = Instance.new("Weld", owner.Character.Torso)
torso.Part1 = owner.Character.HumanoidRootPart.RootJoint.Part1
torso.Part0 = owner.Character.HumanoidRootPart.RootJoint.Part0
torso.C1 = owner.Character.HumanoidRootPart.RootJoint.C1
torso.C0 = owner.Character.HumanoidRootPart.RootJoint.C0
torso.Enabled = false

local larm = Instance.new("Weld", owner.Character.Torso)
larm.Part1 = owner.Character.Torso["Left Shoulder"].Part1
larm.Part0 = owner.Character.Torso["Left Shoulder"].Part0
larm.C1 = owner.Character.Torso["Left Shoulder"].C1
larm.C0 = owner.Character.Torso["Left Shoulder"].C0
larm.Enabled = false

local rarm = Instance.new("Weld", owner.Character.Torso)
rarm.Part1 = owner.Character.Torso["Right Shoulder"].Part1
rarm.Part0 = owner.Character.Torso["Right Shoulder"].Part0
rarm.C0 = owner.Character.Torso["Right Shoulder"].C0
rarm.C1 = owner.Character.Torso["Right Shoulder"].C1
rarm.Enabled = false

local lleg = Instance.new("Weld", owner.Character.Torso)
lleg.Part1 = owner.Character.Torso["Left Hip"].Part1
lleg.Part0 = owner.Character.Torso["Left Hip"].Part0
lleg.C1 = owner.Character.Torso["Left Hip"].C1
lleg.C0 = owner.Character.Torso["Left Hip"].C0
lleg.Enabled = false

local rleg = Instance.new("Weld", owner.Character.Torso)
rleg.Part1 = owner.Character.Torso["Right Hip"].Part1
rleg.Part0 = owner.Character.Torso["Right Hip"].Part0
rleg.C1 = owner.Character.Torso["Right Hip"].C1
rleg.C0 = owner.Character.Torso["Right Hip"].C0
rleg.Enabled = false

local AnimDefaults = {
torso = torso.C0,
head = head.C0,
larm = larm.C0,
rarm = rarm.C0,
lleg = lleg.C0,
rleg = rleg.C0,

}

local name = Instance.new("BillboardGui", owner.Character.Head)
name.Size = UDim2.fromScale(2,4)
name.StudsOffset = Vector3.new(0,5,0)
name.MaxDistance = 200
local tb = Instance.new("TextBox", name)
tb.Size = UDim2.new(1,0,1,0)
tb.BackgroundTransparency = 1
tb.TextSize = 15
tb.TextYAlignment = 'Top'
tb.TextColor = BrickColor.White()
tb.Text = ' '

local slap = Instance.new("Sound", owner.Character.HumanoidRootPart)
slap.SoundId = 'rbxassetid://5189782994'
slap.Volume = 5
slap.Pitch = 3
slap.MaxDistance = 100

function SLAP()
slap.Pitch = 3
arm = owner.Character["Right Arm"]
slap:Play()
db = true
torso.Enabled = true
head.Enabled = true
larm.Enabled = true
rarm.Enabled = true
lleg.Enabled = true
rleg.Enabled = true

game:GetService("TweenService"):Create(torso,TweenInfo.new(.15),{C0 = AnimDefaults.torso * CFrame.new(0,-1,0) * CFrame.Angles(math.rad(20),0,math.rad(20))}):Play()
game:GetService("TweenService"):Create(rarm,TweenInfo.new(.15),{C0 = AnimDefaults.rarm * CFrame.new(0,0,0) * CFrame.Angles(math.rad(20),0,math.rad(110))}):Play()
game:GetService("TweenService"):Create(larm,TweenInfo.new(.15),{C0 = AnimDefaults.larm * CFrame.new(0,0,0) * CFrame.Angles(math.rad(-20),0,math.rad(0))}):Play()

wait(.15)
arm.Touched:Connect( function()end)
for i,v in pairs(arm:GetTouchingParts()) do
if v.Parent ~= owner.Character then
for i,v in pairs(v.Parent:GetDescendants()) do
if v:IsA("BasePart") then
v:BreakJoints()
v.Velocity = -CFrame.new(v.Position, owner.Character.HumanoidRootPart.Position).LookVector * 300
end
end
end
end

torso.Enabled = false
head.Enabled = false
larm.Enabled = false
rarm.Enabled = false
lleg.Enabled = false
rleg.Enabled = false
db = false
end

function MSG(text, soundid)
db = true
slap.SoundId = 'rbxassetid://'..soundid
slap.Pitch = 1
slap:Play()
for i = 1,string.len(text) do
local currentchar = string.sub(text, i - 1,i)
tb.Text = string.sub(text,0,i)
wait(.1)
end
wait(1.5)
db = false
slap:Stop()
slap.SoundId = 'rbxassetid://'..5189782994
tb.Text = ' '
end

local rem = Instance.new("RemoteEvent", owner.Character)
rem.Name = 'SLAP'


rem.OnServerEvent:Connect(function(plr, key, target)
if db == false and key == 'e' then
SLAP()
elseif db == false and key == 'r' then
MSG([[Ok 19 dolla fornite card. Who wants it? and yes im giving it away.]], 6258381459)
elseif db == false and key == 'f' then
if target:IsA("BasePart") then
if target.Parent:FindFirstChildWhichIsA("Humanoid") ~= nil then
target.Parent.PrimaryPart.Anchored = true
owner.Character.HumanoidRootPart.Anchored = true
owner.Character:SetPrimaryPartCFrame(target.Parent.PrimaryPart.CFrame * CFrame.new(0,0,2))
MSG([[*Teleports behind you cutely*]], 341397163)
SLAP()
owner.Character.HumanoidRootPart.Anchored = false
end
end
elseif db == false and key == 'g' then
MSG("*angry noises*", 2618158728)
elseif db == false and key == 't' then
MSG("*Trumpet* HeY1!?11", 610086544)
elseif db == false and key == 'y' then
MSG("Oh YEaH YeAh Oh Yeah YEaH", 2930283498)
end
end)

NLS([[local rem = script.Parent

owner:GetMouse().KeyDown:Connect(function(key)
rem:FireServer(key, owner:GetMouse().Target)
end)
]], rem)