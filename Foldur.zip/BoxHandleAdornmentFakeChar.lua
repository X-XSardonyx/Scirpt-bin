Character = owner.Character
local Y = Character.HumanoidRootPart.Position.Y+20
humanoid = owner.Character.Humanoid
sine = 1
jumpDB = false

if Y == 0 then
jumpDB = false
else
jumpDB = true

coroutine.wrap(function()
repeat task.wait() Y=math.clamp(Y-.75,0,100000000000000000) until Y < .1
end)()

end

local Anchor = Instance.new("Part", script)
Anchor.Transparency = 1
Anchor.CanCollide = false
Anchor.Anchored = true
Anchor.Position = Vector3.new(0,0,0)

local hum = Instance.new("BoxHandleAdornment", Anchor)
hum.Size = Vector3.new(2,2,1)
hum.Adornee = Anchor
hum.CFrame = CFrame.new(0,Y,0)
hum.Color = BrickColor.new("Really blue")

local Head = Instance.new("BoxHandleAdornment", Anchor)
Head.Size = Vector3.new(1.25,1.25,1.25)
Head.Adornee = Anchor
Head.Color = BrickColor.new("Bright yellow")

local Larm = Instance.new("BoxHandleAdornment", Anchor)
Larm.Size = Vector3.new(1,2,1)
Larm.Adornee = Anchor
Larm.Color = BrickColor.new("Bright yellow")

local Rarm = Instance.new("BoxHandleAdornment", Anchor)
Rarm.Size = Vector3.new(1,2,1)
Rarm.Adornee = Anchor
Rarm.Color = BrickColor.new("Bright yellow")

local Rleg= Instance.new("BoxHandleAdornment", Anchor)
Rleg.Size = Vector3.new(1,2,1)
Rleg.Adornee = Anchor
Rleg.Color = BrickColor.new("Camo")

local Lleg= Instance.new("BoxHandleAdornment", Anchor)
Lleg.Size = Vector3.new(1,2,1)
Lleg.Adornee = Anchor
Lleg.Color = BrickColor.new("Camo")

local leye= Instance.new("BoxHandleAdornment", Anchor)
leye.Size = Vector3.new(.15,.25,.2)
leye.Adornee = Anchor
leye.Color = BrickColor.new("Really black")

local reye= Instance.new("BoxHandleAdornment", Anchor)
reye.Size = Vector3.new(.15,.25,.2)
reye.Adornee = Anchor
reye.Color = BrickColor.new("Really black")

Pac = Instance.new("Part")

Pac.CFrame = CFrame.new(Character.HumanoidRootPart.Position.X,Y+20,Character.HumanoidRootPart.Position.Z)

Character.Parent = owner

game:GetService("RunService").Heartbeat:Connect(function()

coroutine.wrap(function()
if humanoid.Jump then
humanoid.Sit = false
if not jumpDB then
jumpDB = true
for i = 1,10 do
Y = Y + i/5*(humanoid.JumpPower/50)
task.wait()
end
repeat task.wait() Y=math.clamp(Y-.75,0,100000000000000000) until Y < .1
jumpDB = false
end
end
end)()


sine = sine + .1
newpos = Pac.Position + (humanoid.MoveDirection/2)*(humanoid.WalkSpeed/16)
if humanoid.Sit == false then
Pac.Position = Vector3.new(newpos.X,Y+3,newpos.Z)
owner.Character:SetPrimaryPartCFrame(Pac.CFrame)
else
Pac.Position = Vector3.new(Pac.Position.X,Y+1,Pac.Position.Z)
owner.Character:SetPrimaryPartCFrame(Pac.CFrame)
end
if humanoid.MoveDirection.Magnitude > 0 then
if humanoid.Sit == false then
Pac.CFrame = CFrame.new(Pac.Position, Pac.Position + humanoid.MoveDirection)

hum.CFrame = Pac.CFrame

Head.CFrame = Pac.CFrame * CFrame.new(0,1.5,0)

leye.CFrame = Pac.CFrame * CFrame.new(.35,1.5,-.6)
reye.CFrame = Pac.CFrame * CFrame.new(-.35,1.5,-.6)

Larm.CFrame = Pac.CFrame * CFrame.new(1.5,1,0)  * CFrame.Angles(math.rad(math.sin(sine) * 45),0,0) * CFrame.new(0,-1,0)

Rarm.CFrame = Pac.CFrame * CFrame.new(-1.5,1,0) *CFrame.Angles(-math.rad(math.sin(sine) * 45),0, 0) * CFrame.new(0,-1,0)

Lleg.CFrame = Pac.CFrame * CFrame.new(.5,-1,0) * CFrame.Angles(-math.rad(math.sin(sine)*30),0,0)* CFrame.new(0,-1,0)

Rleg.CFrame = Pac.CFrame * CFrame.new(-.5,-1,0) * CFrame.Angles(math.rad(math.sin(sine)*30),0,0)* CFrame.new(0,-1,0)
end
else

hum.CFrame = Pac.CFrame * CFrame.new(0,0,0) *  CFrame.new(0,math.sin(sine/5)/10,0) * CFrame.Angles(math.rad(math.sin(sine/5))*3,0,math.rad(math.cos(sine/5))*3)

Head.CFrame = Pac.CFrame * CFrame.new(0,1,0) * CFrame.Angles(math.rad(math.cos(sine/10))*5,math.rad(math.sin(sine/10))*5,math.rad(math.cos(sine/5))*10) * CFrame.new(0,.5,0)

leye.CFrame = Pac.CFrame * CFrame.new(0,1,0) * CFrame.Angles(math.rad(math.cos(sine/10))*5,math.rad(math.sin(sine/10))*5,math.rad(math.cos(sine/5))*10) * CFrame.new(.35,.5,-.6)
reye.CFrame = Pac.CFrame * CFrame.new(0,1,0) * CFrame.Angles(math.rad(math.cos(sine/10))*5,math.rad(math.sin(sine/10))*5,math.rad(math.cos(sine/5))*10) * CFrame.new(-.35,.5,-.6)

Larm.CFrame = Pac.CFrame * CFrame.new(1.5,1,0) * CFrame.new(0,-.1+math.cos(sine/5)/7,0) * CFrame.Angles(0,math.rad(35),math.rad(10 + math.sin(sine/5)*10)) * CFrame.new(0,-1,0)

Rarm.CFrame = Pac.CFrame * CFrame.new(-1.5,1,0) * CFrame.Angles(0,-math.rad(35),-math.rad(10 + math.sin(sine/5)*10)) * CFrame.new(0,-1,0)

Lleg.CFrame = Pac.CFrame * CFrame.new(.5,-1,0) * CFrame.Angles(0,math.rad(-90),0) * CFrame.new(0,-.1+math.sin(sine/5)/10,0) * CFrame.Angles(math.rad(0),math.rad(40),math.rad(5+math.cos(sine/5)*5)) * CFrame.new(0,-1,0)

Rleg.CFrame = Pac.CFrame * CFrame.new(-.5,-1,0) * CFrame.Angles(0,math.rad(-90),0) * CFrame.new(0,-.1+math.sin(sine/5)/10,0) * CFrame.Angles(0,0,-math.rad(7+math.sin(sine/5)*7)) * CFrame.new(0,-1,0)

end


if humanoid.Sit then
hum.CFrame = Pac.CFrame * CFrame.new(0,0,0) *  CFrame.new(0,math.sin(sine/5)/10,0) * CFrame.Angles(math.rad(math.sin(sine/5))*3,0,math.rad(math.cos(sine/5))*3)

Head.CFrame = Pac.CFrame * CFrame.new(0,1,0) * CFrame.Angles(math.rad(math.cos(sine/10))*5,math.rad(math.sin(sine/10))*5,math.rad(math.cos(sine/5))*10) * CFrame.new(0,.5,0)

leye.CFrame = Pac.CFrame * CFrame.new(0,1,0) * CFrame.Angles(math.rad(math.cos(sine/10))*5,math.rad(math.sin(sine/10))*5,math.rad(math.cos(sine/5))*10) * CFrame.new(.35,.5,-.6)
reye.CFrame = Pac.CFrame * CFrame.new(0,1,0) * CFrame.Angles(math.rad(math.cos(sine/10))*5,math.rad(math.sin(sine/10))*5,math.rad(math.cos(sine/5))*10) * CFrame.new(-.35,.5,-.6)

Larm.CFrame = Pac.CFrame * CFrame.new(1.5,1,0) * CFrame.new(0,-.1+math.cos(sine/5)/7,0) * CFrame.Angles(0,math.rad(35),math.rad(10 + math.sin(sine/5)*10)) * CFrame.new(0,-1,0)

Rarm.CFrame = Pac.CFrame * CFrame.new(-1.5,1,0) * CFrame.Angles(0,-math.rad(35),-math.rad(10 + math.sin(sine/5)*10)) * CFrame.new(0,-1,0)

Lleg.CFrame = Pac.CFrame * CFrame.new(.5,-1,0) * CFrame.Angles(math.rad(90),0,0) * CFrame.new(0,-1,0)

Rleg.CFrame = Pac.CFrame * CFrame.new(-.5,-1,0) * CFrame.Angles(math.rad(90),0,0) * CFrame.new(0,-1,0)

end

if math.sin(tick()) > .99 then
leye.Size = Vector3.new(.1,.05,.2)
reye.Size = Vector3.new(.1,.05,.2)
else
leye.Size = leye.Size:Lerp(Vector3.new(.15,.3,.2), .1)
reye.Size = reye.Size:Lerp(Vector3.new(.15,.3,.2), .1)
end

end)