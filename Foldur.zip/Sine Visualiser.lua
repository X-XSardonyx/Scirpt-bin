local lbars = {}
local rbars = {}

local BG = Instance.new("Part", script)
BG.Size = Vector3.new(22,5,1.1)
BG.Anchored = true
BG.Locked = true
BG.BrickColor = BrickColor.new("Really black")
BG.CanCollide = false

local mesh = Instance.new("SpecialMesh", BG)
mesh.Scale = Vector3.new(-22,7,1.1)
mesh.MeshType = 'FileMesh'

for i = 1,10 do
local bar = Instance.new("Part", script)
bar.Anchored = true
bar.Material= 'Neon'
bar.CanCollide = false
bar.CFrame = CFrame.new(i-.5,.5,30)
table.insert(lbars, bar)
end
for i = 1,10 do
local bar = Instance.new("Part", script)
bar.Anchored = true
bar.Material= 'Neon'
bar.CFrame = CFrame.new(-i - .5,.5,30)
table.insert(rbars, bar)
end

local audio = Instance.new("Sound", owner.Character.Head)
audio.MaxDistance = 100
audio.Looped = true
audio.SoundId = 'rbxassetid://7071427516'
audio.Pitch = 1
audio.Volume = 5
audio:Play()

local Loud = Instance.new("Part", script)
Loud.CanCollide = false
Loud.Transparency = 1
Loud.Massless = true
Loud.Size = Vector3.new(5,5,5)
Loud:SetNetworkOwner(owner)
Instance.new("ObjectValue", owner.Character).Value = Loud

NLS([[local target = owner.Character.Value.Value
local sound = owner.Character.Head.Sound

local force1 = Instance.new("BodyPosition", target)
force1.MaxForce = Vector3.new(math.huge,math.huge,math.huge)
force1.P = 150000
force1.D = 1000

local force2 = Instance.new("BodyGyro", target)
force2.MaxTorque = Vector3.new(math.huge,math.huge,math.huge)
force2.P = 150000
force2.D = 1000

game:GetService("RunService").RenderStepped:Connect(function()
force1.Position = Vector3.new(owner.Character.Head.Position.X,sound.PlaybackLoudness,owner.Character.Head.Position.Z)
force2.CFrame = CFrame.new(0,0,0)
end)

]], owner.Character)

game:GetService("RunService").Heartbeat:Connect(function()
BG.CFrame = owner.Character.Head.CFrame * CFrame.new(0,8,0)

for i,v in pairs(lbars) do
v.Size = v.Size:Lerp(Vector3.new(1,math.sin(math.noise(Loud.Position.Y/60,i))*15,1), .1)
v.CFrame = owner.Character.Head.CFrame * CFrame.new(0,4,0) * CFrame.new(i + .5,.5,0) * CFrame.new(0,v.Size.Y / 2,0)
v.Color = v.Color:Lerp(Color3.fromHSV(math.sin(math.noise(v.Size.Y))/3%1/1,1,1), .1)
end
for i,v in pairs(rbars) do
v.Size = v.Size:Lerp(Vector3.new(1,math.sin(math.noise(Loud.Position.Y/60,i))*15,1), .1)
v.CFrame = owner.Character.Head.CFrame * CFrame.new(0,4,0) * CFrame.new(-i - .5,.5,0) * CFrame.new(0,v.Size.Y / 2,0)
v.Color = v.Color:Lerp(Color3.fromHSV(math.sin(math.noise(v.Size.Y))/3%1/1,1,1), .1)
end
end)

local flange = Instance.new("FlangeSoundEffect", audio)
flange.Rate = .5
flange.Depth = 5
flange.Enabled = false

owner.Chatted:Connect(function(msg)
local message = string.split(msg, ' ')
if string.lower(message[1]) =='-music' then
audio:Stop()
audio.SoundId = 'rbxassetid://'..message[2]
audio:Play()
elseif string.lower(message[1]) =='-volume' then
audio.Volume = message[2]
elseif string.lower(message[1]) =='-pitch' then
audio.Pitch = message[2]
elseif string.lower(message[1]) =='-debug' then
Loud.Transparency = .5
elseif string.lower(message[1]) =='-bug' then
Loud.Transparency = 1
elseif string.lower(message[1]) =='-flange' then
flange.Enabled = true
elseif string.lower(message[1]) =='-unflange' then
flange.Enabled = false
end
end)

print([[Commands: 
-music int
-volume int
-pitch int
-debug
-bug]])