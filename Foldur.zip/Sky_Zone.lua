model = Instance.new("Model", script)


function part(shape,anchored, transparency, size, cframe, color, locked, cancollide,material, name)

local prt = Instance.new("Part", model)
prt.Size = size
prt.Anchored = anchored
prt.CanCollide = cancollide
prt.Locked = locked
prt.Shape = shape
prt.Transparency = transparency
prt.Size = size
prt.Color = color
prt.CFrame = cframe
prt.Material = material
prt.Name = name
end

function wedge(anchored, transparency, size, cframe, color, locked, cancollide, material, name)

local prt = Instance.new("WedgePart", model)
prt.Size = size
prt.Anchored = anchored
prt.CanCollide = cancollide
prt.Locked = locked
prt.Transparency = transparency
prt.Size = size
prt.Color = color
prt.CFrame = cframe
prt.Material = material
prt.Name = name
end

function corner(anchored, transparency, size, cframe, color, locked, cancollide, material, name)

local prt = Instance.new("CornerWedgePart", model)
prt.Size = size
prt.Anchored = anchored
prt.CanCollide = cancollide
prt.Locked = locked
prt.Transparency = transparency
prt.Size = size
prt.Color = color
prt.CFrame = cframe
prt.Material = material
prt.Name = name
end

function seat(anchored, transparency, size, cframe, color, locked, cancollide, material, name)

local prt = Instance.new("Seat", model)
prt.Size = size
prt.Anchored = anchored
prt.CanCollide = cancollide
prt.Locked = locked
prt.Transparency = transparency
prt.Size = size
prt.Color = color
prt.CFrame = cframe
prt.Material = material
prt.Name = name
end

 
part("Block",true,0,Vector3.new(225.60000610352,1,376.90002441406),CFrame.new(-33.618091583252,-0.10627746582031,157.22814941406) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.80392158031464,0.80392158031464,0.80392158031464),false,true,"Concrete","Part")
part("Block",true,0,Vector3.new(87.800003051758,167.60000610352,56.800010681152),CFrame.new(-88.018096923828,80.093719482422,-38.721843719482) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.80392158031464,0.80392158031464,0.80392158031464),false,true,"Concrete","Part")
part("Cylinder",true,0,Vector3.new(2,6,6),CFrame.new(-112.98913574219,163.39372253418,-38.357078552246) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(90)),Color3.new(0.97254902124405,0.97254902124405,0.97254902124405),false,true,"Plastic","Part")
part("Block",false,0,Vector3.new(2,2,1),CFrame.new(-0.70576733350754,1.3939393758774,-0.097751714289188) * CFrame.Angles(math.rad(0),math.rad(-97.889999389648),math.rad(0)),Color3.new(1,1,0),false,true,"Plastic","Torso")
part("Block",false,0,Vector3.new(2,1,1),CFrame.new(-0.71750736236572,2.8952856063843,-0.098643720149994) * CFrame.Angles(math.rad(0),math.rad(-97.790000915527),math.rad(-0.029999999329448)),Color3.new(0.64313727617264,0.74117648601532,0.27843138575554),false,true,"Plastic","Head")
part("Block",true,0,Vector3.new(87.800003051758,167.60000610352,56.800010681152),CFrame.new(35.281902313232,80.093719482422,-38.721843719482) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.80392158031464,0.80392158031464,0.80392158031464),false,true,"Concrete","Part")
part("Block",true,0,Vector3.new(87.800003051758,1,56.800010681152),CFrame.new(35.281902313232,191.39372253418,-38.721843719482) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.80392158031464,0.80392158031464,0.80392158031464),false,true,"Concrete","Part")
part("Block",true,0,Vector3.new(4,1,3.5),CFrame.new(-115.43695831299,190.89372253418,-44.076629638672) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"Neon","Part")
wedge(true,0,Vector3.new(48.799999237061,164.60000610352,268.10000610352),CFrame.new(-40.286697387695,81.700004577637,150.92813110352) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.80392158031464,0.80392158031464,0.80392158031464),false,true,"Concrete","Wedge")
part("Block",true,0,Vector3.new(82.800003051758,0.50001227855682,52.800010681152),CFrame.new(35.281902313232,164.04371643066,-36.721843719482) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.73725491762161,0.60784316062927,0.3647058904171),false,true,"Wood","Part")
part("Block",true,0,Vector3.new(248.80000305176,1,41.200012207031),CFrame.new(-45.21809387207,163.39372253418,10.078155517578) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.80392158031464,0.80392158031464,0.80392158031464),false,true,"Concrete","Part")
part("Block",false,0,Vector3.new(2,1,1),CFrame.new(-41.463523864746,0.49414816498756,-106.40592193604) * CFrame.Angles(math.rad(89.919998168945),math.rad(179.66999816895),math.rad(-10.319999694824)),Color3.new(0.64313727617264,0.74117648601532,0.27843138575554),false,true,"Plastic","Head")
part("Block",false,0,Vector3.new(2,2,1),CFrame.new(0.49024185538292,1.0000152587891,-67.616264343262) * CFrame.Angles(math.rad(0),math.rad(-179.86999511719),math.rad(0)),Color3.new(1,1,0),false,true,"Plastic","Torso")
part("Block",true,0,Vector3.new(2.5,28.799999237061,56.800010681152),CFrame.new(-7.3680925369263,177.29371643066,-38.721843719482) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.80392158031464,0.80392158031464,0.80392158031464),false,true,"Concrete","Part")
part("Cylinder",true,0,Vector3.new(2,6,6),CFrame.new(10.310862541199,163.39372253418,-38.357078552246) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(90)),Color3.new(0.97254902124405,0.97254902124405,0.97254902124405),false,true,"Plastic","Part")
part("Cylinder",true,0,Vector3.new(2,4.6999998092651,4.6999998092651),CFrame.new(12.260859489441,163.39372253418,-36.757080078125) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(90)),Color3.new(0.97254902124405,0.97254902124405,0.97254902124405),false,true,"Plastic","Part")
part("Block",true,0,Vector3.new(2.5,28.799999237061,56.800010681152),CFrame.new(-45.368091583252,177.29371643066,-38.721843719482) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.80392158031464,0.80392158031464,0.80392158031464),false,true,"Concrete","Part")
part("Block",true,0,Vector3.new(45.900001525879,1,356.20001220703),CFrame.new(-146.56809997559,163.39372253418,167.57815551758) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.80392158031464,0.80392158031464,0.80392158031464),false,true,"Concrete","Part")
part("Block",true,0,Vector3.new(45.900001525879,1,356.20001220703),CFrame.new(56.231906890869,163.39372253418,167.57815551758) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.80392158031464,0.80392158031464,0.80392158031464),false,true,"Concrete","Part")
part("Block",true,0,Vector3.new(4,1,3.5),CFrame.new(-83.036956787109,190.89372253418,-44.076629638672) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"Neon","Part")
part("Block",true,0,Vector3.new(86.5,28.799999237061,4.000009059906),CFrame.new(35.931911468506,177.29371643066,-65.121841430664) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.80392158031464,0.80392158031464,0.80392158031464),false,true,"Concrete","Part")
part("Block",true,0,Vector3.new(2.5,28.799999237061,56.800010681152),CFrame.new(77.931900024414,177.29371643066,-38.721843719482) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.80392158031464,0.80392158031464,0.80392158031464),false,true,"Concrete","Part")
part("Block",true,0,Vector3.new(87.800003051758,1,56.800010681152),CFrame.new(-88.018096923828,191.39372253418,-38.721843719482) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.80392158031464,0.80392158031464,0.80392158031464),false,true,"Concrete","Part")
part("Cylinder",true,0,Vector3.new(2,4.6999998092651,4.6999998092651),CFrame.new(-111.03913879395,163.39372253418,-36.757080078125) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(90)),Color3.new(0.97254902124405,0.97254902124405,0.97254902124405),false,true,"Plastic","Part")
part("Block",true,0,Vector3.new(82.800003051758,0.50001227855682,52.800010681152),CFrame.new(-88.018096923828,164.04371643066,-36.721843719482) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.73725491762161,0.60784316062927,0.3647058904171),false,true,"Wood","Part")
part("Block",true,0,Vector3.new(225.60000610352,1,60.700000762939),CFrame.new(-33.618091583252,163.39372253418,315.32815551758) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.80392158031464,0.80392158031464,0.80392158031464),false,true,"Concrete","Part")
part("Block",true,0,Vector3.new(4,1,3.5),CFrame.new(69.063034057617,190.89372253418,-44.076629638672) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"Neon","Part")
part("Block",true,0,Vector3.new(4,1,3.5),CFrame.new(-54.236957550049,190.89372253418,-44.076629638672) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"Neon","Part")
part("Block",true,0,Vector3.new(4,1,3.5),CFrame.new(40.263042449951,190.89372253418,-44.076629638672) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"Neon","Part")
part("Cylinder",true,0,Vector3.new(2,2.7000000476837,2.7000000476837),CFrame.new(13.060862541199,163.39372253418,-39.757080078125) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(90)),Color3.new(0.97254902124405,0.97254902124405,0.97254902124405),false,true,"Plastic","Part")
part("Block",true,0,Vector3.new(4,1,3.5),CFrame.new(7.8630399703979,190.89372253418,-44.076629638672) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"Neon","Part")
part("Block",true,0,Vector3.new(2.5,28.799999237061,56.800010681152),CFrame.new(-130.66809082031,177.29371643066,-38.721843719482) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.80392158031464,0.80392158031464,0.80392158031464),false,true,"Concrete","Part")
part("Block",true,0,Vector3.new(86.5,28.799999237061,4.000009059906),CFrame.new(-87.368087768555,177.29371643066,-65.121841430664) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.80392158031464,0.80392158031464,0.80392158031464),false,true,"Concrete","Part")
part("Cylinder",true,0,Vector3.new(2,2.7000000476837,2.7000000476837),CFrame.new(-110.23913574219,163.39372253418,-39.757080078125) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(90)),Color3.new(0.97254902124405,0.97254902124405,0.97254902124405),false,true,"Plastic","Part")
for i,v in pairs(model:GetDescendants()) do
if v:IsA("BasePart") then
local cf = v.CFrame
local tp = v.Transparency
local cc = v.CanCollide
local anch = v.Anchored

v.Anchored = true
v.CFrame = CFrame.new(v.Position + Vector3.new(0,50,0))
v.Transparency = 1
v.Locked = true
v.CanCollide = false
coroutine.resume(coroutine.create(function()
wait(i/#model:GetDescendants())

game:GetService("TweenService"):Create(v, TweenInfo.new(1), {CFrame = cf, Transparency = tp}):Play()
wait(1)
v.CanCollide = cc
v.Anchored = anch
end))

end
end  