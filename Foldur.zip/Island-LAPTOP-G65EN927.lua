model = Instance.new("Model", script)

local teleporter = Instance.new("Part", model)
teleporter.Size = Vector3.new(10,10,1)
teleporter.CFrame = CFrame.new(0,7.5,-50)
teleporter.Anchored = true
teleporter.Locked = true
teleporter.CanCollide = false
teleporter.Material = 'Slate'
teleporter.BrickColor = BrickColor.new("Ghost grey")

local Baseplate = Instance.new("Part", model)
Baseplate.Anchored = true
Baseplate.Size = Vector3.new(150,2,156)
Baseplate.Color = Color3.fromRGB(100,255,100)
Baseplate.CFrame = CFrame.new(100000,100000,100000)
Baseplate.Locked = true
Baseplate.Material = 'Grass'

function Cylinder(cf, material, color, size)
local cyl = Instance.new("Part", model)
cyl.CFrame = cf
cyl.Size = size
cyl.Anchored = true
cyl.Material = material
cyl.Color = color
cyl.Locked = true
cyl.Shape = 'Cylinder'
return cyl
end

Cylinder(CFrame.new(99925,100000,99925) * CFrame.Angles(0,0,math.rad(90)), 'Grass', Baseplate.Color, Vector3.new(2.01,6,6))
Cylinder(CFrame.new(100075,100000,99925) * CFrame.Angles(0,0,math.rad(90)), 'Grass', Baseplate.Color, Vector3.new(2.01,6,6))
Cylinder(CFrame.new(99925,100000,100075) * CFrame.Angles(0,0,math.rad(90)), 'Grass', Baseplate.Color, Vector3.new(2.01,6,6))
Cylinder(CFrame.new(100075,100000,100075) * CFrame.Angles(0,0,math.rad(90)), 'Grass', Baseplate.Color, Vector3.new(2.01,6,6))

local fakebp = Baseplate:Clone()
fakebp.Parent = model
fakebp.Size = Vector3.new(156,1.99,150)

local skybox = Instance.new("Part", model)
skybox.Anchored = true
skybox.CanCollide = false
skybox.Locked = true
skybox.CFrame = CFrame.new(100000,100000,100000) * CFrame.Angles(math.rad(90),0,0)
skybox.CastShadow = false
skybox.Color = BrickColor.new("Pastel Blue").Color

local mesh = Instance.new("SpecialMesh", skybox)
mesh.Scale = Vector3.new(-2000,2000,2000)
mesh.MeshType = 'FileMesh'
mesh.MeshId = 'rbxassetid://1185246'
mesh.TextureId = 'rbxassetid://7123762364'

model.PrimaryPart= Baseplate

model:SetPrimaryPartCFrame(CFrame.new(0,2000,2000))

teleporter.CFrame = CFrame.new(0,7.5,-50)


local DB = false

teleporter.Touched:Connect(function(part)
if DB == false then
if game:GetService("Players"):GetPlayerFromCharacter(part.Parent) then
DB = true
local plr = game:GetService("Players"):GetPlayerFromCharacter(part.Parent)
local blackout = Instance.new("Frame", Instance.new("ScreenGui", plr.PlayerGui))
blackout.Parent.IgnoreGuiInset = true
blackout.Size = UDim2.new(1,0,1,0)
blackout.BackgroundTransparency = 1
blackout.BackgroundColor3 = BrickColor.new("Institutional white").Color
blackout.BorderSizePixel = 1
plr.Character.Parent = nil
for i = 1,5 do
local cylen = Cylinder(teleporter.CFrame * CFrame.Angles(0,math.rad(90),0), 'SmoothPlastic', BrickColor.new("Institutional white").Color, Vector3.new(1,1,1))
game:GetService("TweenService"):Create(cylen, TweenInfo.new(.5), {Size = Vector3.new(1.05,5,5), Transparency = 1}):Play()
game:GetService("Debris"):AddItem(cylen, .5)
wait(.2)
end
game:GetService("TweenService"):Create(blackout, TweenInfo.new(1), {BackgroundTransparency = 0}):Play()
wait(1)
game:GetService("TweenService"):Create(blackout, TweenInfo.new(1), {BackgroundTransparency = 1}):Play()

plr.Character:SetPrimaryPartCFrame(Baseplate.CFrame * CFrame.new(0,10,0))
plr.Character.Parent = workspace
game:GetService("Debris"):AddItem(blackout, 1)
DB = false
end
end
end)