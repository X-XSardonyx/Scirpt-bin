script.Parent = owner.Character
owner.Character.Humanoid.WalkSpeed = 50
owner.Character.Humanoid.JumpPower = 75
--Anim Setting
local mode = 1
for i,v in pairs(owner.Character:GetDescendants()) do
if v:IsA("Motor6D") then
local weld = Instance.new("Weld", v.Parent)
weld.Part1 = v.Part1
weld.Part0 = v.Part0
weld.C0 = v.C0
weld.C1 = v.C1
weld.Name = v.Name
v:Destroy()
end
end


AnimDefaults = {
Head = owner.Character.Torso.Neck.C0,
Torso = owner.Character.HumanoidRootPart.RootJoint.C0,
Larm = owner.Character.Torso["Left Shoulder"].C0,
Rarm = owner.Character.Torso["Right Shoulder"].C0,
Lleg = owner.Character.Torso["Left Hip"].C0,
Rleg = owner.Character.Torso["Right Hip"].C0
}
--Setting Joints
Head = owner.Character.Torso.Neck
Torso = owner.Character.HumanoidRootPart.RootJoint
Larm = owner.Character.Torso["Left Shoulder"]
Rarm = owner.Character.Torso["Right Shoulder"]
Lleg = owner.Character.Torso["Left Hip"]
Rleg = owner.Character.Torso["Right Hip"]
--ANIMS1

local hrp = owner.Character.HumanoidRootPart
local effects = {}
for i = 1,100 do
local part = Instance.new("Part", script)
part.Anchored = true
part.CanCollide = false
part.Transparency = 1
part.Shape = 'Ball'
part.Size = Vector3.new(2,2,2)
part.Material = 'Neon'
table.insert(effects, part)
end
--Running
game:GetService("RunService").Heartbeat:Connect(function()
local Mag = owner.Character.HumanoidRootPart.Velocity.Magnitude
if Mag > 1 then

Larm.C0 = Larm.C0:Lerp(AnimDefaults.Larm * CFrame.Angles(0,0,math.rad(75)), .2)
Rarm.C0 = Rarm.C0:Lerp(AnimDefaults.Rarm * CFrame.Angles(0,0,math.rad(-75)), .2)

Torso.C0 = Torso.C0:Lerp(AnimDefaults.Torso * CFrame.Angles(math.rad(25),0,0), .2)

Lleg.C0 = Lleg.C0:Lerp(AnimDefaults.Lleg * CFrame.Angles(0,0,math.rad(math.sin(tick() * Mag) * 90)), .25)
Rleg.C0 = Rleg.C0:Lerp(AnimDefaults.Rleg * CFrame.Angles(0,0,math.rad(math.sin(tick() * Mag) * 90)), .25)


local part = effects[math.random(1, #effects)]
part.CFrame = hrp.CFrame * CFrame.new(math.random(-5,5) / 10,-3,math.random(-5,5) / 10)
part.Transparency = 0
game:GetService("TweenService"):Create(part, TweenInfo.new(2), {Transparency = 1, CFrame = CFrame.new(part.CFrame * CFrame.new(0,2,0).Position)}):Play()
end
end)

--Idle
game:GetService("RunService").Heartbeat:Connect(function()
local Mag = owner.Character.HumanoidRootPart.Velocity.Magnitude
if Mag < 1 then
Torso.C0 = Torso.C0:Lerp(AnimDefaults.Torso * CFrame.new(0,0,0 + math.sin(tick()) / 5), .2)
Larm.C0 = Larm.C0:Lerp(AnimDefaults.Larm * CFrame.Angles(math.rad(math.sin(tick() ) * 10), 0, 0), .2)
Rarm.C0 = Rarm.C0:Lerp(AnimDefaults.Rarm * CFrame.Angles(math.rad(math.sin(tick() ) * 10), 0, 0), .2)
Lleg.C0 = Lleg.C0:Lerp(AnimDefaults.Lleg * CFrame.new(0,-math.sin(tick()) / 5,0) * CFrame.Angles(0,math.rad(15),0), .2)
Rleg.C0 = Rleg.C0:Lerp(AnimDefaults.Rleg * CFrame.new(0,-math.sin(tick())/5,0) *  CFrame.Angles(0,math.rad(0),0), .2)
end
end)

local sound = Instance.new("Sound", owner.Character.PrimaryPart)
sound.Volume = 1
sound.MaxDistance = 50
sound.Looped = true
sound.Pitch = 0
sound.SoundId = 'rbxassetid://'..4561266845
sound:Play()

local fakevector = Vector3.new(0,0,0)

local hum = owner.Character.Humanoid
local HRP = owner.Character.HumanoidRootPart

game:GetService("RunService").Heartbeat:Connect(function()
if HRP.Velocity.Magnitude > .1 then
hum.WalkSpeed = hum.WalkSpeed + .1
fakevector = fakevector + Vector3.new(0,.001,0)
sound.Pitch = fakevector.Y
else
hum.WalkSpeed = 15
fakevector = fakevector:Lerp(Vector3.new(0,0,0), .01)
sound.Pitch = fakevector.Y
end
end)