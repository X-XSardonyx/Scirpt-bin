local rem = Instance.new("RemoteEvent", owner.PlayerGui)

local wm = Instance.new("WorldModel", script)

clr = BrickColor.Random()

rem.OnServerEvent:Connect(function(plr, pos1, pos2)

local part = Instance.new("SpawnLocation", wm)
part.Enabled = false
part.Material = 'SmoothPlastic'
part.BrickColor = clr

mag = (pos1-pos2).Magnitude

part.CFrame = CFrame.new(pos1,pos2) * CFrame.new(0,0,-mag/2) 
part.Size = Vector3.new(.5,.5,mag)
z
end)


NLS([[

local rem = script.Parent

local mouse = owner:GetMouse()

mousedown = false

mouse.Button1Down:Connect(function()
mousedown = true

repeat

pos1 = mouse.Hit.Position

wait(1/30)
pos2 = mouse.Hit.Position

rem:FireServer(pos1,pos2)
until mousedown == false
end)

mouse.Button1Up:Connect(function()
mousedown = false
end)
]], rem)