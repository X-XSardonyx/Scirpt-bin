local fakerem = Instance.new("RemoteEvent")
local Size = 2
local head = Instance.new("Part", script)



head.Anchored = true
head.CanCollide = false
head.Archivable = false
head.Material = 'SmoothPlastic'
head.Color = owner.Character.Head.Color
head.Size = Vector3.new(Size,Size,Size)

owner.Character.Head:FindFirstChildWhichIsA("Decal"):Clone().Parent = head

Instance.new("BlockMesh", head).Offset = Vector3.new(0,0,10000)
local larm = Instance.new("Part", script)
larm.Anchored = true
larm.CanCollide = false
larm.Archivable = false
larm.Material = 'SmoothPlastic'
larm.Color = owner.Character.Head.Color
larm.Size = Vector3.new(Size / 4,Size / 4,Size)

Instance.new("BlockMesh", larm).Offset = Vector3.new(0,0,10000)
local rarm = Instance.new("Part", script)
rarm.Anchored = true
rarm.CanCollide = false
rarm.Archivable = false
rarm.Material = 'SmoothPlastic'
rarm.Color = owner.Character.Head.Color
rarm.Size = Vector3.new(Size / 4,Size / 4,Size)

Instance.new("BlockMesh", rarm).Offset = Vector3.new(0,0,10000)


owner.Character = nil

local NLS = NLS([[

local cam = workspace.CurrentCamera
local mouse = owner:GetMouse()
local UI = game:GetService'UserInputService'
local speed = 1
local rem = script:WaitForChild("RemoteEvent")

local wdown = false
local sdown = false
local adown = false
local ddown = false


cam.CameraType = 'Scriptable'

mouse.TargetFilter = workspace

mouse.KeyUp:Connect(function(key)
if key == 'w' then
wdown = false
elseif key == 'a' then
adown = false
elseif key == 's' then
sdown = false
elseif key == 'd' then
ddown = false
end
end)

mouse.KeyDown:Connect(function(key)
if key == 'w' then
wdown = true
elseif key == 'a' then
adown = true
elseif key == 's' then
sdown = true
elseif key == 'd' then
ddown = true
end
end)

game:GetService("RunService").RenderStepped:Connect(function()
if wdown == true then
cam.CFrame = cam.CFrame * CFrame.new(0,0,-speed)
elseif adown == true then
cam.CFrame = cam.CFrame * CFrame.new(-speed,0,0)
elseif sdown == true then
cam.CFrame = cam.CFrame * CFrame.new(0,0,speed)
elseif ddown == true then
cam.CFrame = cam.CFrame * CFrame.new(speed,0,0)
end
cam.CFrame = cam.CFrame:Lerp(CFrame.new(cam.CFrame.Position, mouse.Hit.Position), .1)
end)

while wait(1/30) do
rem:FireServer(cam.CFrame)
end

]], owner.PlayerGui)

fakerem.Parent = NLS

local HIDE = Instance.new("WorldModel", script)

head.Parent = HIDE
larm.Parent = HIDE
rarm.Parent = HIDE

fakerem.OnServerEvent:Connect(function(plr, CF)
head.CFrame = CF * CFrame.new(0,0,-10000)
larm.CFrame = CF * CFrame.new(Size / 2,-Size / 2,-10000)
rarm.CFrame = CF * CFrame.new(-Size / 2,-Size / 2,-10000)

end)