local id = 7089187825

local part = Instance.new("Part", script)
part.Size = Vector3.new(5,5,5)
part.CanCollide = false
part.Locked = false
part.Transparency = 0

local bav = Instance.new("BodyAngularVelocity", part)
local bp = Instance.new("BodyPosition", part)

bp.P = 150000
bp.D = 1000
bp.MaxForce = Vector3.new(math.huge,math.huge,math.huge)
bp.Position = owner.Character.HumanoidRootPart.Position

bav.AngularVelocity = Vector3.new(5,5,5)

for i,v in pairs({'Left','Right','Top','Bottom','Front','Back'}) do
local decal = Instance.new("Decal", part)
decal.Texture = 'rbxassetid://'..id
decal.Face = v
end

part.Touched:Connect(function(prt)
if prt.Parent ~= workspace then
prt.Velocity = CFrame.new(prt.Position, part.Position).LookVector*30
end
end)

coroutine.wrap(function()

while true do
plrs = game:GetService("Players"):GetPlayers()
local target = plrs[math.random(1,#plrs)]

if target.Character then
if target.Character.PrimaryPart then

repeat 
task.wait()
bp.Position = bp.Position:Lerp(target.Character.PrimaryPart.Position, .01)

until (bp.Position - target.Character.PrimaryPart.Position).Magnitude < 5 or (not target.Character or not target.Character.PrimaryPart)

end
end

end

end)()