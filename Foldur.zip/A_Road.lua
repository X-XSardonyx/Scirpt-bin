print("'A long trip' - Made by X_XSardonyx.")
print('V 0.5')
local offset = CFrame.new(0,7000,-10000)

model = Instance.new("Model", script)
Model = Instance.new("Model", script)

function part(shape,anchored, transparency, size, cframe, color, locked, cancollide,material, name, parent)

local prt = Instance.new("Part", parent)
prt.Size = size
prt.Anchored = anchored
prt.CanCollide = cancollide
prt.Locked = locked
prt.Shape = shape
prt.Transparency = transparency
prt.Size = size
prt.Color = color
prt.CFrame = cframe
prt.Material = material
prt.Name = name

return prt

end

function seat(anchored, transparency, size, cframe, color, locked, cancollide, material, name, parent)

local prt = Instance.new("Seat", parent)
prt.Size = size
prt.Anchored = anchored
prt.CanCollide = cancollide
prt.Locked = locked
prt.Transparency = transparency
prt.Size = size
prt.Color = color
prt.CFrame = cframe
prt.Material = material
prt.Name = name
end

part("Cylinder",true,0,Vector3.new(1,18,18),CFrame.new(0,0.5,-30) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(-90)),Color3.new(0.97254902124405,0.97254902124405,0.97254902124405),false,true,"Cobblestone","Part", model)
part("Cylinder",true,0,Vector3.new(0.10000002384186,10,10),CFrame.new(0,2.0499999523163,-30) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(-90)),Color3.new(0.97254902124405,0.97254902124405,0.97254902124405),false,true,"Neon","Pad", model)
part("Block",true,0,Vector3.new(4,.2,9),CFrame.new(0,9.1000003814697,-30) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),BrickColor.new("Black").Color,false,false,"Concrete","PLAN", model)
part("Block",true,0,Vector3.new(5,.15,9),CFrame.new(0,9.1000003814697,-30) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),BrickColor.new("Camo").Color,false,false,"Grass","PLAN2",model)
part("Cylinder",true,0,Vector3.new(1,14,14),CFrame.new(0,1.5,-30) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(-90)),Color3.new(0.38823530077934,0.37254902720451,0.38431373238564),false,true,"Cobblestone","Part",model)

part("Block",true,0,Vector3.new(0.5,2.4999997615814,1.0999994277954),CFrame.new(-13.5,4.6499996185303,-63.250003814697) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"SmoothPlastic","Part",Model)
part("Block",true,0,Vector3.new(4.7999992370605,9.1999998092651,0.099999904632568),CFrame.new(-18.299999237061,10.5,-52.750007629395) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"Slate","Part",Model)
part("Cylinder",true,0,Vector3.new(1.2999999523163,5.5999999046326,5.5999999046326),CFrame.new(-21.349998474121,3.7999999523163,-63.200004577637) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.10588235408068,0.16470588743687,0.20784313976765),false,true,"SmoothPlastic","Part",Model)
part("Block",true,0,Vector3.new(0.09999942779541,5.6999998092651,4.1999998092651),CFrame.new(-20.64999961853,12.25,-54.800006866455) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"Slate","Part",Model)
part("Block",true,0,Vector3.new(0.15000000596046,0.14999942481518,7.7499995231628),CFrame.new(-20.64999961853,12.183522224426,-66.810333251953) * CFrame.Angles(math.rad(-46),math.rad(0),math.rad(0)),Color3.new(0.066666670143604,0.066666670143604,0.066666670143604),false,true,"SmoothPlastic","Part",Model)
part("Cylinder",true,0,Vector3.new(1.3999999761581,5,5),CFrame.new(-5.649998664856,3.7999999523163,-63.200004577637) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.80392158031464,0.80392158031464,0.80392158031464),false,true,"SmoothPlastic","Part",Model)
part("Block",true,0,Vector3.new(0.15000000596046,0.14999942481518,7.2499995231628),CFrame.new(-6.3499994277954,14.949999809265,-60.500003814697) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.066666670143604,0.066666670143604,0.066666670143604),false,true,"SmoothPlastic","Part",Model)
part("Block",true,0,Vector3.new(5,0.0999995470047,4.9000000953674),CFrame.new(-13.5,5.9499998092651,-50.350002288818) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.97254902124405,0.97254902124405,0.97254902124405),false,true,"DiamondPlate","Part",Model)
part("Block",true,0,Vector3.new(14.39999961853,0.0999995470047,11.399998664856),CFrame.new(-13.5,15.050000190735,-58.400005340576) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"Slate","Part",Model)
part("Block",true,0,Vector3.new(5,3.199999332428,0.099999904632568),CFrame.new(-13.5,13.5,-52.750003814697) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"Slate","Part",Model)
part("Cylinder",true,0,Vector3.new(1.3999999761581,5,5),CFrame.new(-21.349998474121,3.7999999523163,-63.200004577637) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.80392158031464,0.80392158031464,0.80392158031464),false,true,"SmoothPlastic","Part",Model)
part("Block",true,0,Vector3.new(0.09999942779541,0.099999666213989,7.8000001907349),CFrame.new(-20.64999961853,12.28050994873,-66.824401855469) * CFrame.Angles(math.rad(-46),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"SmoothPlastic","Part",Model)
part("Block",true,0,Vector3.new(0.09999942779541,5.6999998092651,4.1999998092651),CFrame.new(-6.3499994277954,12.25,-54.800006866455) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"Slate","Part",Model)
part("Block",true,0,Vector3.new(0.09999942779541,3.5,5.3999996185303),CFrame.new(-6.3499994277954,7.6500000953674,-66.800003051758) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"Slate","Part",Model)
part("Block",true,0,Vector3.new(0.09999942779541,3.5,5.3999996185303),CFrame.new(-20.64999961853,7.6500000953674,-66.800003051758) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"Slate","Part",Model)
part("Block",true,0,Vector3.new(0.09999942779541,3.5,11.39999961853),CFrame.new(-6.3499994277954,7.6500000953674,-58.400005340576) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"Slate","Part",Model)
part("Block",true,0,Vector3.new(4.7999992370605,9.1999998092651,0.099999904632568),CFrame.new(-8.6999988555908,10.5,-52.750007629395) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"Slate","Part",Model)
part("Block",true,0,Vector3.new(0.15000000596046,0.14999942481518,12.64999961853),CFrame.new(-20.64999961853,9.4499998092651,-63.200004577637) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.066666670143604,0.066666670143604,0.066666670143604),false,true,"SmoothPlastic","Part",Model)
part("Block",true,0,Vector3.new(0.15000000596046,0.14999942481518,7.7499995231628),CFrame.new(-6.3499994277954,12.183522224426,-66.810333251953) * CFrame.Angles(math.rad(-46),math.rad(0),math.rad(0)),Color3.new(0.066666670143604,0.066666670143604,0.066666670143604),false,true,"SmoothPlastic","Part",Model)
part("Block",true,0,Vector3.new(0.15000000596046,5.6499996185303,0.14999990165234),CFrame.new(-20.64999961853,12.199999809265,-56.950004577637) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.066666670143604,0.066666670143604,0.066666670143604),false,true,"SmoothPlastic","Part",Model)
part("Block",true,0,Vector3.new(0.15000000596046,0.14999942481518,12.64999961853),CFrame.new(-6.3499994277954,9.4499998092651,-63.200004577637) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.066666670143604,0.066666670143604,0.066666670143604),false,true,"SmoothPlastic","Part",Model)
part("Block",true,0,Vector3.new(14.39999961853,0.0999995470047,16.799999237061),CFrame.new(-13.5,5.9499998092651,-61.100006103516) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"Slate","Part",Model)
part("Block",true,0,Vector3.new(0.09999942779541,0.099999666213989,7.8000001907349),CFrame.new(-6.3499994277954,12.28050994873,-66.824401855469) * CFrame.Angles(math.rad(-46),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"SmoothPlastic","Part",Model)
part("Block",true,0,Vector3.new(0.09999942779541,3.5,11.39999961853),CFrame.new(-20.64999961853,7.6500000953674,-58.400005340576) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"Slate","Part",Model)
part("Block",true,0,Vector3.new(14.39999961853,3.3999996185303,0.099998474121094),CFrame.new(-13.5,7.5999999046326,-69.450004577637) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"Slate","Part",Model)
part("Block",true,0,Vector3.new(0.09999942779541,0.099999666213989,11.5),CFrame.new(-20.64999961853,15.050000190735,-58.450004577637) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"SmoothPlastic","Part",Model)
part("Block",true,0,Vector3.new(14.39999961853,0.099999666213989,1.2999985218048),CFrame.new(-13.5,9.25,-68.850006103516) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"Slate","Part",Model)
part("Block",true,0,Vector3.new(14.349999427795,0.15000000596046,0.14999961853027),CFrame.new(-13.549999237061,14.917044639587,-64.17066192627) * CFrame.Angles(math.rad(-46),math.rad(0),math.rad(0)),Color3.new(0.066666670143604,0.066666670143604,0.066666670143604),false,true,"SmoothPlastic","Part",Model)
part("Block",true,0.75,Vector3.new(14.349999427795,0.0010000000474975,7.7499995231628),CFrame.new(-13.549999237061,12.183522224426,-66.810333251953) * CFrame.Angles(math.rad(-46),math.rad(0),math.rad(0)),Color3.new(0.066666670143604,0.066666670143604,0.066666670143604),false,true,"Glass","Part",Model)
part("Block",true,0,Vector3.new(14.300000190735,1,1),CFrame.new(-13.5,3.8499999046326,-63.250007629395) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"SmoothPlastic","Part",Model)
part("Block",true,0,Vector3.new(5,0.09999942779541,4.9000000953674),CFrame.new(-13.5,11.949999809265,-50.350002288818) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.97254902124405,0.97254902124405,0.97254902124405),false,true,"DiamondPlate","Part",Model)
part("Block",true,0,Vector3.new(0.09999942779541,0.099999666213989,11.5),CFrame.new(-6.3499994277954,15.050000190735,-58.450004577637) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"SmoothPlastic","Part",Model)
part("Block",true,0,Vector3.new(0.15000000596046,5.6499996185303,0.14999990165234),CFrame.new(-6.3499994277954,12.199999809265,-56.950004577637) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.066666670143604,0.066666670143604,0.066666670143604),false,true,"SmoothPlastic","Part",Model)
part("Block",true,0,Vector3.new(0.15000000596046,0.14999942481518,7.2499995231628),CFrame.new(-20.64999961853,14.949999809265,-60.500003814697) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.066666670143604,0.066666670143604,0.066666670143604),false,true,"SmoothPlastic","Part",Model)
part("Block",true,0,Vector3.new(0.099999904632568,6.0999994277954,4.9000000953674),CFrame.new(-11.050000190735,8.9499998092651,-50.350002288818) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.97254902124405,0.97254902124405,0.97254902124405),false,true,"DiamondPlate","Part",Model)
part("Cylinder",true,0,Vector3.new(1.2999999523163,5.5999999046326,5.5999999046326),CFrame.new(-5.649998664856,3.7999999523163,-63.200004577637) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.10588235408068,0.16470588743687,0.20784313976765),false,true,"SmoothPlastic","Part",Model)
part("Block",true,0,Vector3.new(0.099999904632568,6.0999994277954,4.9000000953674),CFrame.new(-16.049999237061,8.9499998092651,-50.350002288818) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.97254902124405,0.97254902124405,0.97254902124405),false,true,"DiamondPlate","Part",Model)
part("Cylinder",true,0,Vector3.new(1.3999999761581,5.1999998092651,5.1999998092651),CFrame.new(-19.049999237061,3.7999997138977,-13.700002670288) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.80392158031464,0.80392158031464,0.80392158031464),false,true,"SmoothPlastic","Part",Model)
part("Block",true,0,Vector3.new(4,6.9999995231628,0.099999904632568),CFrame.new(-9,8.5,-47.950000762939) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.58823531866074,0.33333334326744,0.33333334326744),false,true,"DiamondPlate","Part",Model)
part("Block",true,0,Vector3.new(0.5,12.499999046326,0.5),CFrame.new(-13.125,11.250000953674,-5.0500001907349) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"SmoothPlastic","Part",Model)
part("Cylinder",true,0,Vector3.new(1.3999999761581,5.1999998092651,5.1999998092651),CFrame.new(-7.6499996185303,3.7999997138977,-38.300003051758) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.80392158031464,0.80392158031464,0.80392158031464),false,true,"SmoothPlastic","Part",Model)
part("Block",true,0,Vector3.new(0.10000038146973,12.39999961853,5),CFrame.new(-7.0500001907349,11.200000762939,-45.5) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.58823531866074,0.33333334326744,0.33333334326744),false,true,"DiamondPlate","Part",Model)
part("Cylinder",true,0,Vector3.new(1.3999999761581,5.1999998092651,5.1999998092651),CFrame.new(-7.6499996185303,3.7999997138977,-13.700002670288) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.80392158031464,0.80392158031464,0.80392158031464),false,true,"SmoothPlastic","Part",Model)
part("Block",true,0,Vector3.new(0.10000038146973,4.0999999046326,3.5999999046326),CFrame.new(-7.0500001907349,7.7423524856567,-34.721702575684) * CFrame.Angles(math.rad(30),math.rad(0),math.rad(0)),Color3.new(0.58823531866074,0.33333334326744,0.33333334326744),false,true,"DiamondPlate","Part",Model)
part("Cylinder",true,0,Vector3.new(1.3999999761581,5.1999998092651,5.1999998092651),CFrame.new(-19.049999237061,3.7999997138977,-38.300003051758) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.80392158031464,0.80392158031464,0.80392158031464),false,true,"SmoothPlastic","Part",Model)
part("Block",true,0,Vector3.new(12.800000190735,1,4.9000000953674),CFrame.new(-13.5,5.5,-45.450000762939) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.38823530077934,0.37254902720451,0.38431373238564),false,true,"Concrete","Part",Model)
part("Block",true,0,Vector3.new(0.5,12.499999046326,0.5),CFrame.new(-13.875001907349,11.250000953674,-5.0500001907349) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"SmoothPlastic","Part",Model)
part("Block",true,0,Vector3.new(0.10000038146973,4.0999999046326,3.5999999046326),CFrame.new(-19.950000762939,7.7423524856567,-9.7217025756836) * CFrame.Angles(math.rad(30),math.rad(0),math.rad(0)),Color3.new(0.58823531866074,0.33333334326744,0.33333334326744),false,true,"DiamondPlate","Part",Model)
part("Block",true,0,Vector3.new(0.10000038146973,4.0999999046326,3.5999999046326),CFrame.new(-19.950000762939,7.7423524856567,-17.21622467041) * CFrame.Angles(math.rad(-30),math.rad(0),math.rad(0)),Color3.new(0.58823531866074,0.33333334326744,0.33333334326744),false,true,"DiamondPlate","Part",Model)
part("Block",true,0,Vector3.new(12.800000190735,1,3.5999999046326),CFrame.new(-13.5,6.400041103363,-10.49674987793) * CFrame.Angles(math.rad(30),math.rad(0),math.rad(0)),Color3.new(0.38823530077934,0.37254902720451,0.38431373238564),false,true,"Concrete","Part",Model)
part("Cylinder",true,0,Vector3.new(1.2999999523163,5.7999997138977,5.7999997138977),CFrame.new(-7.6499996185303,3.7999997138977,-13.700002670288) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.10588235408068,0.16470588743687,0.20784313976765),false,true,"SmoothPlastic","Part",Model)
part("Block",true,0,Vector3.new(12.85000038147,0.10000000149012,43),CFrame.new(-13.550000190735,17.35000038147,-26.5) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.58823531866074,0.33333334326744,0.33333334326744),false,true,"DiamondPlate","Part",Model)
part("Block",true,0,Vector3.new(0.10000038146973,10.699999809265,11.800000190735),CFrame.new(-19.950000762939,12.100093841553,-38.468963623047) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.58823531866074,0.33333334326744,0.33333334326744),false,true,"DiamondPlate","Part",Model)
part("Cylinder",true,0,Vector3.new(12.199999809265,1,1),CFrame.new(-13.25,3.7999997138977,-38.300003051758) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.80392158031464,0.80392158031464,0.80392158031464),false,true,"SmoothPlastic","Part",Model)
part("Block",true,0,Vector3.new(0.5,12.5,0.5),CFrame.new(-7.0500001907349,11.250000953674,-5.0500001907349) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"SmoothPlastic","Part",Model)
part("Cylinder",true,0,Vector3.new(1.2999999523163,5.7999997138977,5.7999997138977),CFrame.new(-7.6499996185303,3.7999997138977,-38.300003051758) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.10588235408068,0.16470588743687,0.20784313976765),false,true,"SmoothPlastic","Part",Model)
part("Block",true,0,Vector3.new(0.25,0.25,43),CFrame.new(-19.950000762939,17.35000038147,-26.5) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"SmoothPlastic","Part",Model)
part("Block",true,0,Vector3.new(0.5,12.499999046326,0.5),CFrame.new(-19.950000762939,11.250000953674,-5.0500001907349) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"SmoothPlastic","Part",Model)
part("Block",true,0,Vector3.new(12.800000190735,1,3.4000000953674),CFrame.new(-13.5,7.2500944137573,-13.468963623047) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.38823530077934,0.37254902720451,0.38431373238564),false,true,"Concrete","Part",Model)
part("Block",true,0,Vector3.new(0.10000038146973,12.39999961853,3.8999996185303),CFrame.new(-19.950000762939,11.200000762939,-7.0500001907349) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.58823531866074,0.33333334326744,0.33333334326744),false,true,"DiamondPlate","Part",Model)
part("Block",true,0,Vector3.new(13,5.4999995231628,0.099999904632568),CFrame.new(-13.5,14.64999961853,-47.950000762939) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.58823531866074,0.33333334326744,0.33333334326744),false,true,"DiamondPlate","Part",Model)
part("Block",true,0,Vector3.new(12.800000190735,1,3.4000000953674),CFrame.new(-13.5,7.2500944137573,-38.468963623047) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.38823530077934,0.37254902720451,0.38431373238564),false,true,"Concrete","Part",Model)
part("Block",true,0,Vector3.new(0.10000038146973,12.39999961853,15.799999237061),CFrame.new(-19.950000762939,11.200000762939,-26) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.58823531866074,0.33333334326744,0.33333334326744),false,true,"DiamondPlate","Part",Model)
part("Block",true,0,Vector3.new(0.10000038146973,10.699999809265,11.800000190735),CFrame.new(-7.0500001907349,12.100093841553,-38.468963623047) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.58823531866074,0.33333334326744,0.33333334326744),false,true,"DiamondPlate","Part",Model)
part("Block",true,0,Vector3.new(0.10000038146973,12.39999961853,15.799999237061),CFrame.new(-7.050000667572,11.200000762939,-26) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.58823531866074,0.33333334326744,0.33333334326744),false,true,"DiamondPlate","Part",Model)
part("Block",true,0,Vector3.new(12.800000190735,1,3.5999999046326),CFrame.new(-13.5,6.400041103363,-16.441177368164) * CFrame.Angles(math.rad(-30),math.rad(0),math.rad(0)),Color3.new(0.38823530077934,0.37254902720451,0.38431373238564),false,true,"Concrete","Part",Model)
part("Block",true,0,Vector3.new(0.10000038146973,12.39999961853,3.8999996185303),CFrame.new(-7.050000667572,11.200000762939,-7.0500001907349) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.58823531866074,0.33333334326744,0.33333334326744),false,true,"DiamondPlate","Part",Model)
part("Cylinder",true,0,Vector3.new(12.199999809265,1,1),CFrame.new(-13.25,3.7999997138977,-13.700002670288) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.80392158031464,0.80392158031464,0.80392158031464),false,true,"SmoothPlastic","Part",Model)
part("Block",true,0,Vector3.new(0.10000038146973,4.0999999046326,3.5999999046326),CFrame.new(-19.950000762939,7.7423524856567,-42.21622467041) * CFrame.Angles(math.rad(-30),math.rad(0),math.rad(0)),Color3.new(0.58823531866074,0.33333334326744,0.33333334326744),false,true,"DiamondPlate","Part",Model)
part("Block",true,0,Vector3.new(12.800000190735,1,3.9000000953674),CFrame.new(-13.5,5.5,-7.0500001907349) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.38823530077934,0.37254902720451,0.38431373238564),false,true,"Concrete","Part",Model)
part("Block",true,0,Vector3.new(0.25,0.25,43),CFrame.new(-7.0500001907349,17.35000038147,-26.5) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"SmoothPlastic","Part",Model)
part("Block",true,0,Vector3.new(0.10000038146973,4.0999999046326,3.5999999046326),CFrame.new(-7.0500011444092,7.7423524856567,-9.7217025756836) * CFrame.Angles(math.rad(30),math.rad(0),math.rad(0)),Color3.new(0.58823531866074,0.33333334326744,0.33333334326744),false,true,"DiamondPlate","Part",Model)
part("Block",true,0,Vector3.new(4,6.9999995231628,0.099999904632568),CFrame.new(-18,8.5,-47.950000762939) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.58823531866074,0.33333334326744,0.33333334326744),false,true,"DiamondPlate","Part",Model)
part("Block",true,0,Vector3.new(0.10000038146973,4.0999999046326,3.5999999046326),CFrame.new(-7.0500001907349,7.7423524856567,-42.21622467041) * CFrame.Angles(math.rad(-30),math.rad(0),math.rad(0)),Color3.new(0.58823531866074,0.33333334326744,0.33333334326744),false,true,"DiamondPlate","Part",Model)
part("Cylinder",true,0,Vector3.new(1.2999999523163,5.7999997138977,5.7999997138977),CFrame.new(-19.049999237061,3.7999997138977,-38.300003051758) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.10588235408068,0.16470588743687,0.20784313976765),false,true,"SmoothPlastic","Part",Model)
part("Block",true,0,Vector3.new(0.10000038146973,10.699999809265,11.800000190735),CFrame.new(-19.950000762939,12.100093841553,-13.468963623047) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.58823531866074,0.33333334326744,0.33333334326744),false,true,"DiamondPlate","Part",Model)
part("Block",true,0,Vector3.new(6.3500003814697,12.499999046326,0.10000000149012),CFrame.new(-9.9750003814697,11.250000953674,-5.0500001907349) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.58823531866074,0.33333334326744,0.33333334326744),false,true,"DiamondPlate","Part",Model)
part("Block",true,0,Vector3.new(0.10000038146973,4.0999999046326,3.5999999046326),CFrame.new(-7.0500011444092,7.7423524856567,-17.21622467041) * CFrame.Angles(math.rad(-30),math.rad(0),math.rad(0)),Color3.new(0.58823531866074,0.33333334326744,0.33333334326744),false,true,"DiamondPlate","Part",Model)
part("Block",true,0,Vector3.new(0.10000038146973,10.699999809265,11.800000190735),CFrame.new(-7.0500011444092,12.100093841553,-13.468963623047) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.58823531866074,0.33333334326744,0.33333334326744),false,true,"DiamondPlate","Part",Model)
part("Block",true,0,Vector3.new(6.3500003814697,12.499999046326,0.10000000149012),CFrame.new(-17.025001525879,11.250000953674,-5.0500001907349) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.58823531866074,0.33333334326744,0.33333334326744),false,true,"DiamondPlate","Part",Model)
part("Block",true,0,Vector3.new(12.800000190735,1,3.5999999046326),CFrame.new(-13.5,6.400041103363,-41.441177368164) * CFrame.Angles(math.rad(-30),math.rad(0),math.rad(0)),Color3.new(0.38823530077934,0.37254902720451,0.38431373238564),false,true,"Concrete","Part",Model)
part("Block",true,0,Vector3.new(12.800000190735,1,3.5999999046326),CFrame.new(-13.5,6.400041103363,-35.49674987793) * CFrame.Angles(math.rad(30),math.rad(0),math.rad(0)),Color3.new(0.38823530077934,0.37254902720451,0.38431373238564),false,true,"Concrete","Part",Model)
part("Block",true,0,Vector3.new(0.10000038146973,4.0999999046326,3.5999999046326),CFrame.new(-19.950000762939,7.7423524856567,-34.721702575684) * CFrame.Angles(math.rad(30),math.rad(0),math.rad(0)),Color3.new(0.58823531866074,0.33333334326744,0.33333334326744),false,true,"DiamondPlate","Part",Model)
part("Block",true,0,Vector3.new(0.10000038146973,12.39999961853,5),CFrame.new(-19.950000762939,11.200000762939,-45.5) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.58823531866074,0.33333334326744,0.33333334326744),false,true,"DiamondPlate","Part",Model)
part("Cylinder",true,0,Vector3.new(1.2999999523163,5.7999997138977,5.7999997138977),CFrame.new(-19.049999237061,3.7999997138977,-13.700002670288) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.10588235408068,0.16470588743687,0.20784313976765),false,true,"SmoothPlastic","Part",Model)
part("Block",true,0,Vector3.new(12.800000190735,1,16),CFrame.new(-13.5,5.5,-26) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.38823530077934,0.37254902720451,0.38431373238564),false,true,"Concrete","Part",Model)
part("Block",true,0,Vector3.new(2,4,1),CFrame.new(-19.299999237061,7.9999995231628,-65.200004577637) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.10588235408068,0.16470588743687,0.20784313976765),false,true,"SmoothPlastic","Part", Model)
seat(true,0,Vector3.new(2,1,2),CFrame.new(-7.5499992370605,6.4999995231628,-62.450004577637) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.10588235408068,0.16470588743687,0.20784313976765),false,true,"SmoothPlastic","Seat", Model)
part("Block",true,0,Vector3.new(2,4,1),CFrame.new(-19.299999237061,7.9999995231628,-60.950004577637) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.10588235408068,0.16470588743687,0.20784313976765),false,true,"SmoothPlastic","Part", Model)
part("Block",true,0,Vector3.new(2,4,1),CFrame.new(-7.5499992370605,7.9999995231628,-65.200004577637) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.10588235408068,0.16470588743687,0.20784313976765),false,true,"SmoothPlastic","Part", Model)
seat(true,0,Vector3.new(2,1,2),CFrame.new(-19.299999237061,6.4999995231628,-62.450004577637) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.10588235408068,0.16470588743687,0.20784313976765),false,true,"SmoothPlastic","Seat", Model)
part("Block",true,0,Vector3.new(2,4,1),CFrame.new(-7.5499992370605,7.9999995231628,-60.950004577637) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.10588235408068,0.16470588743687,0.20784313976765),false,true,"SmoothPlastic","Part", Model)
seat(true,0,Vector3.new(2,1,2),CFrame.new(-7.5499992370605,6.4999995231628,-66.700004577637) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.10588235408068,0.16470588743687,0.20784313976765),false,true,"SmoothPlastic","Seat", Model)
seat(true,0,Vector3.new(2,1,2),CFrame.new(-19.299999237061,6.4999995231628,-66.700004577637) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.10588235408068,0.16470588743687,0.20784313976765),false,true,"SmoothPlastic","Seat", Model)
local screen = part("Block",true,0,Vector3.new(1.3000,0.89999943971634,5.0100002288818),CFrame.new(-13.5,8.6414108276367,-67.977806091309) * CFrame.Angles(math.rad(45),math.rad(-90),math.rad(math.rad(-45))),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"Slate","Part", Model)
part("Block",true,0,Vector3.new(5,2.4999995231628,1.2999985218048),CFrame.new(-13.5,7.25,-67.850006103516) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"Slate","Part", Model)
part("Block",true,0,Vector3.new(14.39999961853,3.2999994754791,1.2999985218048),CFrame.new(-13.5,7.6500000953674,-68.850006103516) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"Slate","Part", Model)

part("Block",true,0,Vector3.new(0.10000002384186,5,10),CFrame.new(-19.850002288818,11.400001525879,-25.10000038147) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.066666670143604,0.066666670143604,0.066666670143604),false,true,"Plastic","Part", Model)
hook = part("Cylinder",true,0,Vector3.new(0.5,2,2),CFrame.new(-13.125,17.050001144409,-25) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(-90)),Color3.new(0.97254902124405,0.97254902124405,0.97254902124405),false,true,"Plastic","HOOK", Model)
bulb = part("Ball",true,0.5,Vector3.new(1,1,1),CFrame.new(-13.125,14.300001144409,-25) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(1,1,0),false,true,"Neon","BULB", Model)
part("Block",true,0,Vector3.new(0.15000000596046,4.5,9.5),CFrame.new(-19.850002288818,11.400001525879,-25.10000038147) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.97254902124405,0.97254902124405,0.97254902124405),false,true,"Plastic","Part", Model)

local att1 = Instance.new("Attachment", hook)
local att2 = Instance.new("Attachment", bulb)
att2.Position = Vector3.new(0,.5,0)

rope = Instance.new("RopeConstraint", hook)
rope.Attachment1 = att1
rope.Attachment0 = att2
rope.Visible = true
rope.Length = 2
rope.Thickness = .15

bulb.Anchored = false

local bbg = Instance.new("SurfaceGui", screen)
bbg.Adornee = screen
bbg.Face = 'Top'

local tb2 = Instance.new("TextBox", bbg)
tb2.Size = UDim2.new(1,0,1,0)
tb2.BackgroundTransparency = 1
tb2.TextScaled = true
tb2.Font = 'Code'
tb2.Text = [[Furret Walk
0.1,6.1,4.9
2975575778]]
tb2.TextColor = BrickColor.new("New Yeller")

local songs = {1494950723,6027322477,5939072342,1916035323,7201796207,225497763,601873759,6538555783,252554299,2307031443, 2975575778,5266257144, 251072363}

sound = Instance.new("Sound", screen)
sound.SoundId = 'rbxassetid://2975575778'
sound.MaxDistance = 100
sound.Volume = .5
sound.Looped = true
sound:Play()

local click = Instance.new("ClickDetector", screen)

click.MouseClick:Connect(function()

local v = songs[math.random(1,#songs)]
local id = v

sound.SoundId = 'rbxassetid://'..id

sound:Play()

tb2.Text = game:GetService("MarketplaceService"):GetProductInfo(v).Name..[[

]]..v

end)

Model:MoveTo(offset.Position)

smallroad = model.PLAN
smallroad2 = model.PLAN2

Pad = model.Pad

game:GetService("RunService").Heartbeat:Connect(function()

smallroad.CFrame = smallroad.CFrame * CFrame.Angles(0,math.rad(2),0)
smallroad2.CFrame = smallroad2.CFrame * CFrame.Angles(0,math.rad(2),0)

end)

Pad.Touched:Connect(function(part)
if part.Parent:FindFirstChildOfClass("Humanoid") then
if game:GetService("Players"):GetPlayerFromCharacter(part.Parent) then

plr = game:GetService("Players"):GetPlayerFromCharacter(part.Parent)

plr.Character:SetPrimaryPartCFrame(offset*CFrame.new(0,5,0))
end
end
end)

local road = Instance.new("Part", script)
road.Anchored = true
road.Size = Vector3.new(100,2,500)
road.Material = 'Slate' 
road.BrickColor = BrickColor.new("Black")
road.CFrame = offset * CFrame.new(0,-9,0)
road.Locked = true

local grass = Instance.new("Part", script)
grass.Anchored = true
grass.Size = Vector3.new(150,1.5,500)
grass.Material = 'Grass'
grass.BrickColor = BrickColor.new("Camo")
grass.CFrame = offset * CFrame.new(0,-9,0)
grass.Locked = true

local wall = Instance.new("Part", script)
wall.Anchored = true
wall.Size = Vector3.new(1,100,500)
wall.Material = 'Grass'
wall.BrickColor = BrickColor.new("Camo")
wall.CFrame = offset * CFrame.new(75,0,0)
wall.Locked = true

local wall2 = Instance.new("Part", script)
wall2.Anchored = true
wall2.Size = Vector3.new(1,100,500)
wall2.Material = 'Grass'
wall2.BrickColor = BrickColor.new("Camo")
wall2.CFrame = offset * CFrame.new(-75,0,0)
wall2.Locked = true

grass.Velocity = Vector3.new(0,0,500)
road.Velocity = Vector3.new(0,0,500)

road.Touched:Connect(function(hit)
if hit.Parent:FindFirstChildOfClass("Humanoid") then
hit.Parent:FindFirstChildOfClass("Humanoid").PlatformStand = true
hit:BreakJoints()

char = hit.Parent

for i,v in pairs(char:GetDescendants()) do
if v:IsA("Humanoid") then
v.RequiresNeck = false
elseif v:IsA("Motor6D") then
local att1 = Instance.new("Attachment", v.Part1)
local att2 = Instance.new("Attachment", v.Part0)
att1.CFrame = v.C0
att2.CFrame = v.C0
rope = Instance.new("BallSocketConstraint", att1)
rope.Attachment0 = att1
rope.Attachment1 = att2
rope.Visible = false
v:Destroy()
end
end

end
end)

grass.Touched:Connect(function(hit)
if hit.Parent:FindFirstChildOfClass("Humanoid") then
hit.Parent:FindFirstChildOfClass("Humanoid").PlatformStand = true
hit:BreakJoints()
end
end)

while wait(10) do
road.Size = Vector3.new(100,2,500)
grass.Size = Vector3.new(150,1.5,500)

game:GetService("TweenService"):Create(road, TweenInfo.new(10), {Size = Vector3.new(100,2,700)}):Play()
game:GetService("TweenService"):Create(grass, TweenInfo.new(10), {Size = Vector3.new(150,1.5,700)}):Play()
end