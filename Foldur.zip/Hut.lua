model = Instance.new("Model", script)


function part(shape,anchored, transparency, size, cframe, color, locked, cancollide,material, name)

local prt = Instance.new("Part", model)
prt.Size = size
prt.Anchored = anchored
prt.CanCollide = cancollide
prt.Locked = locked
prt.Shape = shape
prt.Transparency = transparency
prt.Size = size
prt.Color = color
prt.CFrame = cframe
prt.Material = material
prt.Name = name
end

function wedge(anchored, transparency, size, cframe, color, locked, cancollide, material, name)

local prt = Instance.new("WedgePart", model)
prt.Size = size
prt.Anchored = anchored
prt.CanCollide = cancollide
prt.Locked = locked
prt.Transparency = transparency
prt.Size = size
prt.Color = color
prt.CFrame = cframe
prt.Material = material
prt.Name = name
end

function seat(anchored, transparency, size, cframe, color, locked, cancollide, material, name)

local prt = Instance.new("Seat", model)
prt.Size = size
prt.Anchored = anchored
prt.CanCollide = cancollide
prt.Locked = locked
prt.Transparency = transparency
prt.Size = size
prt.Color = color
prt.CFrame = cframe
prt.Material = material
prt.Name = name
end

 
part("Block",true,0,Vector3.new(0.10000038146973,7,1.2000000476837),CFrame.new(-4.9499983787537,4.5,-35.5) * CFrame.Angles(math.rad(0),math.rad(180),math.rad(0)),Color3.new(0.38823530077934,0.37254902720451,0.38431373238564),false,true,"Slate","Part")
part("Block",true,0,Vector3.new(28,0.20000000298023,28),CFrame.new(0,0.94999998807907,-50) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(1,0.80000001192093,0.60000002384186),false,true,"Wood","Part")
wedge(true,0,Vector3.new(14,3,3),CFrame.new(12.39999961853,8.0500001907349,-62.5) * CFrame.Angles(math.rad(0),math.rad(-180),math.rad(-90)),Color3.new(0.66666668653488,0.33333334326744,0),false,true,"WoodPlanks","Wedge")
part("Block",true,0,Vector3.new(0.10000038146973,15,28.10000038147),CFrame.new(13.949999809265,7.5,-50.100002288818) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.66666668653488,0.33333334326744,0),false,true,"WoodPlanks","Part")
part("Block",true,0,Vector3.new(1,15,30),CFrame.new(-14.5,7.5,-50) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"Concrete","Part")
part("Block",true,0,Vector3.new(10,7,1),CFrame.new(9.5367431640625e-07,11.5,-35.5) * CFrame.Angles(math.rad(0),math.rad(180),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"Concrete","Part")
part("Block",true,0,Vector3.new(10,15,1),CFrame.new(10.000000953674,7.5,-35.5) * CFrame.Angles(math.rad(0),math.rad(180),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"Concrete","Part")
part("Block",true,0,Vector3.new(9,15,0.10000038146973),CFrame.new(-9.5,7.5,-36.100002288818) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.66666668653488,0.33333334326744,0),false,true,"WoodPlanks","Part")
part("Block",true,0,Vector3.new(32,1,32),CFrame.new(0,0.5,-50) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.38823530077934,0.37254902720451,0.38431373238564),false,true,"Slate","Part")
wedge(true,0,Vector3.new(14,3,3),CFrame.new(-12.39999961853,8.0500001907349,-37.600002288818) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(-90)),Color3.new(0.66666668653488,0.33333334326744,0),false,true,"WoodPlanks","Wedge")
part("Block",true,0,Vector3.new(29.89999961853,0.10000037401915,30),CFrame.new(0.050000380724669,15.050000190735,-50) * CFrame.Angles(math.rad(0),math.rad(180),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"Concrete","Part")
part("Block",true,0,Vector3.new(10,15,1),CFrame.new(-9.9999990463257,7.5,-35.5) * CFrame.Angles(math.rad(0),math.rad(180),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"Concrete","Part")
part("Block",true,0,Vector3.new(28,15,0.20000000298023),CFrame.new(0,7.5,-64.050003051758) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.66666668653488,0.33333334326744,0),false,true,"WoodPlanks","Part")
part("Block",true,0,Vector3.new(0.10000038146973,7,1.2000000476837),CFrame.new(4.9500012397766,4.5,-35.5) * CFrame.Angles(math.rad(0),math.rad(180),math.rad(0)),Color3.new(0.38823530077934,0.37254902720451,0.38431373238564),false,true,"Slate","Part")
part("Block",true,0,Vector3.new(1,15,30),CFrame.new(14.5,7.5,-50) * CFrame.Angles(math.rad(0),math.rad(180),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"Concrete","Part")
part("Block",true,0,Vector3.new(9,15,0.10000038146973),CFrame.new(9.5,7.5,-36.100002288818) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.66666668653488,0.33333334326744,0),false,true,"WoodPlanks","Part")
part("Block",true,0,Vector3.new(30,15,1),CFrame.new(0,7.5,-64.5) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"Concrete","Part")
wedge(true,0,Vector3.new(14,3,3),CFrame.new(12.39999961853,8.0500001907349,-37.600002288818) * CFrame.Angles(math.rad(0),math.rad(90),math.rad(-90)),Color3.new(0.66666668653488,0.33333334326744,0),false,true,"WoodPlanks","Wedge")
part("Block",true,0,Vector3.new(27.89999961853,0.10000038146973,28),CFrame.new(-0.050000190734863,14.949999809265,-50.050003051758) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.84313726425171,0.77254903316498,0.60392159223557),false,true,"Pebble","Part")
part("Block",true,0,Vector3.new(10,0.099999904632568,1.2000000476837),CFrame.new(1.2676302958425e-06,7.9499998092651,-35.5) * CFrame.Angles(math.rad(0),math.rad(180),math.rad(0)),Color3.new(0.38823530077934,0.37254902720451,0.38431373238564),false,true,"Slate","Part")
part("Block",true,0,Vector3.new(0.10000038146973,15,28),CFrame.new(-13.949999809265,7.5,-50.050003051758) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.66666668653488,0.33333334326744,0),false,true,"WoodPlanks","Part")
part("Block",true,0,Vector3.new(10.099999427795,6.9999995231628,0.10000038146973),CFrame.new(-0.0500000230968,11.5,-36.100002288818) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.66666668653488,0.33333334326744,0),false,true,"WoodPlanks","Part")
wedge(true,0,Vector3.new(14,3,3),CFrame.new(-12.39999961853,8.0500001907349,-62.5) * CFrame.Angles(math.rad(0),math.rad(-90),math.rad(-90)),Color3.new(0.66666668653488,0.33333334326744,0),false,true,"WoodPlanks","Wedge")
for i,v in pairs(model:GetDescendants()) do
if v:IsA("BasePart") then
local cf = v.CFrame
local tp = v.Transparency
local cc = v.CanCollide
local anch = v.Anchored

v.Anchored = true
v.Locked = true
v.CastShadow = false
v.CFrame = CFrame.new(v.Position + Vector3.new(0,50,0))
v.Transparency = 1
v.CanCollide = false
coroutine.resume(coroutine.create(function()
wait(i/#model:GetDescendants())

game:GetService("TweenService"):Create(v, TweenInfo.new(1), {CFrame = cf, Transparency = tp}):Play()
wait(1)
v.CanCollide = cc
v.Anchored = anch
end))

end
end  