local ScreenGui = Instance.new("ScreenGui")
ScreenGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling

local Frame = Instance.new("Frame")
Frame.Size = UDim2.new(0.25, 0, 1, 0)
Frame.BackgroundTransparency = 1
Frame.Position = UDim2.new(0.75, 0, 0, 0)
Frame.BorderSizePixel = 0
Frame.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Frame.Parent = ScreenGui

local ScrollingFrame = Instance.new("ScrollingFrame")
ScrollingFrame.Size = UDim2.new(1, 0, 1, 0)
ScrollingFrame.Active = true
ScrollingFrame.BorderSizePixel = 0
ScrollingFrame.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
ScrollingFrame.CanvasSize = UDim2.new(0, 0, 5, 0)
ScrollingFrame.ScrollBarImageColor3 = Color3.fromRGB(0, 0, 0)
ScrollingFrame.Parent = Frame

local Paste = Instance.new("TextButton", Frame)
Paste.Size = UDim2.new(.2,0,.1,0)
Paste.Position = UDim2.new(-.2,0,0,0)
Paste.Text = 'Paste'
Paste.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Paste.BorderSizePixel = 0

ScreenGui.Parent = script

--Script1

MaxZone = owner.PlayerGui

local cloneitem = Instance.new("Part")
local currenttarget = MaxZone

function createbutton(item, pos)
	local button = Instance.new("TextButton", ScrollingFrame)
	button.Text = item.Name
	button.Size = UDim2.new(.9,0,0.025, 0)
	button.Position = UDim2.new(.05,0,.025 * pos, 0)
	button.BorderSizePixel = 0
	
		if item.Parent ~= MaxZone.Parent then
	local Delete = Instance.new("TextButton", button)
	Delete.Text = 'Delete'
	Delete.Size = UDim2.new(.2,0,.5,0)
	Delete.Position = UDim2.new(.8,0,0,0)
	Delete.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	Delete.BorderSizePixel = 0
	
	
local Copy = Instance.new("TextButton", button)
Copy.Size = UDim2.new(.2,0,.5,0)
Copy.Position = UDim2.new(.8,0,.5,0)
Copy.Text = 'Copy'
Copy.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Copy.BorderSizePixel = 0



Copy.MouseButton1Click:Connect(function()
cloneitem = item:Clone()
end)

	Delete.MouseButton1Click:Connect(function()
	item:Destroy()
	refresh()
	end)
	end
	button.MouseButton1Click:Connect(function()
		currenttarget = item
		refresh()
	end)
end

function refresh()
	for i,v in pairs(ScrollingFrame:GetChildren()) do

		v:Destroy()

	end
	for i,v in pairs(currenttarget:GetChildren()) do

		createbutton(v, i)

	end
	
	if currenttarget ~= MaxZone then
		local button = Instance.new("TextButton", ScrollingFrame)
		button.Text = 'To Parent'
		button.Size = UDim2.new(.9,0,0.025, 0)
		button.Position = UDim2.new(.05,0,0, 0)
		button.BorderSizePixel = 0
		button.MouseButton1Click:Connect(function()
			currenttarget = currenttarget.Parent
			refresh()
		end)
	end
	currenttarget.ChildAdded:Connect(function()
	refresh()
	end)
	
	currenttarget.ChildRemoved:Connect(function()
	refresh()
	end)
	
end
refresh()	

Paste.MouseButton1Click:Connect(function()
cloneitem:Clone().Parent = currenttarget
refresh()
end)