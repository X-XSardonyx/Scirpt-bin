for i,v in pairs(owner.Character:GetDescendants()) do
if v:IsA("Motor6D") then
local weld = Instance.new("Weld", v.Parent)
weld.Part1 = v.Part1
weld.Part0 = v.Part0
weld.C0 = v.C0
weld.C1 = v.C1
weld.Name = v.Name
v:Destroy()
end
end

Attack = false

script.Parent = owner.Character

--Anim Defaults
AnimDefaults = {
Head = owner.Character.Torso.Neck.C0,
Torso = owner.Character.HumanoidRootPart.RootJoint.C0,
Larm = owner.Character.Torso["Left Shoulder"].C0,
Rarm = owner.Character.Torso["Right Shoulder"].C0,
Lleg = owner.Character.Torso["Left Hip"].C0,
Rleg = owner.Character.Torso["Right Hip"].C0
}
--Setting Joints
Head = owner.Character.Torso.Neck
Torso = owner.Character.HumanoidRootPart.RootJoint
Larm = owner.Character.Torso["Left Shoulder"]
Rarm = owner.Character.Torso["Right Shoulder"]
Lleg = owner.Character.Torso["Left Hip"]
Rleg = owner.Character.Torso["Right Hip"]

local sine = 1

local sound = Instance.new("Sound", owner.Character.Torso)
sound.Volume = 1
sound.Pitch = 0
sound.Looped = true
sound.MaxDistance = 50
sound.SoundId = 'rbxassetid://833564767'
sound:Play()

local Idle = true

local newsine = 1

game:GetService("RunService").Heartbeat:Connect(function()
newsine = newsine + owner.Character.Humanoid.WalkSpeed/8
sound.Pitch = owner.Character.HumanoidRootPart.Velocity.Magnitude/owner.Character.Humanoid.WalkSpeed

sine = sine + 1

if owner.Character.Humanoid.Sit == true then
Idle = false
Larm.C0 = Larm.C0:Lerp(AnimDefaults.Larm * CFrame.new(0,-.25,0) * CFrame.Angles(math.rad(-30),0,0), .1)
Rarm.C0 = Rarm.C0:Lerp(AnimDefaults.Rarm * CFrame.new(0,-.25,0) * CFrame.Angles(math.rad(-30),0,0), .1)
Lleg.C0 = Lleg.C0:Lerp(AnimDefaults.Lleg * CFrame.Angles(math.rad(-5),math.rad(30),math.rad(-100)), .1)
Rleg.C0 = Rleg.C0:Lerp(AnimDefaults.Rleg * CFrame.Angles(math.rad(-5),math.rad(-30),math.rad(100)), .1)
Head.C0 = Head.C0:Lerp(AnimDefaults.Head, .1)
Torso.C0 = Torso.C0:Lerp(AnimDefaults.Torso * CFrame.new(0,0,0), .1)


if math.sin(sine*2) > .99 then
Larm.C0 = Larm.C0:Lerp(AnimDefaults.Larm * CFrame.new(0,-.75,0) * CFrame.Angles(math.rad(-40),0,0), 1)
Rarm.C0 = Rarm.C0:Lerp(AnimDefaults.Rarm * CFrame.new(0,-.75,0) * CFrame.Angles(math.rad(-40),0,0), 1)
Lleg.C0 = Lleg.C0:Lerp(AnimDefaults.Lleg * CFrame.new(0,-.25,0) * CFrame.Angles(math.rad(-5),math.rad(30),math.rad(-100)), 1)
Rleg.C0 = Rleg.C0:Lerp(AnimDefaults.Rleg * CFrame.new(0,-.25,0) * CFrame.Angles(math.rad(-5),math.rad(-30),math.rad(100)), 1)
Head.C0 = Head.C0:Lerp(AnimDefaults.Head * CFrame.Angles(0,0,math.rad(math.sin(sine)*15)), 1)
Torso.C0 = Torso.C0:Lerp(AnimDefaults.Torso * CFrame.new(0,0,0) * CFrame.Angles(0,math.rad(math.sin(sine)*15),0), 1)
end

else

if owner.Character.HumanoidRootPart.Velocity.Magnitude > 1 and owner.Character.Humanoid.Sit == false then

Lleg.C0 = Lleg.C0:Lerp(AnimDefaults.Lleg * CFrame.Angles(0,0,-math.rad(math.sin(newsine/25)*45)), .5)
Rleg.C0 = Rleg.C0:Lerp(AnimDefaults.Rleg * CFrame.Angles(0,0,-math.rad(math.sin(newsine/25)*45)), .5)
Torso.C0 = Torso.C0:Lerp(AnimDefaults.Torso * CFrame.new(0,0,math.sin(newsine/(25/2))/5), .5)
Head.C0 = Head.C0:Lerp(AnimDefaults.Head, .1)
Larm.C0 = Larm.C0:Lerp(AnimDefaults.Larm * CFrame.Angles(math.rad(math.sin(newsine/25)*20),0,math.rad(math.sin(newsine/25)*45)), .5)
Rarm.C0 = Rarm.C0:Lerp(AnimDefaults.Rarm * CFrame.Angles(-math.rad(math.sin(newsine/25)*20),0,math.rad(math.sin(newsine/25)*45)), .5)
Torso.C0 = Torso.C0:Lerp(AnimDefaults.Torso * CFrame.new(0,0,math.sin(newsine/(25/2))/5), .5)
elseif owner.Character.HumanoidRootPart.Velocity.Magnitude < 1 then
Lleg.C0 = Lleg.C0:Lerp(AnimDefaults.Lleg * CFrame.new(0,-math.sin(sine/50) / 5,0) * CFrame.Angles(0,0,-math.rad(10 + math.sin(sine /25) * 5)), .5)
Rleg.C0 = Rleg.C0:Lerp(AnimDefaults.Rleg * CFrame.new(0,-math.sin(sine/50) / 5,0) * CFrame.Angles(0,0,math.rad(10 + math.sin(sine /25) * 5)), .5)
Torso.C0 = Torso.C0:Lerp(AnimDefaults.Torso * CFrame.new(0,0,math.sin(sine/50) / 5) * CFrame.Angles(math.rad(10 + math.sin(sine / 25) * 5),0,0), .5)

Larm.C0 = Larm.C0:Lerp(AnimDefaults.Larm * CFrame.new(0,-.5 + math.sin(sine/25) / 5,0) * CFrame.Angles(math.rad(-5),0,-15), .5)
Rarm.C0 = Rarm.C0:Lerp(AnimDefaults.Rarm * CFrame.new(0,-.5 + math.sin(sine/25) / 5,0) * CFrame.Angles(math.rad(-5),0,15), .5)
Torso.C0 = Torso.C0:Lerp(AnimDefaults.Torso * CFrame.new(0,0,math.sin(sine/50) / 5) * CFrame.Angles(math.rad(10 + math.sin(sine / 25) * 5),0,0), .5)
Head.C0 = Head.C0:Lerp(AnimDefaults.Head, .1)
end
end
end)