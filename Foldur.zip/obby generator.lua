local CF = owner.Character.HumanoidRootPart.CFrame * CFrame.new(0,40,-20)

local truss = Instance.new("TrussPart", script)
truss.Size = Vector3.new(2,40,2)
truss.Anchored = true
truss.CFrame = CF * CFrame.new(0,-20,0)

function BallObby()

local platform = Instance.new("SpawnLocation", script)
platform.Size = Vector3.new(10,1,10)
platform.Enabled = false
platform.Anchored = true
platform.Material = 'SmoothPlastic'
platform.CFrame = CF * CFrame.new(0,0,-5)

for i = 1,10 do
ball = Instance.new("SpawnLocation", script)
ball.Size = Vector3.new(5,5,5)
ball.Enabled = false
ball.CFrame = platform.CFrame * CFrame.new(math.random(-1,1)*5,math.random(0,1)*3,-i*7.5)
ball.BrickColor = BrickColor.Random()
ball.Anchored = true
ball.Material = 'SmoothPlastic'
ball.Shape = 'Ball'
end

local platform2 = Instance.new("SpawnLocation", script)
platform2.Size = Vector3.new(10,1,10)
platform2.Enabled = false
platform2.Anchored = true
platform2.Material = 'SmoothPlastic'
platform2.CFrame = platform.CFrame * CFrame.new(0,0,-10*8.3)

CF = platform2.CFrame
end

function Dissapear()

local platform = Instance.new("SpawnLocation", script)
platform.Size = Vector3.new(10,1,10)
platform.Enabled = false
platform.Anchored = true
platform.Material = 'SmoothPlastic'
platform.CFrame = CF * CFrame.new(0,0,-5)

for i = 1,30 do
local ball = Instance.new("SpawnLocation", script)
ball.Size = Vector3.new(10,.5,2)
ball.Enabled = false
ball.CFrame = platform.CFrame * CFrame.new(0,0,-i*2)
ball.Color = Color3.fromHSV(i/30,1,1)
ball.Anchored = true
ball.Material = 'SmoothPlastic'

local db = false
ball.Touched:Connect(function()
if db == false then
db = true
game:GetService("TweenService"):Create(ball, TweenInfo.new(1.5), {Transparency = 1}):Play()
wait(1)
ball.CanCollide = false
wait(4)
db = false
ball.CanCollide = true
game:GetService("TweenService"):Create(ball, TweenInfo.new(.25), {Transparency = 0}):Play()
end
end)

end

local platform2 = Instance.new("SpawnLocation", script)
platform2.Size = Vector3.new(10,1,10)
platform2.Enabled = false
platform2.Anchored = true
platform2.Material = 'SmoothPlastic'
platform2.CFrame = platform.CFrame * CFrame.new(0,0,-30*2-5)

CF = platform2.CFrame
end

function RowObby()

local platform = Instance.new("SpawnLocation", script)
platform.Size = Vector3.new(20,1,10)
platform.Enabled = false
platform.Anchored = true
platform.Material = 'SmoothPlastic'
platform.CFrame = CF * CFrame.new(0,0,-5)

for i = 1,4 do
ball1 = Instance.new("SpawnLocation", script)
ball1.Size = Vector3.new(5,1,20)
ball1.Enabled = false
ball1.CFrame = platform.CFrame * CFrame.new(-7.5,0,-i*20+5-(i*5)+5)
ball1.BrickColor = BrickColor.Random()
ball1.Anchored = true
ball1.Material = 'SmoothPlastic'
ball1.CastShadow = false

ball2 = Instance.new("SpawnLocation", script)
ball2.Size = Vector3.new(5,1,20)
ball2.Enabled = false
ball2.CFrame = platform.CFrame * CFrame.new(0,0,-i*20+5-(i*5)+5)
ball2.BrickColor = BrickColor.Random()
ball2.Anchored = true
ball2.Material = 'SmoothPlastic'
ball2.CastShadow = false

ball3 = Instance.new("SpawnLocation", script)
ball3.Size = Vector3.new(5,1,20)
ball3.Enabled = false
ball3.CFrame = platform.CFrame * CFrame.new(7.5,0,-i*20+5-(i*5)+5)
ball3.BrickColor = BrickColor.Random()
ball3.Anchored = true
ball3.Material = 'SmoothPlastic'
ball3.CastShadow = false

local miniplat= Instance.new("SpawnLocation", script)
miniplat.Size = Vector3.new(20,1,5)
miniplat.Enabled = false
miniplat.Anchored = true
miniplat.Material = 'SmoothPlastic'
miniplat.CFrame = platform.CFrame * CFrame.new(0,0,-i*25-2.5)

chance = math.random(1,3)

if chance == 1 then

ball1.CanCollide = false
ball2.CanCollide = false

elseif chance == 2 then

ball2.CanCollide = false
ball3.CanCollide = false

elseif chance == 3 then

ball1.CanCollide = false
ball3.CanCollide = false

end

end

local platform2 = Instance.new("SpawnLocation", script)
platform2.Size = Vector3.new(20,1,10)
platform2.Enabled = false
platform2.Anchored = true
platform2.Material = 'SmoothPlastic'
platform2.CFrame = platform.CFrame * CFrame.new(0,0,-110)

CF = platform2.CFrame
end

function Spiral()

local platform = Instance.new("SpawnLocation", script)
platform.Size = Vector3.new(10,1,10)
platform.Enabled = false
platform.Anchored = true
platform.Material = 'SmoothPlastic'
platform.CFrame = CF * CFrame.new(0,0,-5)

local lastCF = platform.CFrame * CFrame.new(0,0,-5)

for i = 1,72 do
local ball = Instance.new("SpawnLocation", script)
ball.Size = Vector3.new(10,1,2)
ball.Enabled = false
ball.CFrame = lastCF * CFrame.Angles(0,math.rad(10),0) * CFrame.new(0,1,-1)
ball.Color = Color3.fromHSV(i/72,1,1)
ball.Anchored = true
ball.Material = 'SmoothPlastic'
lastCF = ball.CFrame
end

local platform2 = Instance.new("SpawnLocation", script)
platform2.Size = Vector3.new(10,1,10)
platform2.Enabled = false
platform2.Anchored = true
platform2.Material = 'SmoothPlastic'
platform2.CFrame = lastCF * CFrame.new(0,0,-6)

CF = platform2.CFrame
end

for i = 1,50 do
wait()
chance = math.random(1,4)
if chance == 1 then
BallObby()
elseif chance == 2 then
RowObby()
elseif chance == 3 then
Dissapear()
elseif chance == 4 then
Spiral()
end
end