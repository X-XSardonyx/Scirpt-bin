local target = owner
local char = target.Character

char.Shirt:Destroy()
char.Pants:Destroy()

for i,v in pairs(char:GetChildren()) do
if v.ClassName == 'Hat' or v.ClassName == 'Accessory' or v.ClassName == 'BodyMesh' then
v:Destroy()
elseif v.ClassName == 'Part' then
v.BrickColor = BrickColor.new("Institutional white")
end
end

char.Head.face:Destroy()

local eye1 = Instance.new("Part", char.Head)
eye1.Size = Vector3.new(.2,.5,.2)
eye1.CanCollide = false
eye1.Massless = false
eye1.Material = 'Neon'
eye1.BrickColor = BrickColor.new("Really blue")

Instance.new("SpecialMesh", eye1).MeshType = 'Sphere'


local weld1 = Instance.new("Weld", eye1)
weld1.Part1 = eye1
weld1.Part0 = char.Head
weld1.C0 = CFrame.new(.3,0,-.5)

local eye2 = Instance.new("Part", char.Head)
eye2.Size = Vector3.new(.2,.5,.2)
eye2.CanCollide = false
eye2.Massless = false
eye2.Material = 'Neon'
eye2.BrickColor = BrickColor.new("Really blue")

Instance.new("SpecialMesh", eye2).MeshType = 'Sphere'


local weld2 = Instance.new("Weld", eye2)
weld2.Part1 = eye2
weld2.Part0 = char.Head
weld2.C0 = CFrame.new(-.3,0,-.5)

local Attacking = false

local anim = 'Idle'

local torso = char.Torso

local Head = torso.Neck
local Torso = char.HumanoidRootPart["RootJoint"]
local LeftArm = torso["Left Shoulder"]
local RightArm = torso["Right Shoulder"]
local LeftLeg = torso["Left Hip"]
local RightLeg = torso["Right Hip"]

Instance.new("ForceField", char).Visible = false

local dancesound = Instance.new("Sound", char.Head)
dancesound.SoundId = 'rbxassetid://1125553642'
dancesound.Volume = 2
dancesound.MaxDistance = 50

local dancesound2 = Instance.new("Sound", char.Head)
dancesound2.SoundId = 'rbxassetid://6430790294'
dancesound2.Volume = 2
dancesound2.MaxDistance = 50

--6430790294
local AnimDefaults = {
	["head"] = CFrame.new(0, 1, 0, -1, 0, 0, 0, 0, 1, 0, 1, -0),
	["tors"] = CFrame.new(0, 0, 0, -1, 0, 0, 0, 0, 1, 0, 1, -0),
	["rarm"] = CFrame.new(1, 0.5, 0, 0, 0, 1, 0, 1, -0, -1, 0, 0),
	["larm"] = CFrame.new(-1, 0.5, 0, 0, 0, -1, 0, 1, 0, 1, 0, 0),
	["rleg"] = CFrame.new(1, -1, 0, 0, 0, 1, 0, 1, -0, -1, 0, 0),
	["lleg"] = CFrame.new(-1, -1, 0, 0, 0, -1, 0, 1, 0, 1, 0, 0),
}


owner.Character.Humanoid.Animator:Destroy()

owner.Character.Humanoid.Running:Connect(function(speed)
if speed == 0 then
anim = 'Idle'
else 
anim = 'walking'
dancesound:Pause()
dancesound2:Pause()
end
end)

owner.Character.Humanoid.Jumping:Connect(function(speed)
if speed == 0 then
anim = 'Idle'
else
anim = 'Jumping'
dancesound:Pause()
dancesound2:Pause()
end
end)


owner.Chatted:Connect(function(msg)
if string.lower(msg) == '/e dance' then
anim = 'Dance'
dancesound2:Pause()
dancesound:Play()

elseif string.lower(msg) == '/e dance2' then
anim = 'Dance2'
dancesound:Pause()
dancesound2:Play()
end

end)

while wait() do
if anim == 'Idle' and Attacking == false then
RightArm.C0 = RightArm.C0:Lerp(AnimDefaults.rarm * CFrame.Angles(math.rad(-45),math.rad(0),math.rad(0)), .5)
LeftArm.C0 = LeftArm.C0:Lerp(AnimDefaults.larm * CFrame.Angles(math.rad(-45),math.rad(0),math.rad(0)), .5)
Torso.C0 = Torso.C0:Lerp(AnimDefaults.tors * CFrame.new(0,0,2), .5)
Head.C0 = Head.C0:Lerp(AnimDefaults.head * CFrame.Angles(math.rad(0),math.rad(0),math.rad(10)), .5)
LeftLeg.C0 = LeftLeg.C0:Lerp(AnimDefaults.lleg * CFrame.Angles(math.rad(0),math.rad(10),math.rad(30)), .5)
RightLeg.C0 = RightLeg.C0:Lerp(AnimDefaults.rleg * CFrame.Angles(math.rad(0),math.rad(0),math.rad(-45)), .5)
wait()
elseif anim == 'walking' and Attacking == false then
RightArm.C0 = RightArm.C0:Lerp(AnimDefaults.rarm * CFrame.Angles(math.rad(-45),math.rad(0),math.rad(20)), .5)
LeftArm.C0 = LeftArm.C0:Lerp(AnimDefaults.larm * CFrame.Angles(math.rad(-45),math.rad(0),math.rad(-20)), .5)
Torso.C0 = Torso.C0:Lerp(AnimDefaults.tors * CFrame.new(0,0,2) * CFrame.Angles(math.rad(20),math.rad(0),math.rad(0)), .5)
Head.C0 = Head.C0:Lerp(AnimDefaults.head * CFrame.Angles(math.rad(-20),math.rad(0),math.rad(10)), .5)
LeftLeg.C0 = LeftLeg.C0:Lerp(AnimDefaults.lleg * CFrame.Angles(math.rad(0),math.rad(10),math.rad(30)), .5)
RightLeg.C0 = RightLeg.C0:Lerp(AnimDefaults.rleg * CFrame.Angles(math.rad(0),math.rad(0),math.rad(-45)), .5)
wait()

elseif anim == 'Jumping' and Attacking == false then
RightArm.C0 = RightArm.C0:Lerp(AnimDefaults.rarm * CFrame.Angles(math.rad(-70),math.rad(0),math.rad(0)), .9)
LeftArm.C0 = LeftArm.C0:Lerp(AnimDefaults.larm * CFrame.Angles(math.rad(-70),math.rad(0),math.rad(0)), .9)
Torso.C0 = Torso.C0:Lerp(AnimDefaults.tors * CFrame.new(0,0,2), .9)
Head.C0 = Head.C0:Lerp(AnimDefaults.head * CFrame.Angles(math.rad(0),math.rad(0),math.rad(10)), .9)
LeftLeg.C0 = LeftLeg.C0:Lerp(AnimDefaults.lleg * CFrame.Angles(math.rad(0),math.rad(-10),math.rad(0)), .9)
RightLeg.C0 = RightLeg.C0:Lerp(AnimDefaults.rleg * CFrame.Angles(math.rad(0),math.rad(10),math.rad(0)), .9)
wait()
elseif anim == 'Dance' and Attacking == false then
for i = 1,5 do
RightArm.C0 = RightArm.C0:Lerp(AnimDefaults.rarm * CFrame.Angles(math.rad(40),math.rad(0),math.rad(25)), .5)
LeftArm.C0 = LeftArm.C0:Lerp(AnimDefaults.larm * CFrame.Angles(math.rad(40),math.rad(0),math.rad(-25)), .5)
Torso.C0 = Torso.C0:Lerp(AnimDefaults.tors * CFrame.new(0,0,2) * CFrame.Angles(0,0,math.rad(20)), .5)
Head.C0 = Head.C0:Lerp(AnimDefaults.head * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)), .5)
LeftLeg.C0 = LeftLeg.C0:Lerp(AnimDefaults.lleg * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)), .5)
RightLeg.C0 = RightLeg.C0:Lerp(AnimDefaults.rleg * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)), .5)
wait()
end
for i = 1,5 do
RightArm.C0 = RightArm.C0:Lerp(AnimDefaults.rarm * CFrame.Angles(math.rad(40),math.rad(0),math.rad(160)), .5)
LeftArm.C0 = LeftArm.C0:Lerp(AnimDefaults.larm * CFrame.Angles(math.rad(-40),math.rad(0),math.rad(-160)), .5)
Torso.C0 = Torso.C0:Lerp(AnimDefaults.tors * CFrame.new(0,0,2) * CFrame.Angles(0,math.rad(10),math.rad(20)), .5)
Head.C0 = Head.C0:Lerp(AnimDefaults.head * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)), .5)
LeftLeg.C0 = LeftLeg.C0:Lerp(AnimDefaults.lleg * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)), .5)
RightLeg.C0 = RightLeg.C0:Lerp(AnimDefaults.rleg * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)), .5)
wait()
end
for i = 1,5 do
RightArm.C0 = RightArm.C0:Lerp(AnimDefaults.rarm * CFrame.Angles(math.rad(40),math.rad(0),math.rad(25)), .5)
LeftArm.C0 = LeftArm.C0:Lerp(AnimDefaults.larm * CFrame.Angles(math.rad(40),math.rad(0),math.rad(-25)), .5)
Torso.C0 = Torso.C0:Lerp(AnimDefaults.tors * CFrame.new(0,0,2) * CFrame.Angles(0,0,math.rad(20)), .5)
Head.C0 = Head.C0:Lerp(AnimDefaults.head * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)), .5)
LeftLeg.C0 = LeftLeg.C0:Lerp(AnimDefaults.lleg * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)), .5)
RightLeg.C0 = RightLeg.C0:Lerp(AnimDefaults.rleg * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)), .5)
wait()
end
for i = 1,5 do
RightArm.C0 = RightArm.C0:Lerp(AnimDefaults.rarm * CFrame.Angles(math.rad(-40),math.rad(0),math.rad(160)), .5)
LeftArm.C0 = LeftArm.C0:Lerp(AnimDefaults.larm * CFrame.Angles(math.rad(40),math.rad(0),math.rad(-160)), .5)
Torso.C0 = Torso.C0:Lerp(AnimDefaults.tors * CFrame.new(0,0,2) * CFrame.Angles(0,math.rad(-10),math.rad(20)), .5)
Head.C0 = Head.C0:Lerp(AnimDefaults.head * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)), .5)
LeftLeg.C0 = LeftLeg.C0:Lerp(AnimDefaults.lleg * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)), .5)
RightLeg.C0 = RightLeg.C0:Lerp(AnimDefaults.rleg * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)), .5)
wait()
end
elseif anim == 'Dance2' and Attacking == false then
for i = 1,5 do
RightArm.C0 = RightArm.C0:Lerp(AnimDefaults.rarm * CFrame.Angles(math.rad(40),math.rad(0),math.rad(25)), .5)
LeftArm.C0 = LeftArm.C0:Lerp(AnimDefaults.larm * CFrame.Angles(math.rad(40),math.rad(0),math.rad(-25)), .5)
Torso.C0 = Torso.C0:Lerp(AnimDefaults.tors * CFrame.new(0,0,2) * CFrame.Angles(0,0,math.rad(0)), .5)
Head.C0 = Head.C0:Lerp(AnimDefaults.head * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)), .5)
LeftLeg.C0 = LeftLeg.C0:Lerp(AnimDefaults.lleg * CFrame.new(.5,0,0), .5)
RightLeg.C0 = RightLeg.C0:Lerp(AnimDefaults.rleg * CFrame.new(.5,0,0), .5)
wait()
end
for i = 1,5 do
RightArm.C0 = RightArm.C0:Lerp(AnimDefaults.rarm * CFrame.Angles(math.rad(40),math.rad(0),math.rad(25)), .5)
LeftArm.C0 = LeftArm.C0:Lerp(AnimDefaults.larm * CFrame.Angles(math.rad(40),math.rad(0),math.rad(-25)), .5)
Torso.C0 = Torso.C0:Lerp(AnimDefaults.tors * CFrame.new(0,0,2) * CFrame.Angles(0,0,math.rad(0)), .5)
Head.C0 = Head.C0:Lerp(AnimDefaults.head * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)), .5)
LeftLeg.C0 = LeftLeg.C0:Lerp(AnimDefaults.lleg * CFrame.new(0,0,0), .5)
RightLeg.C0 = RightLeg.C0:Lerp(AnimDefaults.rleg * CFrame.new(0,0,0), .5)
wait()
end
for i = 1,5 do
RightArm.C0 = RightArm.C0:Lerp(AnimDefaults.rarm * CFrame.Angles(math.rad(40),math.rad(0),math.rad(25)), .5)
LeftArm.C0 = LeftArm.C0:Lerp(AnimDefaults.larm * CFrame.Angles(math.rad(40),math.rad(0),math.rad(-25)), .5)
Torso.C0 = Torso.C0:Lerp(AnimDefaults.tors * CFrame.new(0,0,2) * CFrame.Angles(0,0,math.rad(0)), .5)
Head.C0 = Head.C0:Lerp(AnimDefaults.head * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)), .5)
LeftLeg.C0 = LeftLeg.C0:Lerp(AnimDefaults.lleg * CFrame.new(-.5,0,0), .5)
RightLeg.C0 = RightLeg.C0:Lerp(AnimDefaults.rleg * CFrame.new(-.5,0,0), .5)
wait()
end
for i = 1,5 do
RightArm.C0 = RightArm.C0:Lerp(AnimDefaults.rarm * CFrame.Angles(math.rad(40),math.rad(0),math.rad(25)), .5)
LeftArm.C0 = LeftArm.C0:Lerp(AnimDefaults.larm * CFrame.Angles(math.rad(40),math.rad(0),math.rad(-25)), .5)
Torso.C0 = Torso.C0:Lerp(AnimDefaults.tors * CFrame.new(0,0,2) * CFrame.Angles(0,0,math.rad(0)), .5)
Head.C0 = Head.C0:Lerp(AnimDefaults.head * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)), .5)
LeftLeg.C0 = LeftLeg.C0:Lerp(AnimDefaults.lleg * CFrame.new(0,0,0), .5)
RightLeg.C0 = RightLeg.C0:Lerp(AnimDefaults.rleg * CFrame.new(0,0,0), .5)
wait()
end
end
end