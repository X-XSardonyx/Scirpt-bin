local part = Workspace.EE
local output = Instance.new("Folder", Workspace)

local Trees = Instance.new("Folder", output)
local Caves = Instance.new("Folder", output)
local Temples = Instance.new("Folder", output)
local Wheat = Instance.new("Folder", output)

local woodcolors = {BrickColor.new("CGA brown"), BrickColor.new("Pine Cone"), BrickColor.new("Brown")}
local stonecolors = {BrickColor.new("Seashell"), BrickColor.new("Cork"),BrickColor.new("Pine Cone")}
local grassColor = {BrickColor.new("Camo"), BrickColor.new("Dark green"), BrickColor.new("Bright green")}
for i = 1, 20 do
for j = 1,20 do

function tree(block)
local container = Instance.new("Model", Trees)
local middle = Instance.new("SpawnLocation", container)
middle.Size = Vector3.new(block.Size.X /3, block.Size.Y * 16, block.Size.Z/ 3)
middle.CFrame = block.CFrame * CFrame.new(0,block.Size.Y * 8, 0)
middle.BrickColor = woodcolors[math.random(1, #woodcolors)]
middle.Material = 'Slate'
middle.Anchored = true
middle.TopSurface = 'Smooth'
middle.BottomSurface = 'Smooth'

local bush = Instance.new("SpawnLocation", container)
bush.Size = Vector3.new(block.Size.X * math.random(1, 5),block.Size.Y * math.random(5,10),block.Size.Z * math.random(1,5))
bush.Anchored = true
bush.CFrame = middle.CFrame * CFrame.new(0,middle.Size.Y * .75, 0)
bush.BottomSurface = 'Smooth'
bush.TopSurface = 'Smooth'
bush.BrickColor = grassColor[math.random(1, #grassColor)]
end

function cave(block)
local container = Instance.new("Model", Caves)
local stone1 = Instance.new("SpawnLocation", container)
local stone2 = Instance.new("SpawnLocation", container)
local stone3 = Instance.new("SpawnLocation", container)
local stone4 = Instance.new("SpawnLocation", container)

stone1.Size = Vector3.new(block.Size.X / 1.5,block.Size.Y / 1.51,block.Size.Z / 1.25)
stone1.CFrame = block.CFrame *CFrame.new(0,stone1.Size.Y * 15,0)
stone1.Anchored = true
stone1.BrickColor = stonecolors[math.random(1, #stonecolors)]
stone1.Material = 'Cobblestone'

stone2.Size = Vector3.new(block.Size.X / 6,block.Size.Y * 10,block.Size.Z)
stone2.CFrame = block.CFrame * CFrame.new(block.Size.X * .395,stone1.Size.Y * 8, 0)
stone2.Anchored = true
stone2.BrickColor = stonecolors[math.random(1, #stonecolors)]
stone2.Material = 'Cobblestone'

stone3.Size = Vector3.new(block.Size.X / 6,block.Size.Y * 10,block.Size.Z)
stone3.CFrame = block.CFrame * CFrame.new(block.Size.X * -.395,stone1.Size.Y * 8, 0)
stone3.Anchored = true
stone3.BrickColor = stonecolors[math.random(1, #stonecolors)]
stone3.Material = 'Cobblestone'

stone4.Size = Vector3.new(block.Size.X,block.Size.Y * 10.01,block.Size.Z / 6)
stone4.CFrame = block.CFrame * CFrame.new(0,stone1.Size.Y * 8, stone4.Size.Z - stone4.Size.Z * 3.5)
stone4.Anchored = true
stone4.BrickColor = stonecolors[math.random(1, #stonecolors)]
stone4.Material = 'Cobblestone'

end

function temple(block)
for i = 1,10 do
local container = Instance.new("Model", Temples)
local level = Instance.new("SpawnLocation", container)
level.Size = Vector3.new(block.Size.X/ (i / 2),block.Size.Y,block.Size.Z/ (i / 2))
level.CFrame = block.CFrame * CFrame.new(0,i / 2,0)
level.Anchored = true
level.Material = 'SmoothPlastic'
level.BrickColor = stonecolors[math.random(1, #stonecolors)]
end
end

function water(block)
local waterfloor = block:Clone()
waterfloor.Size = block.Size / 4
waterfloor.CFrame = block.CFrame * CFrame.new(0,block.Size.Y * -2, 0)
block.BrickColor = BrickColor.new('Really blue')
block.Transparency = .75
block.CanCollide = false
end

function wheat(block)
local container = Instance.new("Model", Wheat)
block.BrickColor = BrickColor.new("CGA brown")
block.Material = 'Slate'
local chaff = Instance.new("SpawnLocation", container)
chaff.Anchored = true
chaff.Size = Vector3.new(block.Size.X / 12,block.Size.Y * 8, block.Size.Z / 12)
chaff.CFrame = block.CFrame * CFrame.new(0,block.Size.Y * 2, 0)
chaff.Material = 'Sand'
chaff.BrickColor = BrickColor.new("Daisy orange")
local click = Instance.new("ClickDetector", chaff)
click.MouseClick:Connect(function(plr)
local tool = Instance.new("Tool", plr.Backpack)
tool.Name = 'Wheat'
chaff.Anchored = false
chaff.Name = 'Handle'
chaff.Parent = tool
tool.Activated:Connect(function()
tool:Destroy()
end)
end)
end

local clon = part:Clone()
clon.Parent = output
clon.CFrame = part.CFrame * CFrame.new(i* part.Size.X, 0, j * part.Size.Z)
--clon.Size = Vector3.new(clon.Size.X,clon.Size.Y * math.random(-1.5, 1.5), clon.Size.Z)
clon.BrickColor = grassColor[math.random(1, #grassColor)]
local rand = math.random(1,25)
if rand == 2 or rand == 3 or rand == 4 or rand == 5 or rand == 6 or rand == 7 or rand == 8 or rand == 9 then
tree(clon)
elseif rand == 10 then
cave(clon)
elseif rand == 11 then
temple(clon)
elseif rand == 12 then
water(clon)
elseif rand == 13 then
wheat(clon)
end
end
end