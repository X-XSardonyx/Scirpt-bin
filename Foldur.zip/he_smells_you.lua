local part = game:GetService("Players").X_XSardonyx.Character.Head

local eyeball = Instance.new("Part", workspace)
eyeball.Anchored = true
eyeball.Transparency = 0
eyeball.Locked = true
eyeball.CFrame = workspace.EYE.CFrame
eyeball.Size = Vector3.new(5,5,5)
eyeball.Material = 'SmoothPlastic'
eyeball.Color = BrickColor.new("Institutional white").Color

Instance.new("SpecialMesh", eyeball)

local tb = Instance.new("TextBox", Instance.new("SurfaceGui", eyeball))
tb.Size = UDim2.new(1,0,1,0)
tb.BackgroundTransparency = 1
tb.Text = [[👀
👄]]
tb.TextSize = 100

local arms = Instance.new("Part", eyeball)
arms.Anchored = true
arms.CanCollide = false
arms.Color = eyeball.Color
arms.Material = 'SmoothPlastic'
arms.Size = Vector3.new(1.5,1.5,7.5)
arms.Locked = true

local arm2 = arms:Clone()
arm2.Parent = eyeball

script.Parent = eyeball

eyeball.Touched:Connect(function(sus)
part = sus
end)

while wait() do
eyeball.CFrame = eyeball.CFrame:Lerp(CFrame.new(eyeball.Position, part.Position), .1)
arm2.CFrame = eyeball.CFrame * CFrame.new(3,-4,-3)
arms.CFrame = eyeball.CFrame * CFrame.new(-3,-4,-3)

end