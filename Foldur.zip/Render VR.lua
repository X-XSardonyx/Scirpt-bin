if script:IsA("LocalScript") then

local gui = Instance.new("ScreenGui", script)
local vp = Instance.new("ViewportFrame", gui)
vp.Size = UDim2.new(1,0,1,0)
gui.IgnoreGuiInset = true
vp.BackgroundColor3 = BrickColor.new("Dark stone grey").Color

local floor = Instance.new("Part", vp)
floor.Size = Vector3.new(200,1,200)
floor.Material = 'Grass'
floor.Color = Color3.fromRGB(100,255,100)
floor.CFrame = CFrame.new(0,-5,0)

local camblock = Instance.new("Part", script)
camblock.Name = 'Head'

local Cam = Instance.new("Camera", gui)

vp.CurrentCamera = Cam

local mouse = owner:GetMouse()

workspace.CurrentCamera = Cam
Cam.CFrame = CFrame.new(0,0,0)
Cam.CameraType = 'Custom'

local RunService = game:GetService("RunService")
local UserInputService = game:GetService("UserInputService")

local Player = game.Players.LocalPlayer
local PlayerMouse = Player:GetMouse()

Forward = 0
Left = 0

UserInputService.InputBegan:Connect(function(input, gp)
if gp == false then
input = input.KeyCode
if input == Enum.KeyCode.W then
Forward = 1
elseif input == Enum.KeyCode.S then
Forward = -1
elseif input == Enum.KeyCode.A then
Left = 1
elseif input == Enum.KeyCode.D then
Left = -1
end
end
end)

UserInputService.InputEnded:Connect(function(input, gp)
input = input.KeyCode
if input == Enum.KeyCode.W then
Forward = 0
elseif input == Enum.KeyCode.S then
Forward = 0
elseif input == Enum.KeyCode.A then
Left = 0
elseif input == Enum.KeyCode.D then
Left = 0
end
end)

RunService.RenderStepped:Connect(function()
camblock.CFrame = camblock.CFrame * CFrame.new(0,0,-Forward) * CFrame.Angles(0,math.rad(Left*7),0)
Cam.CFrame = camblock.CFrame
camblock.Position = Vector3.new(math.clamp(camblock.Position.X,-100,100),camblock.Position.Y,math.clamp(camblock.Position.Z,-100,100))
end)

print("bad fake world by X_XSardonyx")

else

error("Error: Run as local script (rl/veer)")
end