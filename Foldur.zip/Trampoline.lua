_G.trampoline = function(posts,size,strength)
CF = owner.Character.HumanoidRootPart.CFrame
circle = 2*math.pi

local part = Instance.new("Part", script)
part.CFrame = CF * CFrame.Angles(0,0,math.rad(90))
part.Velocity = Vector3.new(0,strength,0)
part.Anchored = true
part.Size = Vector3.new(size/size,size,size)
part.Shape = 'Cylinder'
part.Material = 'Slate'
part.BrickColor = BrickColor.new("Black")

local part = Instance.new("Part", script)
part.CFrame = CF * CFrame.Angles(0,0,math.rad(90))
part.Anchored = true
part.Size = Vector3.new(size/size-.1,size+(size/10),size+(size/10))
part.Shape = 'Cylinder'
part.Material = 'DiamondPlate'

for i = 1,posts do
local post = Instance.new("Part", script)
post.Anchored = true
post.Size = Vector3.new(size/2,size/10,size/10)
post.Shape = 'Cylinder'
post.Material = 'DiamondPlate'

X = math.sin(i * (circle/posts))*size/2
Z = math.cos(i * (circle/posts))*size/2

post.CFrame = CF * CFrame.new(X,0-(size/4),Z) * CFrame.Angles(0,0,math.rad(90))

end
end

trampoline(10,10,300)

print("c/ trampoline(posts,size,strength)")