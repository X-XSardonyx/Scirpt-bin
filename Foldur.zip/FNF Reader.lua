charts={
expurgation={[[https://raw.githubusercontent.com/X-XSardonyx/VSB-Scripts/main/expurgation-hard.json]], 6900844331, "Expurgation"},
happy={[[https://raw.githubusercontent.com/X-XSardonyx/VSB-Scripts/main/really-happy-hard.json]], 7795670300, "Really Happy"},
roses={[[https://raw.githubusercontent.com/ninjamuffin99/Funkin/master/assets/preload/data/roses/roses.json]], 6337428158, "Roses"},
fresh={[[https://raw.githubusercontent.com/ninjamuffin99/Funkin/master/assets/preload/data/fresh/fresh.json]] ,6025191328,"Fresh"},
winterhorrorland={[[https://raw.githubusercontent.com/ninjamuffin99/Funkin/master/assets/preload/data/winter-horrorland/winter-horrorland.json]] ,6275837083,'Winter Horrorland'},
south={[[https://raw.githubusercontent.com/ninjamuffin99/Funkin/master/assets/preload/data/south/south.json]] ,6038765924 ,'South'},
nonsence={[[https://raw.githubusercontent.com/X-XSardonyx/VSB-Scripts/main/nonsence.json]], 7102185418 ,"nonsense"},
commonsense={[[https://raw.githubusercontent.com/X-XSardonyx/VSB-Scripts/main/Common%20sense.json]], 7112426008, 'Common Sense'},
opheebop={[[https://raw.githubusercontent.com/Radhew/Salt-Engine/master/assets/preload/data/opheebop/opheebop.json]], 6730593959, 'Opheebop'},
bsmilf={[[https://raw.githubusercontent.com/kckarnige/fnf-week-7-code/main/src/assets/data/milf/milf.json]], 7071427516, 'B-Side Milf'},
endless={[[https://raw.githubusercontent.com/CryBitDev/Sonic.exe-source-1.5/master/assets/preload/data/endless/endless-hard.json]] ,7313871314 ,"Endless"},
sunshine={[[https://raw.githubusercontent.com/wildythomas/mmmbob/main/assets/preload/data/sunshine/sunshine.json]] , 6822649446 ,'Sunshine'},
withered={[[https://raw.githubusercontent.com/wildythomas/mmmbob/main/assets/preload/data/withered/withered.json]] , 6822655743 ,'Withered'},
run={[[https://raw.githubusercontent.com/wildythomas/mmmbob/main/assets/preload/data/run/run.json]], 6822647318, 'RUN'},
release={[[https://raw.githubusercontent.com/Rageminer996/Smoke-Em-Out-Struggle-Mod/main/assets/preload/data/release/release.json]], 6767491531, 'Release'},
nerves={[[https://raw.githubusercontent.com/Rageminer996/Smoke-Em-Out-Struggle-Mod/main/assets/preload/data/nerves/nerves.json]], 6763964321, 'Nerves'},
headache={[[https://raw.githubusercontent.com/Rageminer996/Smoke-Em-Out-Struggle-Mod/main/assets/preload/data/headache/headache.json]], 6765405147,'Headache'},
fading={[[https://raw.githubusercontent.com/Rageminer996/Smoke-Em-Out-Struggle-Mod/main/assets/preload/data/fading/fading.json]], 6770738952 , 'Fading'},
magelo={[[https://fnf-songs.errortp.repl.co/megalostrikeback.html]], 6745517883,'Magelostrikeback'},
otherfriends={[[https://raw.githubusercontent.com/theevity1/VS-Spinel/master/assets/preload/data/other-friends/other-friends.json]], 7490567703, 'Other Friends'},
flippyroll={[[https://raw.githubusercontent.com/Yirius125/FNF-VsFliqpy-1.5-Full-Week-Engine/main/assets/preload/data/flippy-roll/flippy-roll.json]], 7047986662, 'Flippy-Roll'},
finaldestination={[[https://raw.githubusercontent.com/GithubSPerez/shaggy-matt/main/assets/preload/data/final-destination/final-destination-god.json]], 7057969804 , 'Final Destination'},
nonsensical={[[https://raw.githubusercontent.com/X-XSardonyx/VSB-Scripts/main/nonsensical.json]], 7361704969, "Nonsensical"},
playtime={[[https://raw.githubusercontent.com/X-XSardonyx/VSB-Scripts/main/Playtime.json]], 7838052823,'Playtime'},
nohero={[[https://raw.githubusercontent.com/X-XSardonyx/VSB-Scripts/main/no-hero.json]], 7951754097, 'No-Hero'},
change={[[https://raw.githubusercontent.com/X-XSardonyx/VSB-Scripts/main/you'll-make-the-change-hard.json]], 8055850993, "Youll Make The Change"},
MONOCHROME = {[[https://raw.githubusercontent.com/Yoshubs/Hypnos-Lullaby/master/assets/preload/data/monochrome/monochrome.json]], 7860856702, "Monochrome"}

}
currentchart = nil

frame = Instance.new("Frame", Instance.new("ScreenGui", owner.PlayerGui))
frame.Size = UDim2.new(.25,0,.75,0)
frame.BackgroundTransparency = .9
frame.Position = UDim2.new(.375,0,.125,0)
num = 0

NUM = 0

for i,v in pairs(charts) do
NUM = NUM + 1
end

for I,v in pairs(charts) do
num = num + 1
button = Instance.new("TextButton",frame)
button.Size = UDim2.new(1,0,1/NUM,0)
button.BackgroundTransparency = .5
button.BackgroundColor = BrickColor.new("Really black")
button.TextColor = BrickColor.new("Institutional white")
button.TextScaled = true
button.BorderSizePixel = 0
button.Text = v[3]

button.Position = UDim2.new(0,0,num/NUM,0) - UDim2.new(0,0,1/NUM,0)

button.MouseButton1Click:Connect(function()
frame.Parent:Destroy()
currentchart = v
end)

end

repeat task.wait() until currentchart ~= nil

HTTP = game:GetService("HttpService")
Data = HTTP:JSONDecode(HTTP:GetAsync(currentchart[1]))
print(Data.song.song)
keys = Data.song.notes

local sound = Instance.new("Sound", owner.Character.HumanoidRootPart)
sound.SoundId = 'rbxassetid://'..currentchart[2]
sound.Volume = 1
sound.MaxDistance = 100
sound:Play()

for i,v in pairs(owner.Character:GetDescendants()) do
if v:IsA("Motor6D") then
local weld = Instance.new("Weld", v.Parent)
weld.Part1 = v.Part1
weld.Part0 = v.Part0
weld.C0 = v.C0
weld.C1 = v.C1
weld.Name = v.Name
v:Destroy()
end
end

AnimDefaults = {
Head = owner.Character.Torso.Neck.C0,
Torso = owner.Character.HumanoidRootPart.RootJoint.C0,
Larm = owner.Character.Torso["Left Shoulder"].C0,
Rarm = owner.Character.Torso["Right Shoulder"].C0,
Lleg = owner.Character.Torso["Left Hip"].C0,
Rleg = owner.Character.Torso["Right Hip"].C0
}
Head = owner.Character.Torso.Neck
Torso = owner.Character.HumanoidRootPart.RootJoint
Larm = owner.Character.Torso["Left Shoulder"]
Rarm = owner.Character.Torso["Right Shoulder"]
Lleg = owner.Character.Torso["Left Hip"]
Rleg = owner.Character.Torso["Right Hip"]

--6074619806

UP = {

Head = AnimDefaults.Head * CFrame.Angles(0,0,math.rad(20)),
Torso = AnimDefaults.Torso * CFrame.Angles(0,0,math.rad(10)),
Larm = AnimDefaults.Larm * CFrame.Angles(0,0,math.rad(20)),
Rarm = AnimDefaults.Rarm * CFrame.Angles(0,0,math.rad(105)),
Lleg = AnimDefaults.Lleg * CFrame.Angles(0,0,math.rad(10)),
Rleg = AnimDefaults.Rleg * CFrame.Angles(0,0,math.rad(10))

}

LEFT = {

Head = AnimDefaults.Head * CFrame.Angles(0,0,math.rad(-10)),
Torso = AnimDefaults.Torso * CFrame.Angles(0,0,math.rad(-15)),
Larm = AnimDefaults.Larm * CFrame.Angles(0,0,math.rad(20)),
Rarm = AnimDefaults.Rarm * CFrame.Angles(0,math.rad(30),math.rad(105)),
Lleg = AnimDefaults.Lleg * CFrame.Angles(0,0,math.rad(-10)),
Rleg = AnimDefaults.Rleg * CFrame.Angles(0,0,math.rad(-10))

}

DOWN = {

Torso = AnimDefaults.Torso,
Head = AnimDefaults.Head,
Rarm = AnimDefaults.Rarm * CFrame.Angles(0,math.rad(45), math.rad(80)),
Larm = AnimDefaults.Larm *  CFrame.new(-.5,-.25,.5) * CFrame.Angles(0,math.rad(130), math.rad(80)),
Lleg = AnimDefaults.Lleg * CFrame.new(0,0,0) * CFrame.Angles(0,math.rad(15),0),
Rleg = AnimDefaults.Rleg * CFrame.new(0,0,0) *  CFrame.Angles(0,math.rad(0),0)
}

RIGHT = {

Torso = AnimDefaults.Torso * CFrame.new(0,0,0),
Rarm = AnimDefaults.Rarm * CFrame.new(.5,0,.5) * CFrame.Angles(0,math.rad(-90), math.rad(90)),
Larm = AnimDefaults.Larm *  CFrame.new(0,-.25,0) * CFrame.Angles(0,math.rad(10), math.rad(10)),
Lleg = AnimDefaults.Lleg * CFrame.new(0,0,0) * CFrame.Angles(0,math.rad(15),0),
Rleg = AnimDefaults.Rleg * CFrame.new(0,0,0) *  CFrame.Angles(0,math.rad(0),0),
Head = AnimDefaults.Head
}

posing=false

function key(num)
posing = true


if num == 0 then
for i = 1,3 do
task.wait()

Torso.C0 = AnimDefaults.Torso
Head.C0 = AnimDefaults.Head
Larm.C0 = AnimDefaults.Larm
Rarm.C0 = AnimDefaults.Rarm
Lleg.C0 = AnimDefaults.Lleg
Rleg.C0 = AnimDefaults.Rleg

Head.C0 = Head.C0:Lerp(LEFT.Head, i/3)
Torso.C0 = Torso.C0:Lerp(LEFT.Torso, i/3)
Larm.C0 = Larm.C0:Lerp(LEFT.Larm, i/3)
Rarm.C0 = Rarm.C0:Lerp(LEFT.Rarm, i/3)
Lleg.C0 = Lleg.C0:Lerp(LEFT.Lleg, i/3)
Rleg.C0 = Rleg.C0:Lerp(LEFT.Rleg, i/3)

owner.Character.Torso.Color = owner.Character.Torso.Color:Lerp(Color3.fromHSV(num/4,1,1), .3)
end
elseif num == 1 then
for i = 1,3 do
task.wait()
Torso.C0 = AnimDefaults.Torso
Head.C0 = AnimDefaults.Head
Larm.C0 = AnimDefaults.Larm
Rarm.C0 = AnimDefaults.Rarm
Lleg.C0 = AnimDefaults.Lleg
Rleg.C0 = AnimDefaults.Rleg

Head.C0 = Head.C0:Lerp(UP.Head, i/3)
Torso.C0 = Torso.C0:Lerp(UP.Torso, i/3)
Larm.C0 = Larm.C0:Lerp(UP.Larm, i/3)
Rarm.C0 = Rarm.C0:Lerp(UP.Rarm, i/3)
Lleg.C0 = Lleg.C0:Lerp(UP.Lleg, i/3)
Rleg.C0 = Rleg.C0:Lerp(UP.Rleg, i/3)

owner.Character.Torso.Color = owner.Character.Torso.Color:Lerp(Color3.fromHSV(num/4,1,1), .3)
end
elseif num == 2 then
for i = 1,3 do
task.wait()

Torso.C0 = AnimDefaults.Torso
Head.C0 = AnimDefaults.Head
Larm.C0 = AnimDefaults.Larm
Rarm.C0 = AnimDefaults.Rarm
Lleg.C0 = AnimDefaults.Lleg
Rleg.C0 = AnimDefaults.Rleg

Head.C0 = Head.C0:Lerp(DOWN.Head, i/3)
Torso.C0 = Torso.C0:Lerp(DOWN.Torso, i/3)
Larm.C0 = Larm.C0:Lerp(DOWN.Larm, i/3)
Rarm.C0 = Rarm.C0:Lerp(DOWN.Rarm, i/3)
Lleg.C0 = Lleg.C0:Lerp(DOWN.Lleg, i/3)
Rleg.C0 = Rleg.C0:Lerp(DOWN.Rleg, i/3)

owner.Character.Torso.Color = owner.Character.Torso.Color:Lerp(Color3.fromHSV(num/4,1,1), .3)
end
elseif num == 3 then
for i = 1,3 do
task.wait()
Torso.C0 = AnimDefaults.Torso
Head.C0 = AnimDefaults.Head
Larm.C0 = AnimDefaults.Larm
Rarm.C0 = AnimDefaults.Rarm
Lleg.C0 = AnimDefaults.Lleg
Rleg.C0 = AnimDefaults.Rleg

Head.C0 = Head.C0:Lerp(RIGHT.Head, i/3)
Torso.C0 = Torso.C0:Lerp(RIGHT.Torso, i/3)
Larm.C0 = Larm.C0:Lerp(RIGHT.Larm, i/3)
Rarm.C0 = Rarm.C0:Lerp(RIGHT.Rarm, i/3)
Lleg.C0 = Lleg.C0:Lerp(RIGHT.Lleg, i/3)
Rleg.C0 = Rleg.C0:Lerp(RIGHT.Rleg, i/3)
owner.Character.Torso.Color = owner.Character.Torso.Color:Lerp(Color3.fromHSV(num/4,1,1), .3)
end

end
for i = 1,10 do
if posing then
break
else
task.wait()
end
end
posing = false
end

for i = 1, #keys do

		sectionkeys = keys[i]["sectionNotes"]
		bpm = keys[i]["bpm"] or 0
		if not keys[i]["mustHitSection"] then
		for b = 1, #sectionkeys do
			local what = sectionkeys[b]
			coroutine.wrap(function()
				task.wait((what[1]/1000)-1)
				if what[2] == 0 then
					key(0)
				end
				if what[2] == 1 then
					key(1)
				end
				if what[2] == 2 then
					key(2)
				end
				if what[2] == 3 then
					key(3)
				end
			end)()
		end
		else
		for b = 1, #sectionkeys do
			local what = sectionkeys[b]
			coroutine.wrap(function()
				task.wait((what[1]/1000)-1)
				if what[2] == 4 then
					key(4)
				end
				if what[2] == 5 then
					key(5)
				end
				if what[2] == 6 then
					key(6)
				end
				if what[2] == 7 then
					key(7)
				end
			end)
		end
		end	
		
		
		
				if keys[i]["mustHitSection"] then
		for b = 1, #sectionkeys do
			local what = sectionkeys[b]
			coroutine.wrap(function()
				task.wait((what[1]/1000)-1)
				if what[2] == 0 then
					key(0)
				end
				if what[2] == 1 then
					key(1)
				end
				if what[2] == 2 then
					key(2)
				end
				if what[2] == 3 then
					key(3)
				end
			end)()
		end
		else
		for b = 1, #sectionkeys do
			local what = sectionkeys[b]
			coroutine.wrap(function()
				task.wait((what[1]/1000)-1)
				if what[2] == 4 then
					key(4)
				end
				if what[2] == 5 then
					key(5)
				end
				if what[2] == 6 then
					key(6)
				end
				if what[2] == 7 then
					key(7)
				end
			end)
		end
		end	
		
		
		
	end