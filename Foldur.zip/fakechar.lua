owner.Character.Parent = owner

local rem = Instance.new("RemoteEvent", owner.PlayerGui)

local E = Instance.new("WorldModel", script)

local hum = Instance.new("Part", E)
hum.CanCollide = false
hum.Anchored = true
hum.Size = Vector3.new(2,2,1)
hum.Material = 'SmoothPlastic'
hum.Name = 'focus'
hum.Locked = true
hum.Archivable = false


local head = Instance.new("Part", E)
head.CanCollide = false
head.Anchored = true
head.Size = Vector3.new(1.25,1.25,1.25)
head.Material = 'SmoothPlastic'
head.Locked = true
head.Archivable = false


local la = Instance.new("Part", E)
la.CanCollide = false
la.Anchored = true
la.Size = Vector3.new(1,2,1)
la.Material = 'SmoothPlastic'
la.Locked = true
la.Archivable = false


local ra = Instance.new("Part", E)
ra.CanCollide = false
ra.Anchored = true
ra.Size = Vector3.new(1,2,1)
ra.Material = 'SmoothPlastic'
ra.Locked = true
ra.Archivable = false


local ll = Instance.new("Part", E)
ll.CanCollide = false
ll.Anchored = true
ll.Size = Vector3.new(1,2,1)
ll.Material = 'SmoothPlastic'
ll.Locked = true
ll.Archivable = false


local rl = Instance.new("Part", E)
rl.CanCollide = false
rl.Anchored = true
rl.Size = Vector3.new(1,2,1)
rl.Material = 'SmoothPlastic'
rl.Locked = true
rl.Archivable = false

local newvalue = Instance.new("ObjectValue", owner.Character)
newvalue.Value = script
newvalue.Name = 'OWO'

NLS([[owner.Character.Parent = workspace 
local rem = owner.PlayerGui.RemoteEvent 

for i,v in pairs(owner.Character.OWO.Value:GetDescendants()) do
if v:IsA("BasePart") then
v.Transparency = .5
end
end

while wait(1/30) do 
rem:FireServer({owner.Character.Torso.CFrame,owner.Character.Head.CFrame,owner.Character["Left Arm"].CFrame,owner.Character["Right Arm"].CFrame,owner.Character["Left Leg"].CFrame,owner.Character["Right Leg"].CFrame}) 
end


]], owner.PlayerGui)

Instance.new("BlockMesh", hum).Offset = Vector3.new(0,0,10000)
Instance.new("SpecialMesh", head).Offset = Vector3.new(0,0,10000)
Instance.new("BlockMesh", ll).Offset = Vector3.new(0,0,10000)
Instance.new("BlockMesh", rl).Offset = Vector3.new(0,0,10000)
Instance.new("BlockMesh", la).Offset = Vector3.new(0,0,10000)
Instance.new("BlockMesh", ra).Offset = Vector3.new(0,0,10000)


rem.OnServerEvent:Connect(function(plr, cf)

script.Name = tick()
hum.CFrame = cf[1] * CFrame.new(0,0,-10000)
head.CFrame = cf[2] * CFrame.new(0,0,-10000)
la.CFrame = cf[3] * CFrame.new(0,0,-10000)
ra.CFrame = cf[4] * CFrame.new(0,0,-10000)
ll.CFrame = cf[5] * CFrame.new(0,0,-10000)
rl.CFrame = cf[6] * CFrame.new(0,0,-10000)

end)