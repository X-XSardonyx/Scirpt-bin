print("I_SEE_YOU By Alfie1728 / X_XSardonyx")

local cheekyface = 144080495

local ball = Instance.new("Part")
ball.Size = Vector3.new(10,10,10)
ball.Material = 'Slate'
ball.Shape = 'Ball'
ball.Locked = true
ball.Transparency = 0
ball.CFrame = owner.Character.HumanoidRootPart.CFrame

local decal = Instance.new("Decal", ball)
decal.Texture = 'rbxassetid://'..cheekyface
decal.Transparency = -1.5

local orbit = Instance.new("Part", script)
orbit.Size = Vector3.new(2,2,2)
orbit.CanCollide = false
orbit.Shape = 'Ball'
orbit.Material = 'Slate'
orbit.Anchored = true

decal:Clone().Parent = orbit

owner.Character.Parent = owner

local rem = Instance.new("RemoteEvent", owner.PlayerGui)

Instance.new("ObjectValue", owner.Character).Value = ball

local fakearm1 = Instance.new("Part")
fakearm1.Anchored = true
fakearm1.CanCollide = false
fakearm1.Size = Vector3.new(1,1,15)
fakearm1.Material = 'Slate'
fakearm1.Transparency = 1

NLS(" owner:GetMouse().TargetFilter = owner.Character.Value.Value.Parent local rem = owner.PlayerGui.RemoteEvent local cam = workspace.CurrentCamera cam.CameraSubject = owner.Character.Value.Value local hum = owner.Character.Humanoid  while wait(1/30) do rem:FireServer(hum.MoveDirection, owner:GetMouse().Hit.Position) end ", owner.PlayerGui)

wait(.25)

local effect = Instance.new("Part", script)
effect.Size = Vector3.new(1000,20,20)
effect.CanCollide = false
effect.Shape = 'Cylinder'
effect.Material = 'Neon'
effect.Anchored = true
effect.CFrame = CFrame.new(owner.Character.HumanoidRootPart.Position) * CFrame.Angles(0,0,math.rad(90))
game:GetService("Debris"):AddItem(effect, 3)


game:GetService("TweenService"):Create(effect, TweenInfo.new(3), {Size = Vector3.new(1000,1,1)}):Play()

ball.Parent = script
fakearm1.Parent = script


rem.OnServerEvent:Connect(function(plr, speed, look)
ball.Velocity = speed * 25
fakearm1.CFrame = fakearm1.CFrame:Lerp(CFrame.new(ball.Position, look) * CFrame.new(-6,0,-7.5), .25)


local X = math.sin(tick() * 5 / (2 * math.pi)) * 10
local Z = math.cos(tick() * 5 / (2 * math.pi)) * 10

orbit.CFrame = CFrame.new(CFrame.new(ball.Position) * CFrame.new(X,0,Z).Position, ball.Position)

end)