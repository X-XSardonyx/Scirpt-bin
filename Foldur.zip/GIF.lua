gifs = {Fox = {gifid = 'rbxassetid://3529154445', size = Vector3.new(15.5, 10,0), fps = 20, rows = 10, columns = 6, frames = 55},
bigshot = {gifid = 'rbxassetid://8035945955', size = Vector3.new(13, 15,0), fps = 20, rows = 4, columns = 5, frames = 19},
ball = {gifid = 'rbxassetid://8231239188', size = Vector3.new(15, 15,0), fps = 20, rows = 3, columns = 3, frames = 9},
spin = {gifid = 'rbxassetid://5146732133', size = Vector3.new(15, 15,0), fps = 20, rows = 5, columns = 5, frames = 24},
troll = {gifid = 'rbxassetid://6969714781', size = Vector3.new(15, 15,0), fps = 20, rows = 5, columns = 7, frames = 31},
smol = {gifid = 'rbxassetid://7081710171', size = Vector3.new(15, 13,0), fps = 20, rows = 12, columns = 13, frames = (12*13-8)},
Virus = {gifid = 'rbxassetid://8471992839', size = Vector3.new(15,13,0), fps = 20, rows = 30, columns = 5, frames = 149}
}

--7081710171

GIF = gifs.smol

part = workspace.scen
--part.CFrame = owner.Character.PrimaryPart.CFrame * CFrame.new(0,3.5,-10) * CFrame.Angles(0,math.rad(180),0)


gif = Instance.new("Texture", part)
gif.Texture = GIF.gifid

local Frames = GIF.frames --Amount of frames in gif
local currentFrame = 1

local rows = GIF.rows
local columns = GIF.columns

local currentRow,CurrentColumn = 0,0

local linear = false

local fps = 20 -- Max 30
local full60fps = false

local size = part.Size -- The gif should be on the front of the part

gif.StudsPerTileU = columns*size.X
gif.StudsPerTileV = rows*size.Y

while true do
	if not full60fps then wait(1/fps) else game:GetService("RunService").Stepped:Wait() end
	if linear then
		gif.OffsetStudsU = gif.OffsetStudsU + size.X
		if gif.OffsetStudsU > gif.StudsPerTileU then
			gif.OffsetStudsU = 0
		end
	else
		CurrentColumn = CurrentColumn + 1
		if CurrentColumn > columns then
			CurrentColumn = 1
			currentRow = currentRow + 1
		end
		if currentFrame > Frames then
			currentRow,CurrentColumn,currentFrame = 1,1,1
		end
		gif.OffsetStudsU = size.X*(CurrentColumn-1)
		gif.OffsetStudsV = size.Y*(currentRow-1)
		currentFrame = currentFrame+1
	end
end