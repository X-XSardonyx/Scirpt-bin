local bonk = Instance.new("Tool", owner.Backpack)
bonk.Name = 'no horni'


local handle = Instance.new("Part", bonk)
handle.Size = Vector3.new(1.25,1.25,1.25)
handle.Name = 'Handle'
handle.Massless = true
handle.Material = 'SmoothPlastic'

local R6C0 = CFrame.new(0,1,0,-1,-0,-0,0,0,1,0,1,0)
local R15C0 = CFrame.new(-5.96046448e-08,0.799999952,1.1920929e-07,1,0,0,0,1,0,0,0,1)

local materials = {'Grass', 'Glass', 'Granite', 'Marble', 'Slate', 'ForceField', 'Neon'}

game:GetService'RunService'.Heartbeat:Connect(function()

handle.Material = materials[math.random(1, #materials)]
handle.BrickColor = BrickColor.Random()

end)

handle.Touched:Connect(function(part)
if part.Name == 'Head' and part:FindFirstChild("Mesh") then
part.Mesh.Scale = Vector3.new(1.25,.75,1.25)
part.Mesh.Offset = Vector3.new(0,.25,0)
if part.Parent.Humanoid.RigType == Enum.HumanoidRigType.R6 then

part.Parent.Torso.Neck.C0 = R6C0 * CFrame.new(0,0,-.5)
else
part.Neck.C0 = R15C0 * CFrame.new(0,-.5,0)
end
end
end)