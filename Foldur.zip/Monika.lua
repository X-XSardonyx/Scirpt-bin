for i,v in pairs(owner.Character:GetDescendants()) do
if v:IsA("Motor6D") then
local weld = Instance.new("Weld", v.Parent)
weld.Part1 = v.Part1
weld.Part0 = v.Part0
weld.C0 = v.C0
weld.C1 = v.C1
weld.Name = v.Name
v:Destroy()
end
end

Attack = false

script.Parent = owner.Character

--Anim Defaults
AnimDefaults = {
Head = owner.Character.Torso.Neck.C0,
Torso = owner.Character.HumanoidRootPart.RootJoint.C0,
Larm = owner.Character.Torso["Left Shoulder"].C0,
Rarm = owner.Character.Torso["Right Shoulder"].C0,
Lleg = owner.Character.Torso["Left Hip"].C0,
Rleg = owner.Character.Torso["Right Hip"].C0
}
--Setting Joints
Head = owner.Character.Torso.Neck
Torso = owner.Character.HumanoidRootPart.RootJoint
Larm = owner.Character.Torso["Left Shoulder"]
Rarm = owner.Character.Torso["Right Shoulder"]
Lleg = owner.Character.Torso["Left Hip"]
Rleg = owner.Character.Torso["Right Hip"]

owner.Character.Head:ClearAllChildren()

Instance.new("SpecialMesh", owner.Character.Head).Scale = Vector3.new(1.25,1.25,1.25)


local eye1 = Instance.new("Part", owner.Character.Head)
eye1.Size = Vector3.new(.2,.3,.2)
eye1.CanCollide = false
eye1.Massless = false
eye1.Material = 'Neon'
eye1.BrickColor = BrickColor.new("Lime green")

Instance.new("SpecialMesh", eye1).MeshType = 'Sphere'


local weld1 = Instance.new("Weld", eye1)
weld1.Part1 = eye1
weld1.Part0 = owner.Character.Head
weld1.C0 = CFrame.new(.2,.15,-.55)

local eye2 = Instance.new("Part", owner.Character.Head)
eye2.Size = Vector3.new(.2,.3,.2)
eye2.CanCollide = false
eye2.Massless = false
eye2.Material = 'Neon'
eye2.BrickColor = BrickColor.new("Lime green")

Instance.new("SpecialMesh", eye2).MeshType = 'Sphere'


local weld2 = Instance.new("Weld", eye2)
weld2.Part1 = eye2
weld2.Part0 = owner.Character.Head
weld2.C0 = CFrame.new(-.2,.15,-.55)

sine = 0

game:GetService("RunService").Heartbeat:connect(function()
sine=sine+.1

if owner.Character.HumanoidRootPart.Velocity.Magnitude < 1 then
Torso.C0 = Torso.C0:Lerp(AnimDefaults.Torso * CFrame.new(0,0,(math.sin(sine/5)/10)) * CFrame.Angles(math.rad(math.sin(sine/5))*3,0,math.rad(math.cos(sine/5))*3), .25)
Head.C0 = Head.C0:Lerp(AnimDefaults.Head * CFrame.Angles(math.rad(math.cos(sine/10))*5,math.rad(math.sin(sine/10))*5,math.rad(math.cos(sine/5))*10), .25)
Larm.C0 = Larm.C0:Lerp(AnimDefaults.Larm * CFrame.new(0,-.1+math.cos(sine/5)/5,0) * CFrame.Angles(0,math.rad(35),-math.rad(10 + math.sin(sine/5)*10)), .25)
Rarm.C0 = Rarm.C0:Lerp(AnimDefaults.Rarm * CFrame.new(0,-.1+math.cos(sine/5)/5,0) * CFrame.Angles(0,-math.rad(35),math.rad(10 + math.sin(sine/5)*10)), .25)
Lleg.C0 = Lleg.C0:Lerp(AnimDefaults.Lleg * CFrame.new(0,-.1+math.sin(sine/5)/10,0) * CFrame.Angles(math.rad(0),math.rad(40),math.rad(5+math.cos(sine/5)*5)), .25)
Rleg.C0 = Rleg.C0:Lerp(AnimDefaults.Rleg * CFrame.new(0,-.1+math.sin(sine/5)/10,0) * CFrame.Angles(0,0,-math.rad(7+math.sin(sine/5)*7)), .25)

else

Torso.C0 = Torso.C0:Lerp(AnimDefaults.Torso * CFrame.new(0,0,math.sin(sine*2)/5), .25)
Rarm.C0 = Rarm.C0:Lerp(AnimDefaults.Rarm *  CFrame.Angles(0,math.rad(math.cos(sine) * 30), -math.rad(math.cos(sine ) * 45)), .25)
Larm.C0 = Larm.C0:Lerp(AnimDefaults.Larm *  CFrame.Angles(0,math.rad(math.cos(sine) * 30), -math.rad(math.cos(sine ) * 45)), .25)
Lleg.C0 = Lleg.C0:Lerp(AnimDefaults.Lleg * CFrame.new(0,.2+math.cos(sine)/5,0) *  CFrame.Angles(0,-math.rad(0), math.rad(math.sin(sine) * 45)), .25)
Rleg.C0 = Rleg.C0:Lerp(AnimDefaults.Rleg * CFrame.new(0,.2+math.cos(sine)/5,0) * CFrame.Angles(0,-math.rad(0), math.rad(math.sin(sine) * 45)), .25)
Head.C0 = Head.C0:Lerp(AnimDefaults.Head, .25)

end
end)