local ID = 4646253758


local Amplifyer = 1
local Offset = CFrame.new(0,-3,0)
local Rainbow = false
local DOUBLERING = true
local numberOfParts = 30

local fullCircle = 2 * math.pi
local radius = 10

local CurrentColor = BrickColor.new("Really red").Color
local basecolor = BrickColor.new("Really black").Color
local BCBackup = BrickColor.new("Really black").Color


local character = owner.Character
local hrp = character:WaitForChild("HumanoidRootPart")

local parts = {}




for _ = 1, numberOfParts do
	table.insert(parts, Instance.new("Part", script))
end



for i, part in pairs(parts) do
	part.Anchored = true
	part.Locked = true
	part.CanCollide = false
	part.Size = Vector3.new(2,2,0)
	part.Color = basecolor
	part.Material = 'Neon'
	
	game:GetService("RunService").Heartbeat:Connect(function()
	part.Size = part.Size:Lerp(Vector3.new(2,0,0), .1)
	part.Color = part.Color:Lerp(basecolor, .1)
	wait()
	end)
	
end





local function getXAndZPositions(angle)
	local x = math.cos(angle) * radius
	local z = math.sin(angle) * radius
	return x, z
end

game:GetService("RunService").Heartbeat:Connect(function()

	for i, part in pairs(parts) do
		local angle = i * (fullCircle / #parts)
		local x, z = getXAndZPositions(angle)
		
		local position = (hrp.CFrame * Offset * CFrame.Angles(0,math.rad(90),0) * CFrame.new(x, 0, z)).p
		local lookAt = hrp.Position
		
		part.CFrame = CFrame.new(position, lookAt)
	end
	
end)

wait(1)

local sound = Instance.new("Sound", parts[math.random(1, #parts)])
sound.SoundId = 'rbxassetid://'..ID
sound.Volume = 1
sound.Looped = true
sound:Play()
sound.Name = 'AUDIO'
sound.MaxDistance = 50

print("use: Music SOUNDID to change the music id. this is a command so it must be in chat")
owner.Chatted:Connect(function(msg)
local message = string.split(msg, '.')
if string.lower(message[1]) =='music' then
sound:Stop()
sound.SoundId = 'rbxassetid://'..message[2]
sound:Play()
wait()
elseif string.lower(message[1]) =='volume' then
sound.Volume = message[2]
wait()
elseif string.lower(message[1]) =='pitch' then
sound.Pitch = message[2]
wait()
elseif string.lower(message[1]) =='amplify' then
Amplifyer = message[2]
wait()
elseif string.lower(message[1]) =='radius' then
radius = message[2]
wait()
elseif string.lower(message[1]) =='color' then
CurrentColor = BrickColor.new(message[2]).Color
wait()
elseif string.lower(message[1]) =='basecolor' then
basecolor = BrickColor.new(message[2]).Color
BCBackup = BrickColor.new(message[2]).Color
wait()
elseif string.lower(message[1]) =='offset' then
Offset = CFrame.new(message[2],message[3],message[4])
wait()
elseif string.lower(message[1]) =='rainbow' then
if Rainbow == true then
Rainbow = false
basecolor = BrickColor.new("Really black").Color
color = BrickColor.new("Really red").Color
else 
Rainbow = true
end

elseif string.lower(message[1]) =='doublering' or string.lower(message[1]) =='db' then
if DOUBLERING == true then
DOUBLERING = false
else 
DOUBLERING = true
end

elseif string.lower(message[1]) =='material' or string.lower(message[1]) =='mat'  then
for j,part in pairs(parts) do
part.Material = message[2]
end

wait()
end
end)

local Value = Instance.new("ObjectValue", owner.Backpack)
Value.Value = sound


local event = Instance.new("RemoteEvent", script)


local REMVAL = Instance.new("ObjectValue", owner.Backpack)
REMVAL.Value = event
REMVAL.Name = 'RemoteEvent'




local ls = NLS("local event = owner.Backpack.RemoteEvent.Value local sound = owner.Backpack.Value.Value sound.MaxDistance = 100000000 while wait(1/30) do event:FireServer(sound.PlaybackLoudness) end", owner.Backpack)

local current = 1

event.OnServerEvent:Connect(function(plr, sound)
if current == numberOfParts then
current = 1
else
current = current + 1
end
local part = parts[current]
part.Size = Vector3.new(2,sound / 50 * Amplifyer,0)
part.Color = CurrentColor

if DOUBLERING == true then
local part2 = parts[numberOfParts - (current - 1)]
part2.Size = Vector3.new(2,sound / 50 * Amplifyer,0)
part2.Color = CurrentColor
end
end)



local colorloop = {"Really red", "Deep orange", "New Yeller", "Lime green", "Cyan", "Really blue", "Magenta"}



while wait() do
if Rainbow == true then
for i,v in pairs(colorloop) do
for i = 1,5 do
basecolor = basecolor:Lerp(BrickColor.new(v).Color, .25)
CurrentColor = CurrentColor:Lerp(BrickColor.new(v).Color, .25)

wait()
end
end
end
end