local ID = 225497763




local screen = Instance.new("Part", script)
screen.Size = Vector3.new(10,7.5, 0)
screen.BrickColor = BrickColor.new("Really black")
screen.Locked = true
screen.Anchored = true
screen.Material = 'SmoothPlastic'
screen.CanCollide = false

local statscreen = Instance.new("Part", script)
statscreen.Size = Vector3.new(5,5, 0)
statscreen.BrickColor = BrickColor.new("Really black")
statscreen.Locked = true
statscreen.Anchored = true
statscreen.Material = 'SmoothPlastic'
statscreen.CanCollide = false

local SG2 = Instance.new("SurfaceGui", statscreen)




local SG = Instance.new("SurfaceGui", screen)
local ROT = Instance.new("Frame", SG)
ROT.Size = UDim2.new(1,0,1,0)
ROT.BackgroundTransparency = 1
ROT.Rotation = 180

local frames = {}

for i = 1,8 do
	local frame = Instance.new("Frame", ROT)
	frame.Size = UDim2.new(.1,0,.1,0)
	frame.BackgroundColor3 = BrickColor.new("Institutional white").Color
	frame.BorderSizePixel = 0
	frame.Position = UDim2.new(i / 10,0,0,0)
table.insert(frames, frame)
end

local sound = Instance.new("Sound", screen)
sound.SoundId = 'rbxassetid://'..ID
sound.Volume = 1
sound.Looped = true
sound:Play()
sound.Name = 'AUDIO'
sound.MaxDistance = 50

local soundstat1 = Instance.new("TextBox", SG2)
soundstat1.BackgroundTransparency = 1
soundstat1.Text = '[Sound Id]: '..sound.SoundId
soundstat1.TextColor = BrickColor.new("Institutional white")
soundstat1.TextSize = 30
soundstat1.Size = UDim2.new(1,0,.2,0)
soundstat1.Position = UDim2.new(0,0,0,0)
soundstat1.TextXAlignment = 'Left'

local soundstat2 = Instance.new("TextBox", SG2)
soundstat2.BackgroundTransparency = 1
soundstat2.Text = '[Sound Volume]: '..sound.Volume
soundstat2.TextColor = BrickColor.new("Institutional white")
soundstat2.TextSize = 30
soundstat2.Size = UDim2.new(1,0,.2,0)
soundstat2.Position = UDim2.new(0,0,.2,0)
soundstat2.TextXAlignment = 'Left'

local soundstat3 = Instance.new("TextBox", SG2)
soundstat3.BackgroundTransparency = 1
soundstat3.Text = '[Sound Pitch]: '..sound.Pitch
soundstat3.TextColor = BrickColor.new("Institutional white")
soundstat3.TextSize = 30
soundstat3.Size = UDim2.new(1,0,.2,0)
soundstat3.Position = UDim2.new(0,0,.4,0)
soundstat3.TextXAlignment = 'Left'

local soundstat4 = Instance.new("TextBox", SG2)
soundstat4.BackgroundTransparency = 1
soundstat4.Text = '[Sound Parent]: workspace.Script.Part.[ere]'
soundstat4.TextColor = BrickColor.new("Institutional white")
soundstat4.TextSize = 30
soundstat4.Size = UDim2.new(1,0,.2,0)
soundstat4.Position = UDim2.new(0,0,.6,0)
soundstat4.TextXAlignment = 'Left'

local soundstat5 = Instance.new("TextBox", SG2)
soundstat5.BackgroundTransparency = 1
soundstat5.Text = '[Sound Name]: '..game:GetService("MarketplaceService"):GetProductInfo(ID).Name
soundstat5.TextColor = BrickColor.new("Institutional white")
soundstat5.TextSize = 30
soundstat5.Size = UDim2.new(1,0,.2,0)
soundstat5.Position = UDim2.new(0,0,.8,0)
soundstat5.TextXAlignment = 'Left'


--game:GetService("MarketplaceService"):GetProductInfo(game.PlaceId).Name
local Value = Instance.new("ObjectValue", owner.PlayerGui)
Value.Value = sound


local event = Instance.new("RemoteEvent", owner.PlayerGui)

local ls = NLS("local event = owner.PlayerGui.RemoteEvent local sound = owner.PlayerGui.Value.Value while wait(1/30) do event:FireServer(sound.PlaybackLoudness) end", owner.PlayerGui)

event.OnServerEvent:Connect(function(plr, sound)
for i,v in pairs(frames) do
v.Size = UDim2.new(.1,0,0,sound / math.random(1,5))
end
end)

while wait() do
screen.CFrame = screen.CFrame:Lerp(owner.Character.PrimaryPart.CFrame * CFrame.new(0,1,-7.5) * CFrame.Angles(math.rad(20),math.rad(180),0), .25)
statscreen.CFrame = screen.CFrame * CFrame.new(7,0,0)
end