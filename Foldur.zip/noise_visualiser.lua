local circle = 2*math.pi
local radius = 5
local parts = 10

local sound = Instance.new("Sound", owner.Character.HumanoidRootPart)
sound.SoundId = 'rbxassetid://'..6945045428
sound.MaxDistance = 150
sound.Looped = true
sound:Play()

local loud = Instance.new("Part", script)
loud.Transparency = 1
loud.CanCollide = false
loud:SetNetworkOwner(owner)

val = Instance.new("ObjectValue", owner.Character)
val.Value = loud

for i = 1,parts do
local part = Instance.new("Part", script)
part.Anchored = true
part.Locked = true
part.Material = 'Neon'
part.CanCollide = false

--Instance.new("SpecialMesh", part).MeshType = 'Sphere'

coroutine.resume(coroutine.create(function()
CLR = BrickColor.new("Really black").Color
while true do
task.wait()

X = math.sin(i * (circle/parts) + (tick()/3))*radius
Z = math.cos(i * (circle/parts) + (tick()/3))*radius

siz = math.sin(math.noise(loud.Position.Y,i/10))*30

part.Size = part.Size:Lerp(Vector3.new(3.5,.25,siz), .05)

CLR = BrickColor.new("Really black").Color:Lerp(BrickColor.new("Pink").Color, part.Size.Z/7)

part.Color = part.Color:Lerp(CLR, .05)

part.CFrame = CFrame.new(owner.Character.HumanoidRootPart.Position - Vector3.new(-X,3,-Z), Vector3.new(owner.Character.HumanoidRootPart.Position.X,owner.Character.HumanoidRootPart.Position.Y-3,owner.Character.HumanoidRootPart.Position.Z)) * CFrame.new(0,0,part.Size.Z/2)
end
end))
end  

owner.Chatted:Connect(function(msg)
local message = string.split(msg, ' ')
if string.lower(message[1]) =='-music' then
sound:Stop()
sound.SoundId = 'rbxassetid://'..message[2]
sound:Play()
elseif string.lower(message[1]) =='-volume' then
sound.Volume = message[2]
elseif string.lower(message[1]) =='-pitch' then
sound.Pitch = message[2]
end
end) 

NLS([[
local sound = owner.Character.HumanoidRootPart.Sound

local part = owner.Character.Value.Value

bp = Instance.new("BodyPosition", part)
bp.MaxForce = Vector3.new(math.huge,math.huge,math.huge)
bp.P = 150000
bp.D = 1000

while true do
task.wait()
bp.Position = Vector3.new(0,sound.PlaybackLoudness,0)
end

]], owner.PlayerGui)