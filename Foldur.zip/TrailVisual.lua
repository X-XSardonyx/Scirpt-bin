local part = Instance.new("Part", script)
part.Size = Vector3.new(8,8,8)
part.CanCollide = false
part.Transparency = 1
part:SetNetworkOwner(owner)
local sound = Instance.new("Sound", part)
sound.SoundId = 'rbxassetid://4702816396'
sound.Volume = 1
sound.MaxDistance = 100
sound:Play()

val = Instance.new("ObjectValue", owner.Character)
val.Value = part

function maketrail(CF1,CF2)
att1 = Instance.new("Attachment", part)
att1.CFrame = CF1

att2 = Instance.new("Attachment", part)
att2.CFrame = CF2

trail = Instance.new("Trail", part)
trail.LightEmission = 100
trail.Attachment0 = att1
trail.Attachment1 = att2
trail.Lifetime = .15
trail.Texture = 'rbxassetid://'..7509141236

end
--side1
maketrail(CFrame.new(4,4,4),CFrame.new(-4,4,4))

maketrail(CFrame.new(4,4,4),CFrame.new(4,-4,4))

maketrail(CFrame.new(4,-4,4),CFrame.new(-4,-4,4))

maketrail(CFrame.new(-4,4,4),CFrame.new(-4,-4,4))

--size2
maketrail(CFrame.new(4,4,-4),CFrame.new(-4,4,-4))

maketrail(CFrame.new(4,4,-4),CFrame.new(4,-4,-4))

maketrail(CFrame.new(4,-4,-4),CFrame.new(-4,-4,-4))

maketrail(CFrame.new(-4,4,-4),CFrame.new(-4,-4,-4))

maketrail(CFrame.new(4,4,4), CFrame.new(4,4,-4))
maketrail(CFrame.new(-4,4,4), CFrame.new(-4,4,-4))
maketrail(CFrame.new(4,-4,4), CFrame.new(4,-4,-4))
maketrail(CFrame.new(-4,-4,4), CFrame.new(-4,-4,-4))

maketrail(CFrame.new(4,-4,4), CFrame.new(0,0,0))
maketrail(CFrame.new(4,-4,-4), CFrame.new(0,0,0))
maketrail(CFrame.new(-4,-4,4), CFrame.new(0,0,0))
maketrail(CFrame.new(-4,-4,-4), CFrame.new(0,0,0))

maketrail(CFrame.new(4,4,4), CFrame.new(0,0,0))
maketrail(CFrame.new(4,4,-4), CFrame.new(0,0,0))
maketrail(CFrame.new(-4,4,4), CFrame.new(0,0,0))
maketrail(CFrame.new(-4,4,-4), CFrame.new(0,0,0))

part2 = Instance.new("Part", part)
part2.CanCollide = false
part2.Material = 'Neon'
part2:SetNetworkOwner(owner)

NLS([[

part = script.Parent.Value
sound = part.Sound
part2 = part.Part

pos = Instance.new("BodyPosition", part)
pos2 = Instance.new("BodyPosition", part2)
gy = Instance.new("BodyGyro", part)

pos.MaxForce = Vector3.new(math.huge,math.huge,math.huge)
pos.P = 150000
pos.D = 1000

gy.MaxTorque = Vector3.new(math.huge,math.huge,math.huge)
gy.P = 150000
gy.D = 1000

sine = 0

game:GetService("RunService").RenderStepped:Connect(function()
sine = sine + sound.PlaybackLoudness/5 + 1
loud = sine

CF = CFrame.new(owner.Character.HumanoidRootPart.Position + Vector3.new(0,10,0)) * CFrame.Angles(math.rad(loud),math.rad(loud),math.rad(loud))
pos.Position = CF.Position
gy.CFrame = gy.CFrame:Lerp(CF, .05)
end)


]], val)

for i,trail in pairs(part:GetDescendants()) do
if trail:IsA("Trail") then
coroutine.resume(coroutine.create(function()
while true do
task.wait()
trail.Color = ColorSequence.new(Color3.fromHSV(tick()/3%1/1,1,1))
 end
 end))
end
end