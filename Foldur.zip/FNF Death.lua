local plr = game.Players.LocalPlayer
local hum = plr.Character.Humanoid

hum.Died:Connect(function()
local gui = Instance.new("ScreenGui", plr.PlayerGui)
gui.ResetOnSpawn = false
local frame = Instance.new("ViewportFrame", gui)
frame.Size = UDim2.new(1,0,1,0)
frame.BackgroundColor3 = Color3.new(0,0,0)
local button = Instance.new("TextButton", gui)
button.Size = UDim2.new(.25,0,.25,0)
button.BackgroundTransparency = 1
button.TextSize = 75
button.TextColor = BrickColor.new("Pink")
button.Text = 'Replay'
button.Position = UDim2.new(.4,0,.75,0)
button.Visible = false

local sound = Instance.new("Sound", plr.Character.Head)
sound.SoundId = 'rbxassetid://6052167677'
sound.Playing = true
sound.Volume = 100000

local cam = Instance.new("Camera", frame)
cam.CFrame = Workspace.CurrentCamera.CFrame
frame.CurrentCamera = cam
local model = Instance.new("Model", frame)
wait(.1)
for i,v in pairs(plr.Character:GetChildren()) do
v:Clone().Parent = model
end
wait(.25)
button.Visible = true
button.MouseButton1Click:Connect(function()
for i = 1,10 do 
frame.Transparency = frame.Transparency + .1
wait()
end
gui:Destroy()
end)

while wait(.5) do
for i = 1,3 do
button.TextSize = button.TextSize + 5
wait()
end
wait()
for i = 1,3 do
button.TextSize = button.TextSize - 5
wait()
end
end
end)