size = .5

owner.Character.Parent = owner

local body = Instance.new("Part", script)
local arm1 = Instance.new("Part", body)
local arm2 = Instance.new("Part", body)
local seat = Instance.new("Seat", body)


body.Size = Vector3.new(size*4,size*4,size*4)
body.Material = 'SmoothPlastic'
body.CFrame = owner.Character.HumanoidRootPart.CFrame
body.Shape = 'Ball'
body:SetNetworkOwner(owner)

Instance.new("BlockMesh", body)

arm1.Size = Vector3.new(1*size,1*size,5*size)
arm1.Material = 'SmoothPlastic'
arm1:SetNetworkOwner(owner)
arm1.Name = 'Arm1'

arm2.Size = Vector3.new(1*size,1*size,5*size)
arm2.Material = 'SmoothPlastic'
arm2:SetNetworkOwner(owner)
arm2.Name = 'Arm2'

seat.Size = Vector3.new(2,1,2)
seat.CanCollide = false
seat.Transparency = 1
seat.CFrame = CFrame.new(0,1000000,0)
seat:SetNetworkOwner(owner)

local value = Instance.new("ObjectValue",owner.PlayerGui)
value.Value = body
value.Name = 'VAL'

owner.Chatted:Connect(function(msg)

msg = string.split(string.lower(msg), ' ')

if msg[1] == '-size' then
if msg[2] then
body.Size = Vector3.new(msg[2],msg[2],msg[2])*4
arm1.Size = Vector3.new(1,1,5)*msg[2]
arm2.Size = Vector3.new(1,1,5)*msg[2]
seat.Size = Vector3.new(2,1,2)*msg[2]
end
end

end)

coroutine.wrap(function()

while wait(1) do
body:SetNetworkOwner(owner)
arm1:SetNetworkOwner(owner)
arm2:SetNetworkOwner(owner)
seat:SetNetworkOwner(owner)

end

end)()

NLS([[

local body = script.Parent.Value
local arm1 = body.Arm1
local arm2 = body.Arm2
local seat = body.Seat

for i,v in pairs({arm1,arm2, seat}) do
v.CanCollide = false
local pos = Instance.new("BodyPosition", v)
pos.MaxForce = Vector3.new(math.huge,math.huge,math.huge)
pos.P = 150000
pos.D = 1000

local gy = Instance.new("BodyGyro", v)
gy.MaxTorque= Vector3.new(math.huge,math.huge,math.huge)
gy.P = 150000
gy.D = 1000
end

local campart = Instance.new("Part")

local mouse = owner:GetMouse()

mouse.TargetFilter = workspace

local gy = Instance.new("BodyGyro", body)
gy.MaxTorque= Vector3.new(math.huge,math.huge,math.huge)
gy.P = 150000
gy.D = 1000

humanoid = owner.Character.Humanoid
workspace.CurrentCamera.CameraSubject = body

jumpDB = false

game:GetService("RunService").RenderStepped:Connect(function()
campart.CFrame = CFrame.new(body.Position, mouse.Hit.Position)
campart.Orientation = Vector3.new(0,campart.Orientation.Y,0)

gy.CFrame = campart.CFrame
velo = humanoid.MoveDirection*20
body.Velocity = Vector3.new(velo.X,body.Velocity.Y,velo.Z)

arm1CF = CFrame.new(body.CFrame * CFrame.new(body.Size.X/2,0,-body.Size.Z/2).Position, mouse.Hit.Position) * CFrame.new(0,0,-arm1.Size.Z/2)
arm1.BodyGyro.CFrame = arm1CF
arm1.BodyPosition.Position = arm1CF.Position

arm2CF = CFrame.new(body.CFrame * CFrame.new(-body.Size.X/2,0,-body.Size.Z/2).Position, mouse.Hit.Position) * CFrame.new(0,0,-arm1.Size.Z/2)
arm2.BodyGyro.CFrame = arm2CF
arm2.BodyPosition.Position = arm2CF.Position

seat.BodyPosition.Position = body.Position + Vector3.new(0,body.Size.Y/2+1,0)
seat.BodyGyro.CFrame = body.CFrame

if humanoid.Jump then
if not jumpDB then
jumpDB = true
body.Velocity = body.Velocity + Vector3.new(0,50,0)
repeat task.wait() until body.Velocity.Y <.1 and body.Velocity.Y > -.1
jumpDB = false
end
end

end)

]], value)