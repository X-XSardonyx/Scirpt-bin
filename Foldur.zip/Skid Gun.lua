local tool = Instance.new("Tool", owner.Backpack)
tool.Name  = 'kill dem skids'
tool.Grip = CFrame.Angles(0,math.rad(180),0)

local PARTS = {}

local handle = Instance.new("Part", tool)
handle.Size = Vector3.new(1,1,1)
handle.Name = 'Handle'
local mesh = Instance.new("SpecialMesh", handle)
mesh.MeshId = 'rbxassetid://7104899196'
mesh.MeshType = 'FileMesh'
mesh.Offset = Vector3.new(0,1,2)

local rem = Instance.new("RemoteEvent", tool)
rem.Name = 'SKID'

NLS("local rem = script.Parent.SKID local mouse = game:GetService'Players'.LocalPlayer:GetMouse() mouse.Button1Down:Connect(function() rem:FireServer(mouse.Hit.Position, mouse.Target) end)", tool)


rem.OnServerEvent:Connect(function(plr, pos, target)
if tool.Parent.ClassName ~= 'Backpack' then
local MAGNITUDE = (handle.CFrame * CFrame.new(0,1,7).Position - pos).Magnitude

if MAGNITUDE < 1000 then

local Shot = Instance.new("Part", script)
Shot.Anchored = true
Shot.BrickColor = BrickColor.new("Really red")
Shot.Material = 'Glass'
Shot.CFrame = CFrame.new(handle.CFrame * CFrame.new(0,1,7).Position, pos)
Shot.Position = Shot.Position:Lerp(pos, .5)
Shot.Name = 'SKIDSHOT'
Shot.CanCollide = false
Shot.Size = Vector3.new(.5,.5,MAGNITUDE)
game:GetService('Debris'):AddItem(Shot, 1)

game:GetService'RunService'.Heartbeat:Connect(function()
Shot.Size = Shot.Size + Vector3.new(.05,.05,0)
Shot.Transparency = Shot.Transparency + .05
end)

if target.Parent:FindFirstChildWhichIsA("Humanoid") ~= nil and target.Name ~= 'SKIDSHOT' then
for i,v in pairs(target.Parent:GetChildren()) do
if v.ClassName == 'Part' or v.ClassName == 'MeshPart' then
game:GetService'Debris':AddItem(v.Parent, 3)
v.Anchored = true
v.CanCollide = false
v.Parent = tool
table.insert(PARTS, v)
end
end
end
end
end
end)
db = 0
game:GetService'RunService'.Heartbeat:Connect(function()

for i,v in pairs(PARTS) do
v.Color = v.Color:Lerp(BrickColor.new("Really black").Color, .075)
v.Transparency = v.Transparency + .05
v.CFrame = CFrame.new(v.Position) * CFrame.new(0,.1,.1)
wait()
end
if db == 15 then
db = 0
else
db = db + .001
end
handle.Color = Color3.fromHSV(db,1,1)
end)
