local target = game.Players.X_XSardonyx
local idle = true

local attack1 = Instance.new("Tool", target.Backpack)
attack1.Name = 'Push'
attack1.RequiresHandle = false

local attack2 = Instance.new("Tool", target.Backpack)
attack2.Name = 'Fling'
attack2.RequiresHandle = false

local attack3 = Instance.new("Tool", target.Backpack)
attack3.Name = 'Crush'
attack3.RequiresHandle = false

local attack4 = Instance.new("Tool", target.Backpack)
attack4.Name = 'Wall'
attack4.RequiresHandle = false

local attack5 = Instance.new("Tool", target.Backpack)
attack5.Name = 'Ice'
attack5.RequiresHandle = false

local attack6 = Instance.new("Tool", target.Backpack)
attack6.Name = 'Beam'
attack6.RequiresHandle = false

local part1 = Instance.new("Part", workspace)
part1.Size = Vector3.new(2,2,1)
part1.Anchored = true
part1.CanCollide = false
part1.Material = 'SmoothPlastic'
part1.BrickColor = BrickColor.new("Institutional white")
part1.Anchored = true
part1.CFrame = target.Character.HumanoidRootPart.CFrame * CFrame.new(-4,2,0)

local part2 = Instance.new("Part", workspace)
part2.Size = target.Character.HumanoidRootPart.Size
part2.Anchored = true
part2.CanCollide = false
part2.Material = 'SmoothPlastic'
part2.BrickColor = BrickColor.new("Institutional white")
part2.Anchored = true
part2.CFrame = target.Character.HumanoidRootPart.CFrame * CFrame.new(4,2,0)

local part3 = Instance.new("Part", workspace)
part3.Size = target.Character.HumanoidRootPart.Size
part3.Anchored = true
part3.CanCollide = false
part3.Material = 'SmoothPlastic'
part3.BrickColor = BrickColor.new("Institutional white")
part3.Anchored = true
part3.CFrame = target.Character.HumanoidRootPart.CFrame * CFrame.new(0,6,0)

local att1 = Instance.new("Attachment", part1)
local att2 = Instance.new("Attachment", part2)
local att3 = Instance.new("Attachment", part3)

local Beam1 = Instance.new("Beam", part1)
local Beam2 = Instance.new("Beam", part2)
local Beam3 = Instance.new("Beam", part3)

Beam1.Attachment1 = att1
Beam1.Attachment0 = att2
Beam1.Enabled = false

Beam2.Attachment1 = att3
Beam2.Attachment0 = att2
Beam2.Enabled = false

Beam3.Attachment1 = att1
Beam3.Attachment0 = att3
Beam3.Enabled = false




attack1.Activated:Connect(function()
	idle = false
	part2.CanCollide = true
	part2.BrickColor = BrickColor.new("Lime green")
	for i = 1,4 do
		part2.CFrame = part2.CFrame:Lerp(target.Character.HumanoidRootPart.CFrame * CFrame.new(0,0,-2), .25)
		wait()
	end
	wait(.2)
	for i = 1,10 do
		part2.CFrame = part2.CFrame:Lerp(target.Character.HumanoidRootPart.CFrame * CFrame.new(0,0,-7), .1)
		wait()
	end
	wait()
	idle = true
	part2.CanCollide = false
	part2.BrickColor = BrickColor.new("Institutional white")
end)

attack2.Activated:Connect(function()
	part1.BrickColor = BrickColor.new("Really red")
	idle = false
	local flinging = true
	for i = 1,5 do
		part1.CFrame = part1.CFrame:Lerp(target.Character.HumanoidRootPart.CFrame * CFrame.new(0,0,-2), .25)
		wait()
	end
	wait(.2)
	part1.Touched:Connect(function(part)
		if flinging == true and part.Parent ~=  target.Character and part.Parent.ClassName == 'Model' then
			local force = Instance.new("BodyVelocity", part)
			force.Velocity = part1.CFrame.LookVector * 100
			wait(.15)
			force:Destroy()
		end
	end)
	for i = 1,10 do
		part1.CFrame = part1.CFrame:Lerp(target.Character.HumanoidRootPart.CFrame * CFrame.new(0,0,-7), .1)
		wait()
	end
	wait()
	idle = true
	flinging = false
	part1.BrickColor = BrickColor.new("Institutional white")
end)

attack3.Activated:Connect(function()
	idle = false
	part2.BrickColor = BrickColor.new("Really blue")
	part1.BrickColor = BrickColor.new("Really blue")
	for i = 1,4 do
		part2.CFrame = part2.CFrame:Lerp(target.Character.HumanoidRootPart.CFrame * CFrame.new(Vector3.new(-1,0,-2), Vector3.new(math.rad(0),math.rad(90),math.rad(0))), .25)
		part1.CFrame = part1.CFrame:Lerp(target.Character.HumanoidRootPart.CFrame * CFrame.new(Vector3.new(1,0,-2), Vector3.new(math.rad(0),math.rad(-90),math.rad(0))), .25)
		wait()
	end
	wait(1)

	local POS = target.Character.HumanoidRootPart.CFrame * CFrame.new(Vector3.new(0,0,-20))

	local model = Instance.new("Model", workspace)


	local box1 = Instance.new("Part", model)
	box1.Material = 'ForceField'
	box1.Size = Vector3.new(10,2,10)
	box1.CFrame = target.Character.HumanoidRootPart.CFrame * CFrame.new(0,5,-20)
	box1.Anchored = true
	box1.BrickColor = BrickColor.new("Really blue")

	local box2 = Instance.new("Part", model)
	box2.Material = 'ForceField'
	box2.Size = Vector3.new(10,2,10)
	box2.CFrame = target.Character.HumanoidRootPart.CFrame * CFrame.new(0,-5,-20)
	box2.Anchored = true
	box2.BrickColor = BrickColor.new("Really blue")

	local box3 = Instance.new("Part", model)
	box3.Material = 'ForceField'
	box3.Size = Vector3.new(10,10,2)
	box3.CFrame = target.Character.HumanoidRootPart.CFrame * CFrame.new(0,0,-25)
	box3.Anchored = true
	box3.BrickColor = BrickColor.new("Really blue")

	local box4 = Instance.new("Part", model)
	box4.Material = 'ForceField'
	box4.Size = Vector3.new(10,10,2)
	box4.CFrame = target.Character.HumanoidRootPart.CFrame * CFrame.new(0,0,-15)
	box4.Anchored = true
	box4.BrickColor = BrickColor.new("Really blue")

	local box5 = Instance.new("Part", model)
	box5.Material = 'ForceField'
	box5.Size = Vector3.new(2,10,10)
	box5.CFrame = target.Character.HumanoidRootPart.CFrame * CFrame.new(5,0,-20)
	box5.Anchored = true
	box5.BrickColor = BrickColor.new("Really blue")


	local box6 = Instance.new("Part", model)
	box6.Material = 'ForceField'
	box6.Size = Vector3.new(2,10,10)
	box6.CFrame = target.Character.HumanoidRootPart.CFrame * CFrame.new(-5,0,-20)
	box6.Anchored = true
	box6.BrickColor = BrickColor.new("Really blue")


	for i,v in pairs(model:GetChildren()) do 
		for i = 1,10 do 
			v.CFrame = v.CFrame:Lerp(POS, .1)
			wait()
		end
	end

	wait(.5)
	model:Destroy()
	wait(.5)
	idle = true
	part2.BrickColor = BrickColor.new("Institutional white")
	part1.BrickColor = BrickColor.new("Institutional white")
end)

attack4.Activated:Connect(function()
	part1.BrickColor = BrickColor.new("New Yeller")
	idle = false
	for i = 1,5 do
		part1.CFrame = part1.CFrame:Lerp(target.Character.HumanoidRootPart.CFrame * CFrame.new(0,-2,-2), .25)
		wait()
	end
	wait(.2)
	local wall = Instance.new("Part", workspace)
	wall.Name = 'WALL'
	wall.Size = Vector3.new(10,9,2)
	wall.Material = 'Slate'
	wall.BrickColor = BrickColor.new("CGA brown")
	wall.Anchored = true
	wall.CFrame = target.Character.HumanoidRootPart.CFrame * CFrame.new(0,0-5,-5)
	game:GetService("Debris"):AddItem(wall, 11)
	for i = 1,5 do
		part1.CFrame = part1.CFrame:Lerp(target.Character.HumanoidRootPart.CFrame * CFrame.new(0,4,-2), .25)
		wall.CFrame = wall.CFrame:Lerp(wall.CFrame * CFrame.new(0,4.5,0), .25)
		wait()
	end

	wait()
	idle = true
	part1.BrickColor = BrickColor.new("Institutional white")
		wait(9)
		for i = 1,5 do
		wall.CFrame = wall.CFrame:Lerp(wall.CFrame * CFrame.new(0,-8,0), .25)
		wait()
	end
end)

attack5.Activated:Connect(function()
	local POS = target.Character.HumanoidRootPart.CFrame * CFrame.new(0,0,-5)
	part1.BrickColor = BrickColor.new("Magenta")
	idle = false
	for i = 1,5 do
		part1.CFrame = part1.CFrame:Lerp(target.Character.HumanoidRootPart.CFrame * CFrame.new(0,-2,-2), .25)
		wait()
	end
	
	
	for i = 1,10 do
		local ice = Instance.new("Part", workspace)
		ice.Size = Vector3.new(5,10,3.2)
		ice.CFrame = POS * CFrame.new(0,-10,i)
		ice.Material = Enum.Material.Glass
		ice.BrickColor = BrickColor.new("Pastel blue-green")
		ice.Transparency = .5
		ice.Anchored = true
			game:GetService("Debris"):AddItem(ice, 5)
		for J = 1,3 do
			ice.CFrame = ice.CFrame:Lerp(POS * CFrame.new(0, i /2,i * -5), .33)
			wait()
		end
	end
	
	wait(.2)
	for i = 1,5 do
		part1.CFrame = part1.CFrame:Lerp(target.Character.HumanoidRootPart.CFrame * CFrame.new(0,4,-2), .25)
		wait()
	end
	

	wait()
	idle = true
	part1.BrickColor = BrickColor.new("Institutional white")
end)

attack6.Activated:Connect(function()
	part1.BrickColor = BrickColor.new("Deep orange")
		part2.BrickColor = BrickColor.new("Deep orange")
			part3.BrickColor = BrickColor.new("Deep orange")

	wait(.2)
	
	Beam1.Enabled = true
	Beam2.Enabled = true
	Beam3.Enabled = true
	
	wait(.5)
	
	local Bullet = Instance.new("Part", Workspace)
	Bullet.CanCollide = false
	Bullet.Size = Vector3.new(3,3,3)
	Bullet.CFrame = part3.CFrame * CFrame.new(0,-2.5,-3)
	Bullet.BrickColor = BrickColor.new("Black")
	Bullet.Shape = 'Ball'
	Bullet.Material = 'Neon'
	game:GetService("Debris"):AddItem(Bullet, 10)
			local force = Instance.new("BodyVelocity", Bullet)	
			force.Velocity = part3.CFrame.LookVector * 100
			
	Bullet.Touched:Connect(function(part)
	Bullet:Destroy()
	part.Parent:FindFirstChild("Humanoid").Health = part.Parent:FindFirstChild("Humanoid").Health - 10
	end)
	wait(1)
	Beam1.Enabled = false
	Beam2.Enabled = false
	Beam3.Enabled = false

	
	
	part1.BrickColor = BrickColor.new("Institutional white")
		part2.BrickColor = BrickColor.new("Institutional white")
			part3.BrickColor = BrickColor.new("Institutional white")
end)

while wait() do
	if idle == true then
		part1.CFrame = part1.CFrame:Lerp(target.Character.HumanoidRootPart.CFrame * CFrame.new(Vector3.new(-4,2,0)), .25)
		part2.CFrame = part2.CFrame:Lerp(target.Character.HumanoidRootPart.CFrame * CFrame.new(Vector3.new(4,2,0)), .25)
		part3.CFrame = part3.CFrame:Lerp(target.Character.HumanoidRootPart.CFrame * CFrame.new(Vector3.new(0,6,0)), .25)
	end
end

