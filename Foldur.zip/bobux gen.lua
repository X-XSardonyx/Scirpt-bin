local HRP = owner.Character.HumanoidRootPart.CFrame
script.Parent = workspace
local main = Instance.new("Part", script)
main.Anchored = true
main.CanCollide = false
main.Locked = true
main.Size = Vector3.new(16,6,4)
main.CFrame = HRP * CFrame.new(math.random(-10,10),math.random(-10,10),math.random(-10,10)) * CFrame.Angles(math.random(-100,100),math.random(-100,100),math.random(-100,100))
main.BrickColor = BrickColor.new("Br. yellowish orange")
main.Material = 'Wood'
main.Transparency = 1
game:GetService("TweenService"):Create(main, TweenInfo.new(math.random(1,5)), {Transparency = 0, CFrame = HRP * CFrame.new(6,0,-8)}):Play()

local roof = Instance.new("WedgePart", script)
roof.Anchored = true
roof.CanCollide = false
roof.Locked = true
roof.Size = Vector3.new(4,2,16)
roof.CFrame = HRP * CFrame.new(math.random(-10,10),math.random(-10,10),math.random(-10,10)) * CFrame.Angles(math.random(-100,100),math.random(-100,100),math.random(-100,100))
roof.BrickColor = BrickColor.new("Dark stone grey")
roof.Material = 'Brick'
roof.Transparency = 1
game:GetService("TweenService"):Create(roof, TweenInfo.new(math.random(1,5)), {Transparency = 0, CFrame = HRP * CFrame.new(6,4,-8) * CFrame.Angles(0,math.rad(-90),0)}):Play()

local button = Instance.new("Part", script)
button.Anchored = true
button.CanCollide = false
button.Locked = true
button.Size = Vector3.new(.1,2,2)
button.Shape = 'Cylinder'
button.CFrame = HRP * CFrame.new(math.random(-10,10),math.random(-10,10),math.random(-10,10)) * CFrame.Angles(math.random(-100,100),math.random(-100,100),math.random(-100,100))
button.BrickColor = BrickColor.new("Lime green")
button.Material = 'SmoothPlastic'
button.Transparency = 1
game:GetService("TweenService"):Create(button, TweenInfo.new(math.random(1,5)), {Transparency = 0, CFrame = HRP * CFrame.new(0,0,-6) * CFrame.Angles(0,math.rad(-90),0)}):Play()

local bholder = Instance.new("Part", script)
bholder.Anchored = true
bholder.CanCollide = false
bholder.Locked = true
bholder.Size = Vector3.new(.1,2.2,2.2)
bholder.Shape = 'Cylinder'
bholder.CFrame = HRP * CFrame.new(math.random(-10,10),math.random(-10,10),math.random(-10,10)) * CFrame.Angles(math.random(-100,100),math.random(-100,100),math.random(-100,100))
bholder.BrickColor = BrickColor.new("Pearl")
bholder.Material = 'DiamondPlate'
bholder.Transparency = 1
game:GetService("TweenService"):Create(bholder, TweenInfo.new(math.random(1,5)), {Transparency = 0, CFrame = HRP * CFrame.new(0,0,-6.01) * CFrame.Angles(0,math.rad(-90),0)}):Play()

local wire = Instance.new("Part", script)
wire.Anchored = true
wire.CanCollide = false
wire.Locked = true
wire.Size = Vector3.new(.1,2,.1)
wire.CFrame = HRP * CFrame.new(math.random(-10,10),math.random(-10,10),math.random(-10,10)) * CFrame.Angles(math.random(-100,100),math.random(-100,100),math.random(-100,100))
wire.BrickColor = BrickColor.new("Pearl")
wire.Material = 'DiamondPlate'
wire.Transparency = 1
game:GetService("TweenService"):Create(wire, TweenInfo.new(math.random(1,5)), {Transparency = 0, CFrame = HRP * CFrame.new(0,-2,-6.01)}):Play()

local Board = Instance.new("Part", script)
Board.Anchored = true
Board.CanCollide = false
Board.Locked = true
Board.Size = Vector3.new(6,3,.1)
Board.CFrame = HRP * CFrame.new(math.random(-10,10),math.random(-10,10),math.random(-10,10)) * CFrame.Angles(math.random(-100,100),math.random(-100,100),math.random(-100,100))
Board.BrickColor = BrickColor.new("Institutional white")
Board.Material = 'SmoothPlastic'
Board.Transparency = 1
game:GetService("TweenService"):Create(Board, TweenInfo.new(math.random(1,5)), {Transparency = 0, CFrame = HRP * CFrame.new(6,0,-6.01)}):Play()

local screen = Instance.new("SurfaceGui", Board)
screen.Face = 'Back'
local TB = Instance.new("TextBox", screen)
TB.Size = UDim2.new(1,0,1,0)
TB.BackgroundTransparency = 1
TB.TextSize = 100
TB.TextColor = BrickColor.new("Really black")
TB.Font = 'Code'
TB.Text = 'Bobux Generator'
TB.TextWrapped = true

wait(5)

main.CanCollide = true
roof.CanCollide = true
button.CanCollide = true
bholder.CanCollide = true
wire.CanCollide = true
Board.CanCollide = true

local click = Instance.new("ClickDetector", button)

local texts = {"Generating Bobux", "Haxing Bobux Into Account", "Inserting Bobux", "Done :D. Enjoy The Bobux B)"}

click.MouseClick:Connect(function(plr)
click.Parent = nil
for i,v in pairs(texts) do
wait(math.random(2,5))
TB.Text = v
end

local bux = Instance.new("Tool", plr.Backpack)
bux.Name = 'Bobux'

local handle = Instance.new("Part", bux)
handle.Name = 'Handle'
handle.Size = Vector3.new(1.5,1,0)
handle.BrickColor = BrickColor.new("Lime green")
handle.Material = 'SmoothPlastic'

local chance = math.random(1,5)

if chance == 1 then
TB.Text = 'Oh noes! The bux got deleted by moderater of roblox and now i scared B('
wait(3)
TB.Text = 'Deleting bux B('
wait(1)
bux:Destroy()

elseif chance == 5 then
TB.Text = 'you just unlocked the legendary bobux! you get 1000 bobux :D'
bux.Name = '1000 Bobux'
handle.BrickColor = BrickColor.new("Camo")
elseif chance == 4 then
TB.Text = 'wait... YOU JUST UNLOCKED PHAT BOBUX... BUX UPGRADE TIME'
game:GetService("TweenService"):Create(handle, TweenInfo.new(math.random(1)), {Size = Vector3.new(3,2,0)}):Play()
bux.Name = 'Mega Bobux'
elseif chance == 2 then
TB.Text = 'MMMMMMMM seems the machine realises you forgot to hydrate. have a blue water bobux to hydrate.'
bux.Name = 'moisture'
handle.BrickColor = BrickColor.new("Cyan")
handle.Transparency = .5
end

wait(4)
TB.Text = 'Bobux Generator'
click.Parent = button
end)