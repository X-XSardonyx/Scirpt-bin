local screen = Instance.new("Part", script)
local sg = Instance.new("SurfaceGui", screen)
local scroll = Instance.new("ScrollingFrame", sg)
local tb = Instance.new("TextBox", scroll)

screen.Size = Vector3.new(10,7.5,0)
screen.BrickColor = BrickColor.new("Institutional white")
screen.CanCollide = false
screen.Massless = true

local weld = Instance.new("Weld", screen)
weld.Part1 = screen
weld.Part0 = owner.Character.HumanoidRootPart
weld.C0 = CFrame.new(0,2,-5) * CFrame.Angles(0,math.rad(180),0)

scroll.Size = UDim2.new(.75,0,.85,0)
scroll.Position = UDim2.new(0,0,.1,0)
scroll.ScrollingDirection = Enum.ScrollingDirection.Y
scroll.CanvasSize = UDim2.new(0,0,100,0)
scroll.BackgroundTransparency = 1

tb.Size = UDim2.new(1,0,1,0)
tb.Position = UDim2.new(0,0,0,0)
tb.BackgroundColor3 = BrickColor.new("Really black").Color
tb.TextColor = BrickColor.new("Institutional white")
tb.Font = 'Code'
tb.TextSize = 50
tb.RichText = true
tb.TextXAlignment = 'Left'
tb.TextWrapped = true
tb.TextYAlignment = 'Top'
tb.Name = 'Box'
tb.BackgroundTransparency = 1
tb.ClearTextOnFocus = false
tb.TextTransparency = 1

local Credit = Instance.new("TextBox", sg)
Credit.Size = UDim2.new(.5,0,.09,0)
Credit.BackgroundTransparency = 1
Credit.RichText = true
Credit.Text = 'Syntaxed Executor by <font color = "rgb(0,0,0)">X_XSardonxy</font>'
Credit.TextScaled = true
Credit.TextXAlignment = 'Left'
Credit.TextColor = BrickColor.new("Really black")

local TB = tb:Clone()
TB.Parent = tb
TB.TextEditable = false
TB.BackgroundTransparency = 0
TB.TextTransparency = 0
TB.ZIndex = -2
TB.Size = UDim2.new(1,0,1,0)

local execute = Instance.new("TextButton", sg)
execute.Size = UDim2.new(.225,0,.15,0)
execute.Position = UDim2.new(.765,0,.1,0)
execute.TextScaled = true
execute.Name = 'Execute'
execute.Font = 'Code'
execute.BackgroundColor3 = BrickColor.new("Really black").Color
execute.TextColor = BrickColor.new("Institutional white")
execute.Text = 'ExecuteServer'

local client = Instance.new("TextButton", sg)
client.Size = UDim2.new(.225,0,.15,0)
client.Position = UDim2.new(.765,0,.3,0)
client.TextScaled = true
client.Name = 'ExecuteClient'
client.Font = 'Code'
client.BackgroundColor3 = BrickColor.new("Really black").Color
client.TextColor = BrickColor.new("Institutional white")
client.Text = 'ExecuteClient'

local rem = Instance.new("RemoteEvent", owner.Character)
rem.Name = 'TB'
Instance.new("ObjectValue", rem).Value = sg

rem.OnServerEvent:Connect(function(plr, String, button)
tb.Text = String
if button == 'ExecuteServer' then
NS(String, workspace)
elseif button == 'ExecuteClient' then
NLS(String, owner.Character)
end
end)

NLS([[local rem = owner.Character.TB
local sg = rem.Value.Value
sg = sg:Clone()
sg.Parent = rem.Value.Value.Parent
sg.Adornee = sg.Parent
sg.Parent = owner.PlayerGui
rem.Value.Value:Destroy()

sg.ScrollingFrame.Box.Changed:Connect(function()
rem:FireServer(sg.ScrollingFrame.Box.Text)
end)

sg.Execute.MouseButton1Click:Connect(function()
rem:FireServer(sg.ScrollingFrame.Box.Text, "ExecuteServer")
end)

sg.ExecuteClient.MouseButton1Click:Connect(function()
rem:FireServer(sg.ScrollingFrame.Box.Text, "ExecuteClient")
end)
local syntax = {
{'local', "<font color = 'rgb(255,0,0)'>local</font>"},
{'Instance', "<font color = 'rgb(0,0,255)'>Instance</font>"},
{'new', "<font color = 'rgb(0,0,150)'>new</font>"},
{'function', "<font color = 'rgb(255,0,0)'>function</font>"},
{'Destroy', "<font color = 'rgb(255,0,0)'>Destroy</font>"},
{'Remove', "<font color = 'rgb(255,0,0)'>Remove</font>"},
{'destroy', "<font color = 'rgb(255,0,0)'>destroy</font>"},
{'remove', "<font color = 'rgb(255,0,0)'>remove</font>"},
{'workspace', "<font color = 'rgb(0,100,0)'>workspace</font>"},
{'Workspace', "<font color = 'rgb(0,100,0)'>Workspace</font>"},
{'game', "<font color = 'rgb(0,255,0)'>game</font>"},
{'GetService', "<font color = 'rgb(0,0,100)'>GetService</font>"},
{'print', "<font color = 'rgb(122,180,180)'>print</font>"},
{'end', "<font color = 'rgb(255,100,100)'>end</font>"},
{'Vector3', "<font color = 'rgb(100,100,255)'>Vector3</font>"},
{'Vector2', "<font color = 'rgb(100,100,255)'>Vector2</font>"},
{'UDim', "<font color = 'rgb(100,100,255)'>UDim</font>"},
{'Position', "<font color = 'rgb(100,100,255)'>Position</font>"},
{'Size', "<font color = 'rgb(100,100,255)'>Size</font>"},
{'CFrame', "<font color = 'rgb(100,100,255)'>CFrame</font>"},
{'Orientation', "<font color = 'rgb(100,100,255)'>Orientation</font>"},
{'owner', "<font color = 'rgb(255,255,255)'>owner</font>"},
{'Players', "<font color = 'rgb(0,0,255)'>Players</font>"}
}
function SYNTAXHL(msg)
for i,v in pairs(syntax) do
msg = string.gsub(msg,v[1], v[2])
end
return msg
end

sg.ScrollingFrame.Box.Changed:Connect(function()

sg.ScrollingFrame.Box.Box.Text = SYNTAXHL(sg.ScrollingFrame.Box.Text)

end)

]], owner.Character)
tb.Text = 'NIL'
local syntax = {
{'local', "<font color = 'rgb(255,0,0)'>local</font>"},
{'Instance', "<font color = 'rgb(0,0,255)'>Instance</font>"},
{'new', "<font color = 'rgb(0,0,150)'>new</font>"},
{'function', "<font color = 'rgb(255,0,0)'>function</font>"},
{'Destroy', "<font color = 'rgb(255,0,0)'>Destroy</font>"},
{'Remove', "<font color = 'rgb(255,0,0)'>Remove</font>"},
{'destroy', "<font color = 'rgb(255,0,0)'>destroy</font>"},
{'remove', "<font color = 'rgb(255,0,0)'>remove</font>"},
{'workspace', "<font color = 'rgb(0,100,0)'>workspace</font>"},
{'Workspace', "<font color = 'rgb(0,100,0)'>Workspace</font>"},
{'game', "<font color = 'rgb(0,255,0)'>game</font>"},
{'GetService', "<font color = 'rgb(0,0,100)'>GetService</font>"},
{'print', "<font color = 'rgb(122,180,180)'>print</font>"},
{'end', "<font color = 'rgb(255,100,100)'>end</font>"},
{'Vector3', "<font color = 'rgb(100,100,255)'>Vector3</font>"},
{'Vector2', "<font color = 'rgb(100,100,255)'>Vector2</font>"},
{'UDim', "<font color = 'rgb(100,100,255)'>UDim</font>"},
{'Position', "<font color = 'rgb(100,100,255)'>Position</font>"},
{'Size', "<font color = 'rgb(100,100,255)'>Size</font>"},
{'CFrame', "<font color = 'rgb(100,100,255)'>CFrame</font>"},
{'Orientation', "<font color = 'rgb(100,100,255)'>Orientation</font>"},
{'owner', "<font color = 'rgb(255,255,255)'>owner</font>"},
{'Players', "<font color = 'rgb(0,0,255)'>Players</font>"}
}
function SYNTAXHL(msg)
for i,v in pairs(syntax) do
msg = string.gsub(msg,v[1], v[2])
end
return msg
end

tb.Changed:Connect(function()

TB.Text = SYNTAXHL(tb.Text)

end)

game:GetService("RunService").Heartbeat:Connect(function()
Credit.TextColor3 = Color3.fromHSV(tick() / 5 % 1 / 1,1,1)
end)