local newhumanoid = Instance.new("Part", Instance.new("Model", script))
newhumanoid.Size = Vector3.new(3,5,1.5)
newhumanoid.Transparency = 1
newhumanoid.Name = 'HumanoidRootPart'
newhumanoid.CFrame = owner.Character.HumanoidRootPart.CFrame
newhumanoid.Parent.PrimaryPart = newhumanoid

owner.Character = newhumanoid.Parent

Instance.new("Humanoid", newhumanoid.Parent)

local T = Instance.new("Part", script)
T.Size = Vector3.new(2,3,1)
T:SetNetworkOwner(owner)
T.Name = 'torso'
value = Instance.new("ObjectValue", newhumanoid.Parent)
value.Name = 'torso'
value.Value = T

local H = Instance.new("Part", script)
H.Size = Vector3.new(1.5,1.5,1.5)
H:SetNetworkOwner(owner)
H.Name = 'Head'
value = Instance.new("ObjectValue", newhumanoid.Parent)
value.Name = 'Head'
value.Value = H

Instance.new("Decal", H).Texture = 'rbxassetid://1676553712'

local LL = Instance.new("Part", script)
LL.Size = Vector3.new(1,3,1)
LL:SetNetworkOwner(owner)
LL.Name = 'LeftLeg'
value = Instance.new("ObjectValue", newhumanoid.Parent)
value.Name = 'LeftLeg'
value.Value = LL

local RL = Instance.new("Part", script)
RL.Size = Vector3.new(1,3,1)
RL:SetNetworkOwner(owner)
RL.Name = 'RightLeg'
value = Instance.new("ObjectValue", newhumanoid.Parent)
value.Name = 'RightLeg'
value.Value = RL

local LA = Instance.new("Part", script)
LA.Size = Vector3.new(1,3,1)
LA:SetNetworkOwner(owner)
LA.Name = 'LeftArm'
value = Instance.new("ObjectValue", newhumanoid.Parent)
value.Name = 'LeftArm'
value.Value = LA

local RA = Instance.new("Part", script)
RA.Size = Vector3.new(1,3,1)
RA:SetNetworkOwner(owner)
RA.Name = 'RightArm'
value = Instance.new("ObjectValue", newhumanoid.Parent)
value.Name = 'RightArm'
value.Value = RA

for i,v in pairs({T,H,LL,RL,LA,RA}) do
v.Material = 'SmoothPlastic'
v.Locked = true
game:GetService("RunService").Heartbeat:Connect(function()
v:SetNetworkOwner(owner)
end)
end

T.Material = 'DiamondPlate'
LL.Material = 'DiamondPlate'
RL.Material = 'DiamondPlate'

T.BrickColor = BrickColor.new("Really red")
LL.BrickColor = BrickColor.new("Really red")
RL.BrickColor = BrickColor.new("Really red")

NLS([[
local hrp = owner.Character.HumanoidRootPart
local Torso = owner.Character.torso.Value
local Head = owner.Character.Head.Value
local LL = owner.Character.LeftLeg.Value
local RL = owner.Character.RightLeg.Value
local LA = owner.Character.LeftArm.Value
local RA = owner.Character.RightArm.Value

Torso.CanCollide = false
Head.CanCollide = false
LL.CanCollide = false
RL.CanCollide = false
LA.CanCollide = false
RA.CanCollide = false

torsomove1 = Instance.new("BodyPosition", Torso)
torsomove2 = Instance.new("BodyGyro", Torso)

torsomove1.MaxForce = Vector3.new(math.huge,math.huge,math.huge)
torsomove1.P = 150000
torsomove1.D = 1000

torsomove2.MaxTorque = Vector3.new(math.huge,math.huge,math.huge)
torsomove2.P = 150000
torsomove2.D = 1000

--Head
headmove1 = Instance.new("BodyPosition", Head)
headmove2 = Instance.new("BodyGyro", Head)

headmove1.MaxForce = Vector3.new(math.huge,math.huge,math.huge)
headmove1.P = 150000
headmove1.D = 1000

headmove2.MaxTorque = Vector3.new(math.huge,math.huge,math.huge)
headmove2.P = 150000
headmove2.D = 1000

--LL
llmove1 = Instance.new("BodyPosition", LL)
llmove2 = Instance.new("BodyGyro", LL)

llmove1.MaxForce = Vector3.new(math.huge,math.huge,math.huge)
llmove1.P = 150000
llmove1.D = 1000

llmove2.MaxTorque = Vector3.new(math.huge,math.huge,math.huge)
llmove2.P = 150000
llmove2.D = 1000
--RL

rlmove1 = Instance.new("BodyPosition", RL)
rlmove2 = Instance.new("BodyGyro", RL)

rlmove1.MaxForce = Vector3.new(math.huge,math.huge,math.huge)
rlmove1.P = 150000
rlmove1.D = 1000

rlmove2.MaxTorque = Vector3.new(math.huge,math.huge,math.huge)
rlmove2.P = 150000
rlmove2.D = 1000

--LA

ramove1 = Instance.new("BodyPosition", RA)
ramove2 = Instance.new("BodyGyro", RA)

ramove1.MaxForce = Vector3.new(math.huge,math.huge,math.huge)
ramove1.P = 150000
ramove1.D = 1000

ramove2.MaxTorque = Vector3.new(math.huge,math.huge,math.huge)
ramove2.P = 150000
ramove2.D = 1000

--RA

lamove1 = Instance.new("BodyPosition", LA)
lamove2 = Instance.new("BodyGyro", LA)

lamove1.MaxForce = Vector3.new(math.huge,math.huge,math.huge)
lamove1.P = 150000
lamove1.D = 1000

lamove2.MaxTorque = Vector3.new(math.huge,math.huge,math.huge)
lamove2.P = 150000
lamove2.D = 1000

--
local Cam = workspace.CurrentCamera
local CamBlock = Instance.new("Part", script)
CamBlock.CanCollide = false
CamBlock.Transparency = 1

sine = 1

game:GetService("RunService").RenderStepped:Connect(function()
sine = sine + .1
CamBlock.CFrame = Cam.CFrame

torsomove1.Position = hrp.CFrame * CFrame.new(0,2,0).Position
torsomove2.CFrame = hrp.CFrame

headmove1.Position = hrp.CFrame * CFrame.new(0,4.25,0).Position
headmove2.CFrame = CamBlock.CFrame

if hrp.Velocity.Magnitude > 1 then
llmove1.Position = hrp.CFrame * CFrame.new(-.5,-1,math.sin(sine)/2*1.5).Position
llmove2.CFrame = hrp.CFrame * CFrame.new(-.5,-1,math.sin(sine)) * CFrame.Angles(math.rad(math.sin(-sine)*45),0,0)

rlmove1.Position = hrp.CFrame * CFrame.new(.5,-1,-math.sin(sine)/2*1.5).Position
rlmove2.CFrame = hrp.CFrame * CFrame.new(.5,-1,-math.sin(sine)) * CFrame.Angles(math.rad(math.sin(sine)*45),0,0)

lamove1.Position = hrp.CFrame * CFrame.new(1.5,2,-math.sin(sine)/2*1.5).Position
lamove2.CFrame = hrp.CFrame * CFrame.new(-.5,1,0) * CFrame.Angles(math.rad(math.sin(sine)*45),0,0)

ramove1.Position = hrp.CFrame * CFrame.new(-1.5,2,math.sin(sine)/2*1.5).Position
ramove2.CFrame = hrp.CFrame * CFrame.new(.5,2,0) * CFrame.Angles(-math.rad(math.sin(sine)*45),0,0)

else
llmove1.Position = hrp.CFrame * CFrame.new(-.5,-1,0).Position
llmove2.CFrame = hrp.CFrame * CFrame.new(-.5,-1,0)

rlmove1.Position = hrp.CFrame * CFrame.new(.5,-1,0).Position
rlmove2.CFrame = hrp.CFrame * CFrame.new(.5,-1,0)

lamove1.Position = hrp.CFrame * CFrame.new(1.5,2,0).Position
lamove2.CFrame = hrp.CFrame * CFrame.new(-.5,1,0)

ramove1.Position = hrp.CFrame * CFrame.new(-1.5,2,0).Position
ramove2.CFrame = hrp.CFrame * CFrame.new(.5,2,0)
end
end)

]], newhumanoid.Parent)