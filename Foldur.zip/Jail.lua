model = Instance.new("Model", script)


function part(shape,anchored, transparency, size, cframe, color, locked, cancollide,material)

local prt = Instance.new("Part", model)
prt.Size = size
prt.Anchored = anchored
prt.CanCollide = cancollide
prt.Locked = locked
prt.Shape = shape
prt.Transparency = transparency
prt.Size = size
prt.Color = color
prt.CFrame = cframe
prt.Material = material

end

function wedge(shape,anchored, transparency, size, cframe, color, locked, cancollide, material)

local prt = Instance.new("WedgePart", model)
prt.Size = size
prt.Anchored = anchored
prt.Shape = shape
prt.CanCollide = cancollide
prt.Locked = locked
prt.Transparency = transparency
prt.Size = size
prt.Color = color
prt.CFrame = cframe
prt.Material = material

end

function seat(shape,anchored, transparency, size, cframe, color, locked, cancollide, material)

local prt = Instance.new("Seat", model)
prt.Size = size
prt.Anchored = anchored
prt.Shape = shape
prt.CanCollide = cancollide
prt.Locked = locked
prt.Transparency = transparency
prt.Size = size
prt.Color = color
prt.CFrame = cframe
prt.Material = material

end

 
part("Block",true,0,Vector3.new(30,1,30),CFrame.new(56.472473144531,16.5,-51.488647460938) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.97254902124405,0.97254902124405,0.97254902124405),false,true,"Slate")
part("Block",true,0,Vector3.new(30,16,1),CFrame.new(56.472473144531,8,-65.988647460938) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.97254902124405,0.97254902124405,0.97254902124405),false,true,"Slate")
part("Block",true,0,Vector3.new(40,1,40),CFrame.new(56.472473144531,0.5,-51.488647460938) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.38823530077934,0.37254902720451,0.38431373238564),false,true,"Concrete")
part("Block",true,0,Vector3.new(5,0.19999980926514,1.3999999761581),CFrame.new(66.972473144531,10.10000038147,-36.988647460938) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.38823530077934,0.37254902720451,0.38431373238564),false,true,"SmoothPlastic")
part("Block",true,0,Vector3.new(1,15,1),CFrame.new(47.972473144531,8.5,-36.988647460938) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"DiamondPlate")
part("Block",true,0,Vector3.new(1,15,1),CFrame.new(69.972473144531,8.5,-36.988647460938) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"Plastic")
part("Block",true,0,Vector3.new(0.19999980926514,9.1999998092651,1.3999999761581),CFrame.new(64.572471618652,5.6000003814697,-36.988647460938) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.38823530077934,0.37254902720451,0.38431373238564),false,true,"SmoothPlastic")
part("Block",true,0,Vector3.new(1,6,1),CFrame.new(67.972473144531,13,-36.988647460938) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"DiamondPlate")
part("Block",true,0,Vector3.new(1,15,1),CFrame.new(63.972473144531,8.5,-36.988647460938) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"DiamondPlate")
part("Block",true,0,Vector3.new(1,15,1),CFrame.new(53.972473144531,8.5,-36.988647460938) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"DiamondPlate")
part("Block",true,0,Vector3.new(1,15,1),CFrame.new(59.972473144531,8.5,-36.988647460938) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"DiamondPlate")
part("Block",true,0,Vector3.new(1,6,1),CFrame.new(65.972473144531,13,-36.988647460938) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"DiamondPlate")
part("Block",true,0,Vector3.new(5,9.1999998092651,0.0010000000474975),CFrame.new(66.972473144531,5.6000003814697,-36.988647460938) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.38823530077934,0.37254902720451,0.38431373238564),false,false,"SmoothPlastic")
part("Block",true,0,Vector3.new(1,15,1),CFrame.new(55.972473144531,8.5,-36.988647460938) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"DiamondPlate")
part("Block",true,0,Vector3.new(1,15,1),CFrame.new(57.972473144531,8.5,-36.988647460938) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"DiamondPlate")
part("Block",true,0,Vector3.new(1,15,1),CFrame.new(43.972473144531,8.5,-36.988647460938) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"DiamondPlate")
part("Block",true,0,Vector3.new(1,15,1),CFrame.new(49.972473144531,8.5,-36.988647460938) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"DiamondPlate")
part("Block",true,0,Vector3.new(1,15,1),CFrame.new(51.972473144531,8.5,-36.988647460938) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"DiamondPlate")
part("Block",true,0,Vector3.new(1,16,30),CFrame.new(70.972473144531,8,-51.488647460938) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.97254902124405,0.97254902124405,0.97254902124405),false,true,"Slate")
part("Block",true,0,Vector3.new(1,15,1),CFrame.new(45.972473144531,8.5,-36.988647460938) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"DiamondPlate")
part("Block",true,0,Vector3.new(1,15,1),CFrame.new(61.972473144531,8.5,-36.988647460938) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"DiamondPlate")
part("Block",true,0,Vector3.new(1,16,30),CFrame.new(41.972473144531,8,-51.488647460938) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.97254902124405,0.97254902124405,0.97254902124405),false,true,"Slate")
part("Block",true,1,Vector3.new(22,15,1),CFrame.new(53.472473144531,8.5,-36.988647460938) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.63921570777893,0.63529413938522,0.64705884456635),false,true,"DiamondPlate")
for i,v in pairs(model:GetDescendants()) do
if v:IsA("BasePart") then
v.CastShadow = false
v.Locked = true
local cf = v.CFrame
local tp = v.Transparency
local cc = v.CanCollide
local anch = v.Anchored

v.Anchored = true
v.CFrame = CFrame.new(v.Position + Vector3.new(0,50,0))
v.Transparency = 1
v.CanCollide = false
coroutine.resume(coroutine.create(function()
wait(i/#model:GetDescendants())

game:GetService("TweenService"):Create(v, TweenInfo.new(1), {CFrame = cf, Transparency = tp}):Play()
wait(1)
v.CanCollide = cc
v.Anchored = anch
end))

end
end  