--16646125  16432575

desc = owner.Character.Humanoid:GetAppliedDescription()

handle = Instance.new("Part", script)
handle.Size = Vector3.new(1,1,1)
handle.CanCollide = false
handle.CFrame = owner.Character.HumanoidRootPart.CFrame
handle.Name = 'Handle'
handle.Anchored = true
owner.Character.HumanoidRootPart.Anchored = true

local mesh = Instance.new("SpecialMesh", handle)
mesh.MeshId = 'rbxassetid://'..16646125
mesh.TextureId = 'rbxassetid://'..16432575

game:GetService("TweenService"):Create(mesh, TweenInfo.new(2), {Scale = Vector3.new(10,10,10)}):Play()
wait(2)

tool = Instance.new("Tool", script)

handle.Parent = tool

owner.Character:BreakJoints()

handle.Anchored = false
handle.CanCollide = true

tool.Name = 'Burger'

game:GetService("TweenService"):Create(mesh, TweenInfo.new(2), {Scale = Vector3.new(1,1,1)}):Play()

wait(.25)

owner.Character.Parent = owner

tool.Activated:Connect(function()
parent = tool.Parent

tool.Grip = CFrame.new(1.5,-1,-1)
wait(1)
tool.Grip = CFrame.new(0,0,0)

wait(.5)

parent.Humanoid:ApplyDescription(desc)
tool:Destroy()
end)