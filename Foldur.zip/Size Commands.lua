owner.Chatted:Connect(function(msg)
msg = string.split(string.lower(msg), ' ')

if msg[1] == '-size' then
size = msg[2]

for i,v in pairs(owner.Character:GetDescendants()) do

if v:IsA("Weld") or v:IsA("Motor6D") then
-- C0 = v.C0
C1 = v.C1

C0P = C0.Position
C0O = C0 - C0.Position

C1P = C1.Position
C1O = C1 - C1.Position

v.C0 = CFrame.new(C0P*size)*C0O

v.C1 = CFrame.new(C1P*size)*C1O

elseif v:IsA("BasePart") then

v.Size = v.Size*size

elseif v:IsA("SpecialMesh") then

if v.MeshType == Enum.MeshType.FileMesh then
v.Scale = v.Scale*size
v.Offset = v.Offset*size
end

elseif v:IsA("Humanoid") then
v.HipHeight = v.HipHeight * size
v.WalkSpeed = v.WalkSpeed * size
v.JumpPower = v.JumpPower * size
end

end
end

end)

NLS([[

local part = script.Parent

humanoid = owner.Character.Humanoid

while true do
task.wait()
for i,v in pairs(humanoid:GetPlayingAnimationTracks()) do

v:AdjustSpeed(part.Size.Magnitude/3)

end
end

]], owner.Character.Torso)