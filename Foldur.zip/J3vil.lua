--193760002 223104924 meshes
--2802812619 music

local torso = Instance.new("SpecialMesh", owner.Character.HumanoidRootPart)
torso.MeshType = 'FileMesh'
torso.MeshId = 'rbxassetid://223104924'
torso.Scale = Vector3.new(.5,.5,.5)
torso.Offset = Vector3.new(0,-1,0)
owner.Character.HumanoidRootPart.BrickColor = BrickColor.new("Brick yellow")
local head = Instance.new("SpecialMesh", owner.Character.Head)
head.MeshType = 'FileMesh'
head.MeshId = 'rbxassetid://193760002'
head.Offset = Vector3.new(0,0,.25)
owner.Character.Head.Color = Color3.fromRGB(38, 20, 74)
for i,v in pairs(owner.Character:GetDescendants()) do
if v:IsA("Decal") or v:IsA("Texture") or v:IsA("BasePart") then
v.Transparency = 1
end
end
owner.Character["Head"].Transparency = 0
owner.Character["HumanoidRootPart"].Transparency = 0

local sound = Instance.new("Sound", owner.Character.Head)
sound.MaxDistance = 50
sound.Looped = true
sound.SoundId = 'rbxassetid://2802812619'
sound.Pitch = 1
sound.Volume = .3
sound:Play()

local sussy = Instance.new("BillboardGui", owner.Character.Head)
sussy.Size = UDim2.fromScale(5,5)
sussy.StudsOffset = Vector3.new(0,4,0)
local frame = Instance.new("TextBox", sussy)
frame.Size = UDim2.new(1,0,1,0)
frame.BorderSizePixel = 0
frame.BackgroundTransparency = 1
frame.Text = 'JEVIL'
frame.TextSize = 50
frame.TextColor3 = owner.Character.Head.Color
frame.Font = 'Fantasy'
frame.TextStrokeTransparency = 0 
frame.TextStrokeColor3 = BrickColor.new("Really blue").Color

local sine = 1

local parts = {}

for i = 1,10 do
local prt = Instance.new("Part", script)
prt:SetNetworkOwner(owner)
prt.Locked = true
prt.Size = Vector3.new(0,0,0)
prt.CanCollide = false
local fire = Instance.new("ParticleEmitter", prt)
fire.Texture = 'rbxasset://textures/particles/Fire_Main.dds'
fire.Color = ColorSequence.new(owner.Character.Head.Color)
fire.Rate = 1000
fire.Size = NumberSequence.new(.5,0)
fire.Lifetime = NumberRange.new(2,2)
fire.RotSpeed = NumberRange.new(30,30)
fire.Rotation = NumberRange.new(10,10)
fire.LockedToPart = false

local fake = fire:Clone()
fake.Parent = prt
fake.EmissionDirection = 'Bottom'

table.insert(parts, prt)
end

Instance.new("ObjectValue", owner.Character).Value = script

game:GetService("RunService").Heartbeat:Connect(function()
sine = sine + 1

frame.Position = UDim2.new(0,math.sin(sine) * 50,0,math.cos(sine) * 50)
frame.Rotation = math.sin(sine) * 20
end)

NLS([[

local sound = owner.Character.Head.Sound
local parts = owner.Character.Value.Value:GetChildren()

for i,v in pairs(parts) do
local force1 = Instance.new("BodyPosition", v)
force1.MaxForce = Vector3.new(math.huge,math.huge,math.huge)
force1.P = 150000
force1.D = 1000

local force2 = Instance.new("BodyGyro", v)
force2.MaxTorque = Vector3.new(math.huge,math.huge,math.huge)
force2.P = 150000
force2.D = 1000
end

local SINE = 1

local fakelerp = Vector3.new(0,1,0)

game:GetService("RunService").RenderStepped:Connect(function()
fakelerp=fakelerp:Lerp(Vector3.new(0,sound.PlaybackLoudness / 20,0), .05)
SINE = SINE + .5
sine = SINE

for i,v in pairs(parts) do
local x = math.sin(i * (2*math.pi / #parts) + (sine / 10)) * math.clamp(fakelerp.Y,5,25)
local z = math.cos(i * (2*math.pi / #parts) + (sine / 10)) * math.clamp(fakelerp.Y,5,25)
CF = CFrame.new(owner.Character.HumanoidRootPart.CFrame * CFrame.new(0,5,0).Position) * CFrame.new(x,0,z)
v.BodyPosition.Position = CF.Position
v.BodyGyro.CFrame = CF
end
end)

]], owner.Character)