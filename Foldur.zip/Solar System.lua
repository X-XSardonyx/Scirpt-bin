SIZE = 1

local SUN = Instance.new("Part", script)
SUN.Material = 'Neon'
SUN.BrickColor = BrickColor.new("Deep orange")
SUN.Size = Vector3.new(5,5,5)*SIZE
SUN:SetNetworkOwner(owner)
SUN.Shape = 'Ball'
SUN.CanCollide = false
SUN.Name = 'sun'

local murc = Instance.new("Part", script)
murc.Material = 'Slate'
murc.CanCollide = false
murc.BrickColor = BrickColor.new("Maroon")
murc.Size = Vector3.new(.75,.75,.75)*SIZE
murc.Name = 'murcury'
murc.Shape = 'Ball'
murc:SetNetworkOwner(owner)

local ven = Instance.new("Part", script)
ven.Material = 'Cobblestone'
ven.CanCollide = false
ven.BrickColor = BrickColor.new("Pastel brown")
ven.Size = Vector3.new(1.5,1.5,1.5)*SIZE
ven.Name = 'venus'
ven.Shape = 'Ball'
ven:SetNetworkOwner(owner)

--ring mesh: 3297805940

local Earth = Instance.new("Part", script)
Earth.Material = 'Glass'
Earth.CanCollide = false
Earth.BrickColor = BrickColor.new("Really blue")
Earth.Size = Vector3.new(1,1,1)*SIZE
Earth.Name = 'earth'
Earth.Shape = 'Ball'
Earth:SetNetworkOwner(owner)

local moon = Instance.new("Part", script)
moon.Material = 'Concrete'
moon.CanCollide = false
moon.Size = Vector3.new(.25,.25,.25)*SIZE
moon.Name = 'moon'
moon.Shape = 'Ball'
moon:SetNetworkOwner(owner)

local mars = Instance.new("Part", script)
mars.Material = 'Granite'
mars.CanCollide = false
mars.BrickColor = BrickColor.new("Persimmon")
mars.Size = Vector3.new(1.75,1.75,1.75)*SIZE
mars.Name = 'mars'
mars.Shape = 'Ball'
mars:SetNetworkOwner(owner)

local jupiter = Instance.new("Part", script)
jupiter.Material = 'Sand'
jupiter.CanCollide = false
jupiter.BrickColor = BrickColor.new("Pastel brown")
jupiter.Size = Vector3.new(2.5,2.5,2.5)*SIZE
jupiter.Name = 'jupiter'
jupiter.Shape = 'Ball'
jupiter:SetNetworkOwner(owner)

local saturn = Instance.new("Part", script)
saturn.Material = 'Wood'
saturn.CanCollide = false
saturn.BrickColor = BrickColor.new("Cork")
saturn.Size = Vector3.new(2,2,2)*SIZE
saturn.Name = 'saturn'
saturn.Shape = 'Ball'
saturn:SetNetworkOwner(owner)

local uranus = Instance.new("Part", script)
uranus.Material = 'Concrete'
uranus.CanCollide = false
uranus.BrickColor = BrickColor.new("Toothpaste")
uranus.Size = Vector3.new(1,1,1)*SIZE
uranus.Name = 'uranus'
uranus.Shape = 'Ball'
uranus:SetNetworkOwner(owner)

local neptune = Instance.new("Part", script)
neptune.Material = 'Glass'
neptune.CanCollide = false
neptune.BrickColor = BrickColor.new("Cyan")
neptune.Size = Vector3.new(1,1,1)*SIZE
neptune.Name = 'neptune'
neptune.Shape = 'Ball'
neptune:SetNetworkOwner(owner)

local pluto = Instance.new("Part", script)
pluto.Material = 'Concrete'
pluto.CanCollide = false
pluto.Color = Color3.fromRGB(100,100,255)
pluto.Size = Vector3.new(.25,.25,.25)*SIZE
pluto.Name = 'PLUTO'
pluto.Shape = 'Ball'
pluto:SetNetworkOwner(owner)

function maketrail(CF1,CF2, parent)

att1 = Instance.new("Attachment", parent)
att1.CFrame = CF1

att2 = Instance.new("Attachment", parent)
att2.CFrame = CF2

trail = Instance.new("Trail", parent)
trail.Attachment0 = att1
trail.Attachment1 = att2
trail.Color = ColorSequence.new(parent.Color)
trail.Lifetime = 3*SIZE
trail.Texture = 'rbxassetid://'..7509141236

end


title = Instance.new("BillboardGui", SUN)
title.Adornee = SUN
title.Size = UDim2.fromScale(16,8)
title.StudsOffset = Vector3.new(0,10*SIZE,0)

text = Instance.new("TextBox", title)
text.Size = UDim2.new(1,0,1,0)
text.BackgroundTransparency = 1
text.Font = 'Code'
text.Text = [[Solar System
By X_XSardonyx]]
text.TextColor3 = BrickColor.new("New Yeller").Color
text.TextScaled = true

int = Instance.new("IntValue", owner.PlayerGui)
int.Value = SIZE
int.Name = 'SIZE'

for i,v in pairs(script:GetChildren()) do
local val = Instance.new("ObjectValue", owner.PlayerGui)
val.Name = v.Name
val.Value = v
v.Locked = true
v.CanTouch = false

bbg = Instance.new("BillboardGui", script)
bbg.Adornee = v
bbg.Size = UDim2.fromScale(4,2)
bbg.StudsOffset = Vector3.new(0,v.Size.Y/2+1,0)


tb = Instance.new("TextBox", bbg)
tb.Size = UDim2.new(1,0,1,0)
tb.BackgroundTransparency = 1
tb.Text = v.Name
tb.TextColor3 = v.Color
tb.TextScaled = true

coroutine.resume(coroutine.create( function()
wait(3)
maketrail(CFrame.new(v.Size.X,0,0),CFrame.new(-v.Size.X,0,0),v)
maketrail(CFrame.new(0,0,v.Size.Z),CFrame.new(0,0,-v.Size.Z),v)

end))
end

NLS([[

SUN = owner.PlayerGui.sun.Value
MUR = owner.PlayerGui.murcury.Value
VEN = owner.PlayerGui.venus.Value
EAR = owner.PlayerGui.earth.Value
MOO = owner.PlayerGui.moon.Value
MAR = owner.PlayerGui.mars.Value
JUP = owner.PlayerGui.jupiter.Value
SAT = owner.PlayerGui.saturn.Value
URA = owner.PlayerGui.uranus.Value
NEP = owner.PlayerGui.neptune.Value
PLU = owner.PlayerGui.PLUTO.Value

local cam = workspace.CurrentCamera

SIZE = owner.PlayerGui.SIZE.Value
HRPPos = owner.Character.HumanoidRootPart.Position + Vector3.new(0,5,0)

PLANETS = {SUN, MUR, VEN, EAR, MOO, MAR, JUP, SAT, URA, NEP, PLU}

VIEWING = false
NUM = 0

specgui = Instance.new("ScreenGui", script)
specgui.IgnoreGuiInset = true

holderframe = Instance.new("Frame", specgui)
holderframe.Size = UDim2.new(.2,0,.25,0)
holderframe.BackgroundTransparency = 1
holderframe.Position = UDim2.new(.4,0,.75,0)

local viewbutton = Instance.new("TextButton", holderframe)
viewbutton.Size = UDim2.new(1,0,1,0)
viewbutton.BackgroundTransparency = 1
viewbutton.Text = 'View PLANETS'
viewbutton.TextColor3 = BrickColor.new("Institutional white").Color
viewbutton.TextScaled = true

viewbutton.MouseButton1Click:Connect(function()
viewbutton.Text = 'View PLANETS'

if NUM == #PLANETS then
NUM = 0
cam.CameraSubject = owner.Character.Humanoid
elseif NUM ~= #PLANETS then
NUM = NUM + 1
cam.CameraSubject = PLANETS[NUM]
end
if NUM == #PLANETS then
viewbutton.Text = 'View PLAYER'
end
end)

for i,v in pairs(PLANETS) do
pos = Instance.new("BodyPosition", v)
pos.P = 150000
pos.D = 1000
pos.MaxForce = Vector3.new(math.huge,math.huge,math.huge)

end

Circle = 2*math.pi

sine = 0

game:GetService("RunService").RenderStepped:Connect(function()

sine = sine + .1

SUN.BodyPosition.Position = HRPPos

MURX = math.sin(Circle + sine/2)*6*SIZE
MURZ = math.cos(Circle + sine/2)*6*SIZE

MURCF = SUN.Position + Vector3.new(MURX,0,MURZ)

MUR.BodyPosition.Position = MURCF

--venus

VENX = math.sin(Circle + sine/3)*10*SIZE
VENZ = math.cos(Circle + sine/3)*10*SIZE

VENCF = SUN.Position + Vector3.new(VENX,0,VENZ)

VEN.BodyPosition.Position = VENCF

--earth 

EARX = math.sin(Circle + sine/5)*14*SIZE
EARZ= math.cos(Circle + sine/5)*14*SIZE

EARCF = SUN.Position + Vector3.new(EARX,0,EARZ)

EAR.BodyPosition.Position = EARCF

--moon 
MOOX = math.sin(Circle + sine/3)*2*SIZE
MOOZ= math.cos(Circle + sine/3)*2*SIZE

MOOCF = EAR.Position + Vector3.new(MOOX,0,MOOZ)

MOO.BodyPosition.Position = MOOCF

--MARS

MARX = math.sin(Circle + sine/2.5)*17*SIZE
MARZ= math.cos(Circle + sine/2.5)*17*SIZE

MARCF = SUN.Position + Vector3.new(MARX,0,MARZ)

MAR.BodyPosition.Position = MARCF

--jupiter

JUPX = math.sin(Circle + sine/7)*22*SIZE
JUPZ= math.cos(Circle + sine/7)*22*SIZE

JUPCF = SUN.Position + Vector3.new(JUPX,0,JUPZ)

JUP.BodyPosition.Position = JUPCF

--saturn

SATX = math.sin(Circle + sine/10)*27*SIZE
SATZ = math.cos(Circle + sine/10)*27*SIZE

SATCF = SUN.Position + Vector3.new(SATX,0,SATZ)

SAT.BodyPosition.Position = SATCF
--uranus
URAX = math.sin(Circle + sine/15)*33*SIZE
URAZ = math.cos(Circle + sine/15)*33*SIZE

URACF = SUN.Position + Vector3.new(URAX,0,URAZ)

URA.BodyPosition.Position = URACF

--NEP

NEPX = math.sin(Circle + sine/22)*38*SIZE
NEPZ = math.cos(Circle + sine/22)*38*SIZE

NEPCF = SUN.Position + Vector3.new(NEPX,0,NEPZ)

NEP.BodyPosition.Position = NEPCF

--PLUTO

PLUX = math.sin(Circle + sine/25)*42*SIZE
PLUZ = math.cos(Circle + sine/25)*42*SIZE

PLUCF = SUN.Position + Vector3.new(PLUX,0,PLUZ)

PLU.BodyPosition.Position = PLUCF

end)

]], owner.PlayerGui)

print("Solar System by X_XSardonyx")