owner.Character.Humanoid:ApplyDescription(Instance.new("HumanoidDescription"))

--head
Vec = Vector3.new(1.25, .67, 1.25)
Vec2 = Vector3.new(.8,1.25,1.25)

pos = Vector3.new(0,.4,0)

mesh1 = Instance.new("Part", owner.Character.Head)

mesh1.Shape = 'Cylinder'
mesh1.Reflectance = 1
mesh1.Size = Vec2

mesh1.CanCollide = false
mesh1.Massless = true

weld = Instance.new("Weld", mesh1)

weld.Part1 = mesh1
weld.Part0 = owner.Character.Head
weld.C0 = CFrame.Angles(0,0,math.rad(90))

mesh2 = Instance.new("Part", owner.Character.Head)
mesh2.Reflectance = 1
mesh2.Size = Vec
mesh2.CanCollide = false
mesh2.Massless = true
Instance.new("SpecialMesh", mesh2).MeshType = 'Sphere'

weld2 = Instance.new("Weld", mesh2)
weld2.Part1 = mesh2
weld2.Part0 = owner.Character.Head
weld2.C0 = CFrame.new(pos)


mesh3 = Instance.new("Part", owner.Character.Head)
mesh3.Reflectance = 1
mesh3.Size = Vec
mesh3.CanCollide = false
mesh3.Massless = true
Instance.new("SpecialMesh", mesh3).MeshType = 'Sphere'

weld3 = Instance.new("Weld", mesh3)
weld3.Part1 = mesh3
weld3.Part0 = owner.Character.Head
weld3.C0 = CFrame.new(-pos)

--head

owner.Character.Head.Transparency = 1
owner.Character.Head.Size = Vector3.new(2.075,1.075,1.075)

if owner.Character:FindFirstChildWhichIsA("Decal") then
decal = owner.Character:FindFirstChildWhichIsA("Decal")
decal.Texture = 'rbxasset://textures/face.png'
decal.Transparency = -1
for i = 1,10 do
decal:Clone().Parent = decal.Parent
end
else
decal = Instance.new("Decal", owner.Character.Head)
decal.Texture = 'rbxasset://textures/face.png'
decal.Transparency = -1

for i = 1,10 do
decal:Clone().Parent = decal.Parent
end

end

for i,v in pairs(owner.Character:GetDescendants()) do
if v:IsA("Motor6D") then
local weld = Instance.new("Weld", v.Parent)
weld.Part1 = v.Part1
weld.Part0 = v.Part0
weld.C0 = v.C0
weld.C1 = v.C1
weld.Name = v.Name
v:Destroy()

elseif v:IsA("BasePart") then
v.Reflectance = 1
v.Material = 'SmoothPlastic'
end
end

--Anim Defaults
AnimDefaults = {
Head = owner.Character.Torso.Neck.C0,
Torso = owner.Character.HumanoidRootPart.RootJoint.C0,
Larm = owner.Character.Torso["Left Shoulder"].C0,
Rarm = owner.Character.Torso["Right Shoulder"].C0,
Lleg = owner.Character.Torso["Left Hip"].C0,
Rleg = owner.Character.Torso["Right Hip"].C0
}
--Setting Joints
Head = owner.Character.Torso.Neck
Torso = owner.Character.HumanoidRootPart.RootJoint
Larm = owner.Character.Torso["Left Shoulder"]
Rarm = owner.Character.Torso["Right Shoulder"]
Lleg = owner.Character.Torso["Left Hip"]
Rleg = owner.Character.Torso["Right Hip"]

sine = 0

local Smack = Instance.new("Sound", owner.Character.HumanoidRootPart)
Smack.SoundId = 'rbxassetid://1929979456'
Smack.Volume = 1
Smack.MaxDistance = 100
Smack.Looped = true
Smack:Play()


local tool = Instance.new("Tool", owner.Backpack)
tool.Name = ''
tool.CanBeDropped = false
tool.Grip = CFrame.new(1.5,0,0)

union = Instance.new("Part", script)
union.Size = Vector3.new(2.5,2.5,2.5)
union.CanCollide = false
union.Massless = true
union.Reflectance = 1
union.Shape = 'Ball'
union.Anchored = true

cut = Instance.new("Part", script)
cut.CanCollide = false
cut.Shape = 'Cylinder'
cut.CFrame = union.CFrame * CFrame.new(0,0,-1) * CFrame.Angles(0,math.rad(90),0)
cut.Anchored = true
cut.Size = Vector3.new(1.5,1.5,2)

handle = union:SubtractAsync({cut})
handle.Name = 'Handle'
handle.Parent = tool
handle.Anchored = false

union:Destroy()
cut:Destroy()

game:GetService("RunService").Heartbeat:Connect(function()
sine = sine + owner.Character.Humanoid.WalkSpeed/16/5

if owner.Character.HumanoidRootPart.Velocity.Magnitude > 1 then

Smack.Pitch = owner.Character.Humanoid.WalkSpeed/16

Larm.C0 = AnimDefaults.Larm * CFrame.Angles(0,0,math.round(math.rad(math.sin(sine))*45))
Rleg.C0 = AnimDefaults.Rleg * CFrame.Angles(0,0,math.round(math.rad(math.sin(sine))*45))

Rarm.C0 = AnimDefaults.Rarm * CFrame.Angles(0,0,math.round(math.rad(math.sin(sine))*45))
Lleg.C0 = AnimDefaults.Lleg * CFrame.Angles(0,0,math.round(math.rad(math.sin(sine))*45))

if tool.Parent == owner.Character then
Rarm.C0 = AnimDefaults.Rarm * CFrame.Angles(0,0,math.rad(90))
Larm.C0 = AnimDefaults.Larm * CFrame.Angles(0,0,math.rad(-90))
end

else

Smack.Pitch = 0

Larm.C0 = AnimDefaults.Larm
Rleg.C0 = AnimDefaults.Rleg
Rarm.C0 = AnimDefaults.Rarm
Lleg.C0 = AnimDefaults.Lleg
Torso.C0 = AnimDefaults.Torso

if owner.Character:FindFirstChildWhichIsA("Tool") then
Rarm.C0 = AnimDefaults.Rarm * CFrame.Angles(0,0,math.rad(90))
Larm.C0 = AnimDefaults.Larm * CFrame.Angles(0,0,math.rad(-90))
end
end

if owner.Character.Humanoid.Sit == true then
Rarm.C0 = AnimDefaults.Rarm * CFrame.Angles(0,0,math.rad(90))
Larm.C0 = AnimDefaults.Larm * CFrame.Angles(0,0,math.rad(-90))
Lleg.C0 = AnimDefaults.Lleg * CFrame.Angles(0,0,math.rad(-90))
Rleg.C0 = AnimDefaults.Rleg * CFrame.Angles(0,0,math.rad(90))
end

end)

tool.Activated:Connect(function()
projectile = Instance.new("SpawnLocation", script)
projectile.Enabled = false
projectile.Shape = 'Ball'
projectile.Size = Vector3.new(1.5,1.5,1.5)
projectile.CFrame = handle.CFrame * CFrame.new(0,0,-1)
projectile.Velocity = projectile.CFrame.LookVector * 200
projectile.Reflectance = 1
end)

print("MIRROR MAN MORPH BY X_XSARDONYX")