---5164348874

for i,v in pairs(owner.Character:GetDescendants()) do
if v:IsA("Motor6D") then
local weld = Instance.new("Weld", v.Parent)
weld.Part1 = v.Part1
weld.Part0 = v.Part0
weld.C0 = v.C0
weld.C1 = v.C1
weld.Name = v.Name
v:Destroy()
end
end

script.Parent = owner.Character

--Anim Defaults
AnimDefaults = {
Head = owner.Character.Torso.Neck.C0,
Torso = owner.Character.HumanoidRootPart.RootJoint.C0,
Larm = owner.Character.Torso["Left Shoulder"].C0,
Rarm = owner.Character.Torso["Right Shoulder"].C0,
Lleg = owner.Character.Torso["Left Hip"].C0,
Rleg = owner.Character.Torso["Right Hip"].C0
}
--Setting Joints
Head = owner.Character.Torso.Neck
Torso = owner.Character.HumanoidRootPart.RootJoint
Larm = owner.Character.Torso["Left Shoulder"]
Rarm = owner.Character.Torso["Right Shoulder"]
Lleg = owner.Character.Torso["Left Hip"]
Rleg = owner.Character.Torso["Right Hip"]

local sine = 1

local sound = Instance.new("Sound", owner.Character.Torso)
sound.MaxDistance = 100
sound.Looped = true
sound.SoundId = 'rbxassetid://5164348874'
sound.Pitch = 1
sound.Volume = 2
sound:Play()

owner.Character.Humanoid.WalkSpeed = 45

game:GetService("RunService").Heartbeat:Connect(function()
sine = sine + 1
if owner.Character.HumanoidRootPart.Velocity.Magnitude < 1 then
Torso.C0 = Torso.C0:Lerp(AnimDefaults.Torso * CFrame.Angles(math.rad(15),math.rad(math.sin(sine / 3)) * 25,0), .1)
Larm.C0 = Larm.C0:Lerp(AnimDefaults.Larm * CFrame.Angles(math.rad(math.sin(sine / 3)) * 50,0,-math.rad(15)), .1)
Rarm.C0 = Rarm.C0:Lerp(AnimDefaults.Rarm * CFrame.Angles(-math.rad(math.sin(sine / 3)) * 50,0,math.rad(15)), .1)
Lleg.C0 = Lleg.C0:Lerp(AnimDefaults.Lleg * CFrame.Angles(0,0,-math.rad(15)), .1)
Rleg.C0 = Rleg.C0:Lerp(AnimDefaults.Rleg * CFrame.Angles(0,0,math.rad(15)), .1)
else
Torso.C0 = Torso.C0:Lerp(AnimDefaults.Torso * CFrame.Angles(math.rad(-45),0,0), .1)
Larm.C0 = Larm.C0:Lerp(AnimDefaults.Larm * CFrame.Angles(0,0,-math.rad(-150)), .1)
Rarm.C0 = Rarm.C0:Lerp(AnimDefaults.Rarm * CFrame.Angles(0,0,math.rad(-150)), .1)
Lleg.C0 = Lleg.C0:Lerp(AnimDefaults.Lleg * CFrame.Angles(0,0,math.rad(math.sin(sine / 3)) * 120), .25)
Rleg.C0 = Rleg.C0:Lerp(AnimDefaults.Rleg * CFrame.Angles(0,0,math.rad(math.sin(sine / 3)) * 120), .25)

end
end)