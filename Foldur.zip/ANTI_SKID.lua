local radius = 2
local circle = 2 * math.pi

local tool = Instance.new("Tool", owner.Backpack)
tool.Name = 'its ok to bully if they die'
local handle = Instance.new("Part", tool)
handle.Name = 'Handle'
handle.Size = Vector3.new(1.25,1.25,1.25)
handle.Transparency = 1
handle.Massless = true

local handle = handle:Clone()
handle.Parent = tool.Handle
handle.Massless = true

local weld = Instance.new("Weld", handle)
weld.Part1 = tool.Handle
weld.Part0 = handle

local OLDHANDLE = tool.Handle

handle.Transparency = 0

local materials = {'Grass', 'Glass', 'Granite', 'Marble', 'Slate', 'ForceField', 'Neon'}


local spin = Instance.new("Part", tool)
spin.Anchored = true
spin.CanCollide = false
spin.Size = Vector3.new(.25,.25,.25)
spin.Material = 'Neon'


game:GetService'RunService'.Heartbeat:Connect(function()
if tool.Parent ~= workspace then
handle.Material = materials[math.random(1, #materials)]
handle.BrickColor = BrickColor.Random()
weld.C0 = CFrame.new(math.random(-5,5) / 10,math.random(-5,5) / 10,math.random(-5,5) / 10) * CFrame.Angles(math.sin(tick()) * 5,math.sin(tick()) * 5,math.sin(tick()) * 5)
else
handle.Material = 'SmoothPlastic'
weld.C0 = CFrame.new(0,0,0)
handle.BrickColor = tool.Handle.BrickColor
end
end)

handle.Touched:Connect(function(part)
if part.Parent ~= tool.Parent and part ~= spin and tool.Parent.ClassName == 'Model' and part.Name ~= 'Baseplate' and part.Name ~= 'Base' then
part.Material = materials[math.random(1, #materials)]
part.BrickColor = BrickColor.random()
part.Size = Vector3.new(math.random(1,5),math.random(1,5),math.random(1,5))
wait(1)
part:Destroy()
end
end)



game:GetService("RunService").Heartbeat:Connect(function()
local x = math.cos(tick() * 30 / circle) * 2
local z = math.sin(tick() * 30 / circle) * 2

spin.CFrame = OLDHANDLE.CFrame * CFrame.new(x,z,0)
spin.CFrame = CFrame.new(spin.Position, OLDHANDLE.Position)

end)