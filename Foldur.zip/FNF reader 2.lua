charts={
expurgation={[[https://raw.githubusercontent.com/X-XSardonyx/VSB-Scripts/main/expurgation-hard.json]], 6900844331, "Expurgation"},
happy={[[https://raw.githubusercontent.com/X-XSardonyx/VSB-Scripts/main/really-happy-hard.json]], 7795670300, "Really Happy"},
roses={[[https://raw.githubusercontent.com/ninjamuffin99/Funkin/master/assets/preload/data/roses/roses.json]], 6337428158, "Roses"},
fresh={[[https://raw.githubusercontent.com/ninjamuffin99/Funkin/master/assets/preload/data/fresh/fresh.json]] ,6025191328,"Fresh"},
winterhorrorland={[[https://raw.githubusercontent.com/ninjamuffin99/Funkin/master/assets/preload/data/winter-horrorland/winter-horrorland.json]] ,6275837083,'Winter Horrorland'},
south={[[https://raw.githubusercontent.com/ninjamuffin99/Funkin/master/assets/preload/data/south/south.json]] ,6038765924 ,'South'},
nonsence={[[https://raw.githubusercontent.com/X-XSardonyx/VSB-Scripts/main/nonsence.json]], 7102185418 ,"nonsense"},
commonsense={[[https://raw.githubusercontent.com/X-XSardonyx/VSB-Scripts/main/Common%20sense.json]], 7112426008, 'Common Sense'},
opheebop={[[https://raw.githubusercontent.com/Radhew/Salt-Engine/master/assets/preload/data/opheebop/opheebop.json]], 6730593959, 'Opheebop'},
bsmilf={[[https://raw.githubusercontent.com/kckarnige/fnf-week-7-code/main/src/assets/data/milf/milf.json]], 7071427516, 'B-Side Milf'},
endless={[[https://raw.githubusercontent.com/CryBitDev/Sonic.exe-source-1.5/master/assets/preload/data/endless/endless-hard.json]] ,7313871314 ,"Endless"},
sunshine={[[https://raw.githubusercontent.com/wildythomas/mmmbob/main/assets/preload/data/sunshine/sunshine.json]] , 6822649446 ,'Sunshine'},
withered={[[https://raw.githubusercontent.com/wildythomas/mmmbob/main/assets/preload/data/withered/withered.json]] , 6822655743 ,'Withered'},
run={[[https://raw.githubusercontent.com/wildythomas/mmmbob/main/assets/preload/data/run/run.json]], 6822647318, 'RUN'},
release={[[https://raw.githubusercontent.com/Rageminer996/Smoke-Em-Out-Struggle-Mod/main/assets/preload/data/release/release.json]], 6767491531, 'Release'},
nerves={[[https://raw.githubusercontent.com/Rageminer996/Smoke-Em-Out-Struggle-Mod/main/assets/preload/data/nerves/nerves.json]], 6763964321, 'Nerves'},
headache={[[https://raw.githubusercontent.com/Rageminer996/Smoke-Em-Out-Struggle-Mod/main/assets/preload/data/headache/headache.json]], 6765405147,'Headache'},
fading={[[https://raw.githubusercontent.com/Rageminer996/Smoke-Em-Out-Struggle-Mod/main/assets/preload/data/fading/fading.json]], 6770738952 , 'Fading'},
magelo={[[https://fnf-songs.errortp.repl.co/megalostrikeback.html]], 6745517883,'Magelostrikeback'},
otherfriends={[[https://raw.githubusercontent.com/theevity1/VS-Spinel/master/assets/preload/data/other-friends/other-friends.json]], 7490567703, 'Other Friends'},
flippyroll={[[https://raw.githubusercontent.com/Yirius125/FNF-VsFliqpy-1.5-Full-Week-Engine/main/assets/preload/data/flippy-roll/flippy-roll.json]], 7047986662, 'Flippy-Roll'},
finaldestination={[[https://raw.githubusercontent.com/GithubSPerez/shaggy-matt/main/assets/preload/data/final-destination/final-destination-god.json]], 7057969804 , 'Final Destination'},
nonsensical={[[https://raw.githubusercontent.com/X-XSardonyx/VSB-Scripts/main/nonsensical.json]], 7361704969, "Nonsensical"},
playtime={[[https://raw.githubusercontent.com/X-XSardonyx/VSB-Scripts/main/Playtime.json]], 7838052823,'Playtime'},
nohero={[[https://raw.githubusercontent.com/X-XSardonyx/VSB-Scripts/main/no-hero.json]], 7951754097, 'No-Hero'},
change={[[https://raw.githubusercontent.com/X-XSardonyx/VSB-Scripts/main/you'll-make-the-change-hard.json]], 8055850993, "Youll Make The Change"},
MONOCHROME = {[[https://raw.githubusercontent.com/Yoshubs/Hypnos-Lullaby/master/assets/preload/data/monochrome/monochrome.json]], 7860856702, "Monochrome"}

}

currentchart = nil

frame = Instance.new("Frame", Instance.new("ScreenGui", owner.PlayerGui))
frame.Size = UDim2.new(.25,0,.75,0)
frame.BackgroundTransparency = .9
frame.Position = UDim2.new(.375,0,.125,0)
num = 0

NUM = 0

for i,v in pairs(charts) do
NUM = NUM + 1
end

for I,v in pairs(charts) do
num = num + 1
button = Instance.new("TextButton",frame)
button.Size = UDim2.new(1,0,1/NUM,0)
button.BackgroundTransparency = .5
button.BackgroundColor = BrickColor.new("Really black")
button.TextColor = BrickColor.new("Institutional white")
button.TextScaled = true
button.BorderSizePixel = 0
button.Text = v[3]

button.Position = UDim2.new(0,0,num/NUM,0) - UDim2.new(0,0,1/NUM,0)

button.MouseButton1Click:Connect(function()
frame.Parent:Destroy()
currentchart = v
end)

end

repeat task.wait() until currentchart ~= nil

HTTP = game:GetService("HttpService")
Data = HTTP:JSONDecode(HTTP:GetAsync(currentchart[1]))
print(Data.song.song)
keys = Data.song.notes

local sound = Instance.new("Sound", owner.Character.HumanoidRootPart)
sound.SoundId = 'rbxassetid://'..currentchart[2]
sound.Volume = 3
sound.MaxDistance = 100
sound:Play()

script.Parent = owner.Character

local left = Instance.new("Part", script)
local up = Instance.new("Part", script)
local down = Instance.new("Part", script)
local right = Instance.new("Part", script)

for i,v in pairs({left,up,down,right}) do
v.Size = Vector3.new(1,1,1)
v.CanCollide = false
v.Massless = true
v.Material = 'SmoothPlastic'
v.BrickColor=BrickColor.new("Really black")


weld= Instance.new("Weld", v)
weld.Part1 = v
weld.Part0 = owner.Character.HumanoidRootPart
weld.C0 = CFrame.new(-2.5+i,5,0)

end

function key(num)
posing = true



if num == 0 then

coroutine.resume(coroutine.create(function()

effect = Instance.new("SpawnLocation", script)
effect.Size = Vector3.new(.9,.9,.9)
effect.CanCollide = false
effect.Massless = true
effect.Enabled = false
effect.Material = 'SmoothPlastic'
effect.Color = Color3.fromHSV(num/4,1,1)

weld= Instance.new("Weld", effect)
weld.Part1 = effect
weld.Part0 = left
weld.C0 = CFrame.new(0,8,0)

game:GetService("TweenService"):Create(weld,TweenInfo.new(1, Enum.EasingStyle.Linear),{C0 = CFrame.new(0,0,0)}):Play()
game:GetService("Debris"):AddItem(effect, 1)

wait(1)
left.Color = Color3.fromHSV(num/4,1,1)
wait(.1)
left.BrickColor=BrickColor.new("Really black")
end))


elseif num == 1 then
coroutine.resume(coroutine.create(function()

effect = Instance.new("SpawnLocation", script)
effect.Size = Vector3.new(.9,.9,.9)
effect.CanCollide = false
effect.Enabled = false
effect.Material = 'SmoothPlastic'
effect.Massless = true
effect.Color = Color3.fromHSV(num/4,1,1)

weld = Instance.new("Weld", effect)
weld.Part1 = effect
weld.Part0 = up
weld.C0 = CFrame.new(0,8,0)

game:GetService("TweenService"):Create(weld,TweenInfo.new(1, Enum.EasingStyle.Linear),{C0 = CFrame.new(0,0,0)}):Play()
game:GetService("Debris"):AddItem(effect, 1)

wait(1)
up.Color = Color3.fromHSV(num/4,1,1)
wait(.1)
up.BrickColor=BrickColor.new("Really black")
end))

elseif num == 2 then
coroutine.resume(coroutine.create(function()

effect = Instance.new("SpawnLocation", script)
effect.Size = Vector3.new(.9,.9,.9)
effect.CanCollide = false
effect.Massless = true
effect.Enabled = false
effect.Material = 'SmoothPlastic'
effect.Color = Color3.fromHSV(num/4,1,1)

weld= Instance.new("Weld", effect)
weld.Part1 = effect
weld.Part0 = down
weld.C0 = CFrame.new(0,8,0)

game:GetService("TweenService"):Create(weld,TweenInfo.new(1, Enum.EasingStyle.Linear),{C0 = CFrame.new(0,0,0)}):Play()
game:GetService("Debris"):AddItem(effect, 1)

wait(1)
down.Color = Color3.fromHSV(num/4,1,1)
wait(.1)
down.BrickColor=BrickColor.new("Really black")
end))

elseif num == 3 then
coroutine.resume(coroutine.create(function()

effect = Instance.new("SpawnLocation", script)
effect.Size = Vector3.new(.9,.9,.9)
effect.CanCollide = false
effect.Massless = true
effect.Enabled = false
effect.Material = 'SmoothPlastic'
effect.Color = Color3.fromHSV(num/4,1,1)

weld= Instance.new("Weld", effect)
weld.Part1 = effect
weld.Part0 = right
weld.C0 = CFrame.new(0,8,0)

game:GetService("TweenService"):Create(weld,TweenInfo.new(1, Enum.EasingStyle.Linear),{C0 = CFrame.new(0,0,0)}):Play()
game:GetService("Debris"):AddItem(effect, 1)

wait(1)
right.Color = Color3.fromHSV(num/4,1,1)
wait(.1)
right.BrickColor=BrickColor.new("Really black")
end))

end
posing = false
end

for i = 1, #keys do

		sectionkeys = keys[i]["sectionNotes"]
		bpm = keys[i]["bpm"] or 0
		if not keys[i]["mustHitSection"] then
		for b = 1, #sectionkeys do
			local what = sectionkeys[b]
			coroutine.wrap(function()
				task.wait((what[1]/1000)-1)
				if what[2] == 0 then
					key(0)
				end
				if what[2] == 1 then
					key(1)
				end
				if what[2] == 2 then
					key(2)
				end
				if what[2] == 3 then
					key(3)
				end
			end)()
		end
		else
		for b = 1, #sectionkeys do
			local what = sectionkeys[b]
			coroutine.wrap(function()
				task.wait((what[1]/1000)-1)
				if what[2] == 4 then
					key(4)
				end
				if what[2] == 5 then
					key(5)
				end
				if what[2] == 6 then
					key(6)
				end
				if what[2] == 7 then
					key(7)
				end
			end)
		end
		end	
		
		
		
				if keys[i]["mustHitSection"] then
		for b = 1, #sectionkeys do
			local what = sectionkeys[b]
			coroutine.wrap(function()
				task.wait((what[1]/1000)-1)
				if what[2] == 0 then
					key(0)
				end
				if what[2] == 1 then
					key(1)
				end
				if what[2] == 2 then
					key(2)
				end
				if what[2] == 3 then
					key(3)
				end
			end)()
		end
		else
		for b = 1, #sectionkeys do
			local what = sectionkeys[b]
			coroutine.wrap(function()
				task.wait((what[1]/1000)-1)
				if what[2] == 4 then
					key(4)
				end
				if what[2] == 5 then
					key(5)
				end
				if what[2] == 6 then
					key(6)
				end
				if what[2] == 7 then
					key(7)
				end
			end)
		end
		end	
		
		
		
	end