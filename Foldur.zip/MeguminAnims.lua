for i,v in pairs(owner.Character:GetDescendants()) do
if v:IsA("Motor6D") then
local weld = Instance.new("Weld", v.Parent)
weld.Part1 = v.Part1
weld.Part0 = v.Part0
weld.C0 = v.C0
weld.C1 = v.C1
weld.Name = v.Name
v:Destroy()
end
end

Attack = false

script.Parent = owner.Character

--Anim Defaults
AnimDefaults = {
Head = owner.Character.Torso.Neck.C0,
Torso = owner.Character.HumanoidRootPart.RootJoint.C0,
Larm = owner.Character.Torso["Left Shoulder"].C0,
Rarm = owner.Character.Torso["Right Shoulder"].C0,
Lleg = owner.Character.Torso["Left Hip"].C0,
Rleg = owner.Character.Torso["Right Hip"].C0
}
--Setting Joints
Head = owner.Character.Torso.Neck
Torso = owner.Character.HumanoidRootPart.RootJoint
Larm = owner.Character.Torso["Left Shoulder"]
Rarm = owner.Character.Torso["Right Shoulder"]
Lleg = owner.Character.Torso["Left Hip"]
Rleg = owner.Character.Torso["Right Hip"]

local DB = false

local staff = Instance.new("Part", owner.Character)
staff.Name = 'staff'
staff.CanCollide = false
staff.Size = Vector3.new(1,6,1)

local mesh = Instance.new("SpecialMesh", staff)

mesh.MeshType = Enum.MeshType.FileMesh
mesh.Scale = Vector3.new(.035,.035,.035)
mesh.MeshId = "rbxassetid://6966030497"
mesh.Offset = Vector3.new(0,1.8,0)
mesh.TextureId = 'rbxassetid://636922344'

local ball = Instance.new("Part", staff)
ball.Size = Vector3.new(.9,.9,.9)
ball.Locked = true
ball.Material = 'Granite'
ball.Shape = 'Ball'
ball.CanCollide = false
ball.Color = Color3.fromRGB(255,100,100)

weld = Instance.new("Weld", ball)
weld.Part1 = ball
weld.Part0 = staff
weld.C0 = CFrame.new(0,3.8,0)

local SW = Instance.new("Weld", staff)
SW.Part1 = staff
SW.Part0 = owner.Character["Right Arm"]
SW.C0 = CFrame.new(0,-1,0) * CFrame.Angles(0,math.rad(90),math.rad(-90))

sine = 1

game:GetService("RunService").Heartbeat:Connect(function()
sine = sine + .1
if owner.Character.HumanoidRootPart.Velocity.Magnitude < 1 then

Torso.C0 = Torso.C0:Lerp(AnimDefaults.Torso * CFrame.new(0,0,math.sin(sine)/5), .1)
Rarm.C0 = Rarm.C0:Lerp(AnimDefaults.Rarm * CFrame.new(.5,math.sin(sine)/10,.5) * CFrame.Angles(0,math.rad(-90), math.rad(90)), .1)
Larm.C0 = Larm.C0:Lerp(AnimDefaults.Larm *  CFrame.new(0,-.25 + math.sin(sine)/10,0) * CFrame.Angles(0,math.rad(10), math.rad(10)), .1)
Lleg.C0 = Lleg.C0:Lerp(AnimDefaults.Lleg * CFrame.new(0,math.sin(-sine)/10,0) * CFrame.Angles(0,math.rad(15),0), .2)
Rleg.C0 = Rleg.C0:Lerp(AnimDefaults.Rleg * CFrame.new(0,math.sin(-sine)/10,0) *  CFrame.Angles(0,math.rad(0),0), .2)

elseif owner.Character.HumanoidRootPart.Velocity.Magnitude > 1 then

Torso.C0 = Torso.C0:Lerp(AnimDefaults.Torso * CFrame.new(0,0,math.sin(sine*2)/5), .1)
Rarm.C0 = Rarm.C0:Lerp(AnimDefaults.Rarm *  CFrame.Angles(0,math.rad(math.sin(sine) * 30), -math.rad(math.sin(sine ) * 45)), .1)
Larm.C0 = Larm.C0:Lerp(AnimDefaults.Larm *  CFrame.Angles(0,math.rad(math.sin(sine) * 30), -math.rad(math.sin(sine ) * 45)), .1)
Lleg.C0 = Lleg.C0:Lerp(AnimDefaults.Lleg *  CFrame.Angles(0,-math.rad(0), math.rad(math.sin(sine) * 45)), .1)
Rleg.C0 = Rleg.C0:Lerp(AnimDefaults.Rleg *  CFrame.Angles(0,-math.rad(0), math.rad(math.sin(sine) * 45)), .1)

end
end)