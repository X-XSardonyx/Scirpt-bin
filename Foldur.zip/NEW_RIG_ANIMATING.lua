local Character = Instance.new("Model")
Character.Name = "Character"
Character.WorldPivot = CFrame.new(-24.563079833984, 7.4499998092651, -8.9164180755615)

local LeftFoot = Instance.new("Part")
LeftFoot.Name = "LeftFoot"
LeftFoot.Anchored = false
LeftFoot.BottomSurface = Enum.SurfaceType.Smooth
LeftFoot.TopSurface = Enum.SurfaceType.Smooth
LeftFoot.Size = Vector3.new(0.59999990463257, 1, 2)
LeftFoot.CFrame = CFrame.new(-25.363080978394, 3.5999999046326, -9.0164184570313)
LeftFoot.Parent = Character

local RightLowerLeg = Instance.new("Part")
RightLowerLeg.Name = "RightLowerLeg"
RightLowerLeg.Anchored = false
RightLowerLeg.BottomSurface = Enum.SurfaceType.Smooth
RightLowerLeg.TopSurface = Enum.SurfaceType.Smooth
RightLowerLeg.Size = Vector3.new(0.59999990463257, 1.5, 0.60000002384186)
RightLowerLeg.CFrame = CFrame.new(-23.763080596924, 4.8499999046326, -8.3164186477661)
RightLowerLeg.Parent = Character

local RightAnkle = Instance.new("Weld")
RightAnkle.Name = "RightAnkle"
RightAnkle.C1 = CFrame.new(0, -0.70000028610229, 0)
RightAnkle.C0 = CFrame.new(0, 0.54999971389771, 0.69999980926514)
RightAnkle.Parent = RightLowerLeg

local RightUpperLeg = Instance.new("Part")
RightUpperLeg.Name = "RightUpperLeg"
RightUpperLeg.Anchored = false
RightUpperLeg.BottomSurface = Enum.SurfaceType.Smooth
RightUpperLeg.TopSurface = Enum.SurfaceType.Smooth
RightUpperLeg.Size = Vector3.new(0.59999990463257, 1.5, 0.60000002384186)
RightUpperLeg.CFrame = CFrame.new(-23.763080596924, 6.3499999046326, -8.3164186477661)
RightUpperLeg.Parent = Character

local RightShin = Instance.new("Weld")
RightShin.Name = "RightShin"
RightShin.C1 = CFrame.new(0, -0.79999971389771, 0)
RightShin.C0 = CFrame.new(0, 0.70000028610229, 0)
RightShin.Parent = RightUpperLeg

local RightHand = Instance.new("Part")
RightHand.Name = "RightHand"
RightHand.Anchored = false
RightHand.BottomSurface = Enum.SurfaceType.Smooth
RightHand.TopSurface = Enum.SurfaceType.Smooth
RightHand.Size = Vector3.new(0.59999990463257, 0.60000002384186, 0.60000002384186)
RightHand.CFrame = CFrame.new(-23.163080215454, 6.8000001907349, -8.3164186477661)
RightHand.Parent = Character

local UpperTorso = Instance.new("Part")
UpperTorso.Name = "UpperTorso"
UpperTorso.Anchored = false
UpperTorso.BottomSurface = Enum.SurfaceType.Smooth
UpperTorso.TopSurface = Enum.SurfaceType.Smooth
UpperTorso.Size = Vector3.new(2.1999998092651, 1.5, 0.60000002384186)
UpperTorso.CFrame = CFrame.new(-24.563081741333, 9.3500003814697, -8.3164186477661)
UpperTorso.Parent = Character

local Neck = Instance.new("Weld")
Neck.Name = "Neck"
Neck.C1 = CFrame.new(0, 0.80000019073486, 0)
Neck.C0 = CFrame.new(0, -0.79999923706055, 0)
Neck.Parent = UpperTorso

local LeftShoulder = Instance.new("Weld")
LeftShoulder.Name = "LeftShoulder"
LeftShoulder.C1 = CFrame.new(-1.3999996185303, 0.69999980926514, 0)
LeftShoulder.C0 = CFrame.new(-1.9073486328125e-06, 0.69999980926514, 0)
LeftShoulder.Parent = UpperTorso

local RightShoulder = Instance.new("Weld")
RightShoulder.Name = "RightShoulder"
RightShoulder.C1 = CFrame.new(1.3999996185303, 0.69999980926514, 0)
RightShoulder.C0 = CFrame.new(-1.9073486328125e-06, 0.69999980926514, 0)
RightShoulder.Parent = UpperTorso

local Head = Instance.new("Part")
Head.Name = "Head"
Head.Anchored = false
Head.BottomSurface = Enum.SurfaceType.Smooth
Head.TopSurface = Enum.SurfaceType.Smooth
Head.Size = Vector3.new(1.799999833107, 1.7000000476837, 0.60000002384186)
Head.CFrame = CFrame.new(-24.563081741333, 10.949999809265, -8.3164186477661)
Head.Parent = Character

local LeftHand = Instance.new("Part")
LeftHand.Name = "LeftHand"
LeftHand.Anchored = false
LeftHand.BottomSurface = Enum.SurfaceType.Smooth
LeftHand.TopSurface = Enum.SurfaceType.Smooth
LeftHand.Size = Vector3.new(0.59999990463257, 0.60000002384186, 0.60000002384186)
LeftHand.CFrame = CFrame.new(-25.963079452515, 6.8000001907349, -8.3164186477661)
LeftHand.Parent = Character

local RightFoot = Instance.new("Part")
RightFoot.Name = "RightFoot"
RightFoot.Anchored = false
RightFoot.BottomSurface = Enum.SurfaceType.Smooth
RightFoot.TopSurface = Enum.SurfaceType.Smooth
RightFoot.Size = Vector3.new(0.59999990463257, 1, 2)
RightFoot.CFrame = CFrame.new(-23.763080596924, 3.5999999046326, -9.0164184570313)
RightFoot.Parent = Character

local LeftLowerArm = Instance.new("Part")
LeftLowerArm.Name = "LeftLowerArm"
LeftLowerArm.Anchored = false
LeftLowerArm.BottomSurface = Enum.SurfaceType.Smooth
LeftLowerArm.TopSurface = Enum.SurfaceType.Smooth
LeftLowerArm.Size = Vector3.new(0.59999990463257, 1.5, 0.60000002384186)
LeftLowerArm.CFrame = CFrame.new(-25.963079452515, 7.8500003814697, -8.3164186477661)
LeftLowerArm.Parent = Character

local LeftWrist = Instance.new("Weld")
LeftWrist.Name = "LeftWrist"
LeftWrist.C1 = CFrame.new(0, -0.80000019073486, 0)
LeftWrist.C0 = CFrame.new(0, 0.25, 0)
LeftWrist.Parent = LeftLowerArm

local LeftUpperArm = Instance.new("Part")
LeftUpperArm.Name = "LeftUpperArm"
LeftUpperArm.Anchored = false
LeftUpperArm.BottomSurface = Enum.SurfaceType.Smooth
LeftUpperArm.TopSurface = Enum.SurfaceType.Smooth
LeftUpperArm.Size = Vector3.new(0.59999990463257, 1.5, 0.60000002384186)
LeftUpperArm.CFrame = CFrame.new(-25.963079452515, 9.3500003814697, -8.3164186477661)
LeftUpperArm.Parent = Character

local LeftElbow = Instance.new("Weld")
LeftElbow.Name = "LeftElbow"
LeftElbow.C1 = CFrame.new(0, -0.80000019073486, 0)
LeftElbow.C0 = CFrame.new(0, 0.69999980926514, 0)
LeftElbow.Parent = LeftUpperArm

local LeftUpperLeg = Instance.new("Part")
LeftUpperLeg.Name = "LeftUpperLeg"
LeftUpperLeg.Anchored = false
LeftUpperLeg.BottomSurface = Enum.SurfaceType.Smooth
LeftUpperLeg.TopSurface = Enum.SurfaceType.Smooth
LeftUpperLeg.Size = Vector3.new(0.59999990463257, 1.5, 0.60000002384186)
LeftUpperLeg.CFrame = CFrame.new(-25.363080978394, 6.3499999046326, -8.3164186477661)
LeftUpperLeg.Parent = Character

local LeftShin = Instance.new("Weld")
LeftShin.Name = "LeftShin"
LeftShin.C1 = CFrame.new(0, -0.80000019073486, 0)
LeftShin.C0 = CFrame.new(0, 0.69999980926514, 0)
LeftShin.Parent = LeftUpperLeg

local RightUpperArm = Instance.new("Part")
RightUpperArm.Name = "RightUpperArm"
RightUpperArm.Anchored = false
RightUpperArm.BottomSurface = Enum.SurfaceType.Smooth
RightUpperArm.TopSurface = Enum.SurfaceType.Smooth
RightUpperArm.Size = Vector3.new(0.59999990463257, 1.5, 0.60000002384186)
RightUpperArm.CFrame = CFrame.new(-23.163080215454, 9.3500003814697, -8.3164186477661)
RightUpperArm.Parent = Character

local RightElbow = Instance.new("Weld")
RightElbow.Name = "RightElbow"
RightElbow.C1 = CFrame.new(0, -0.80000019073486, 0)
RightElbow.C0 = CFrame.new(0, 0.69999980926514, 0)
RightElbow.Parent = RightUpperArm

local LeftLowerLeg = Instance.new("Part")
LeftLowerLeg.Name = "LeftLowerLeg"
LeftLowerLeg.Anchored = false
LeftLowerLeg.BottomSurface = Enum.SurfaceType.Smooth
LeftLowerLeg.TopSurface = Enum.SurfaceType.Smooth
LeftLowerLeg.Size = Vector3.new(0.59999990463257, 1.5, 0.60000002384186)
LeftLowerLeg.CFrame = CFrame.new(-25.363080978394, 4.8499999046326, -8.3164186477661)
LeftLowerLeg.Parent = Character

local LeftAnkle = Instance.new("Weld")
LeftAnkle.Name = "LeftAnkle"
LeftAnkle.C1 = CFrame.new(0, -0.69999980926514, 0)
LeftAnkle.C0 = CFrame.new(0, 0.55000019073486, 0.69999980926514)
LeftAnkle.Parent = LeftLowerLeg

local RightLowerArm = Instance.new("Part")
RightLowerArm.Name = "RightLowerArm"
RightLowerArm.Anchored = false
RightLowerArm.BottomSurface = Enum.SurfaceType.Smooth
RightLowerArm.TopSurface = Enum.SurfaceType.Smooth
RightLowerArm.Size = Vector3.new(0.59999990463257, 1.5, 0.60000002384186)
RightLowerArm.CFrame = CFrame.new(-23.163080215454, 7.8500003814697, -8.3164186477661)
RightLowerArm.Parent = Character

local RightWrist = Instance.new("Weld")
RightWrist.Name = "RightWrist"
RightWrist.C1 = CFrame.new(0, -0.80000019073486, 0)
RightWrist.C0 = CFrame.new(0, 0.25, 0)
RightWrist.Parent = RightLowerArm

local LowerTorso = Instance.new("Part")
LowerTorso.Name = "LowerTorso"
LowerTorso.Anchored = false
LowerTorso.BottomSurface = Enum.SurfaceType.Smooth
LowerTorso.TopSurface = Enum.SurfaceType.Smooth
LowerTorso.Size = Vector3.new(2.1999998092651, 1.5, 0.60000002384186)
LowerTorso.CFrame = CFrame.new(-24.563081741333, 7.8499999046326, -8.3164186477661)
LowerTorso.Parent = Character

local Waist = Instance.new("Weld")
Waist.Name = "Waist"
Waist.C1 = CFrame.new(0, 0.70000028610229, 0)
Waist.C0 = CFrame.new(0, -0.80000019073486, 0)
Waist.Parent = LowerTorso

local LeftHip = Instance.new("Weld")
LeftHip.Name = "LeftHip"
LeftHip.C1 = CFrame.new(-0.79999923706055, -0.80000019073486, 0)
LeftHip.C0 = CFrame.new(0, 0.69999980926514, 0)
LeftHip.Parent = LowerTorso

local RightHip = Instance.new("Weld")
RightHip.Name = "RightHip"
RightHip.C1 = CFrame.new(0.79999923706055, -0.79999971389771, 0)
RightHip.C0 = CFrame.new(-1.9073486328125e-06, 0.70000028610229, 0)
RightHip.Parent = LowerTorso

local HumanoidRootPart = Instance.new("Part")
HumanoidRootPart.Name = "HumanoidRootPart"
HumanoidRootPart.Anchored = false
HumanoidRootPart.Transparency = 1
HumanoidRootPart.BottomSurface = Enum.SurfaceType.Smooth
HumanoidRootPart.TopSurface = Enum.SurfaceType.Smooth
HumanoidRootPart.Size = Vector3.new(1.5, 1.5, 1)
HumanoidRootPart.CFrame = CFrame.new(-24.563081741333, 7.8499999046326, -8.3164186477661)
HumanoidRootPart.Parent = Character

local Root = Instance.new("Weld")
Root.Name = "Root"
Root.C1 = CFrame.new(0, 0.50000047683716, 0)
Root.C0 = CFrame.new(0, 0.50000047683716, 0)
Root.Parent = HumanoidRootPart

RightAnkle.Part1 = RightLowerLeg
RightAnkle.Part0 = RightFoot

RightShin.Part1 = RightUpperLeg
RightShin.Part0 = RightLowerLeg

Neck.Part1 = UpperTorso
Neck.Part0 = Head

LeftShoulder.Part1 = UpperTorso
LeftShoulder.Part0 = LeftUpperArm

RightShoulder.Part1 = UpperTorso
RightShoulder.Part0 = RightUpperArm

LeftWrist.Part1 = LeftLowerArm
LeftWrist.Part0 = LeftHand

LeftElbow.Part1 = LeftUpperArm
LeftElbow.Part0 = LeftLowerArm

LeftShin.Part1 = LeftUpperLeg
LeftShin.Part0 = LeftLowerLeg

RightElbow.Part1 = RightUpperArm
RightElbow.Part0 = RightLowerArm

LeftAnkle.Part1 = LeftLowerLeg
LeftAnkle.Part0 = LeftFoot

RightWrist.Part1 = RightLowerArm
RightWrist.Part0 = RightHand

Waist.Part1 = LowerTorso
Waist.Part0 = UpperTorso

LeftHip.Part1 = LowerTorso
LeftHip.Part0 = LeftUpperLeg

RightHip.Part1 = LowerTorso
RightHip.Part0 = RightUpperLeg

Root.Part1 = HumanoidRootPart
Root.Part0 = LowerTorso

Character.Parent = script

Character.PrimaryPart = HumanoidRootPart

Character:SetPrimaryPartCFrame(owner.Character.PrimaryPart.CFrame)

owner.Character = Character

Instance.new("Humanoid", Character).HipHeight = 4

local AnimDefaults = {
lAnkle = LeftAnkle.C0,
rAnkle = RightAnkle.C0,
lShin = LeftShin.C0,
rShin = RightShin.C0,
lHip = LeftHip.C0,
rHip = RightHip.C0,
Root = Root.C0,
Waist = Waist.C0,
Neck = Neck.C0,
rShoulder = RightShoulder.C0,
lShoulder = LeftShoulder.C0,
lElbow = LeftElbow.C0,
rElbow = RightElbow.C0,
lWrist = LeftWrist.C0,
rWrist = RightWrist.C0
}



game:GetService("RunService").Heartbeat:Connect(function()
if HumanoidRootPart.Velocity.X ~= 0 or HumanoidRootPart.Velocity.Z ~= 0 and HumanoidRootPart.Velocity.Y == 0 then
Waist.C0 = AnimDefaults.Waist * CFrame.Angles(math.rad(15),0,0)
LeftShoulder.C0 = AnimDefaults.lShoulder * CFrame.Angles(math.rad(math.sin(tick() * 5) * 30),0,0)
LeftElbow.C0 = AnimDefaults.lElbow * CFrame.Angles(math.rad(-25),0,0)
RightShoulder.C0 = AnimDefaults.rShoulder * CFrame.Angles(-math.rad(math.sin(tick() * 5) * 30),0,0)
RightElbow.C0 = AnimDefaults.rElbow * CFrame.Angles(math.rad(-25),0,0)
LeftHip.C0 = AnimDefaults.lHip * CFrame.Angles(-math.rad(math.sin(tick() * 5) * 30),0,0)
LeftShin.C0 = AnimDefaults.lShin* CFrame.Angles(math.rad(30 + math.sin(tick() * 2.5) * 15),0,0)
RightHip.C0 = AnimDefaults.rHip * CFrame.Angles(math.rad(math.sin(tick() * 5) * 30),0,0)
RightShin.C0 = AnimDefaults.rShin* CFrame.Angles(math.rad(30 + math.sin(tick() * 2.5) * 15),0,0)
end
end)

game:GetService("RunService").Heartbeat:Connect(function()
if HumanoidRootPart.Velocity.X == 0 or HumanoidRootPart.Velocity.Z == 0 and HumanoidRootPart.Velocity.Y == 0 then
Waist.C0 = AnimDefaults.Waist * CFrame.Angles(math.rad(15),0,0)
LeftShoulder.C0 = AnimDefaults.lShoulder * CFrame.Angles(math.rad(math.sin(tick() * 5) * 30),0,0)
LeftElbow.C0 = AnimDefaults.lElbow * CFrame.Angles(math.rad(-25),0,0)
RightShoulder.C0 = AnimDefaults.rShoulder * CFrame.Angles(-math.rad(math.sin(tick() * 5) * 30),0,0)
RightElbow.C0 = AnimDefaults.rElbow * CFrame.Angles(math.rad(-25),0,0)
LeftHip.C0 = AnimDefaults.lHip * CFrame.Angles(-math.rad(math.sin(tick() * 5) * 30),0,0)
LeftShin.C0 = AnimDefaults.lShin* CFrame.Angles(math.rad(30 + math.sin(tick() * 2.5) * 15),0,0)
RightHip.C0 = AnimDefaults.rHip * CFrame.Angles(math.rad(math.sin(tick() * 5) * 30),0,0)
RightShin.C0 = AnimDefaults.rShin* CFrame.Angles(math.rad(30 + math.sin(tick() * 2.5) * 15),0,0)
end
end)

