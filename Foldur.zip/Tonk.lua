local hat = Instance.new("Part", script)

hat.Anchored = true
hat.Locked = true
hat.CanCollide = false
hat.Size = Vector3.new(2,2,2)

local specialmesh = Instance.new("SpecialMesh", hat)
specialmesh.MeshType = 'FileMesh'
specialmesh.MeshId = 'rbxassetid://4850001372'
specialmesh.TextureId = 'rbxassetid://4849997982'

local rem = Instance.new("RemoteEvent", owner.PlayerGui)

NLS("local rem = owner.PlayerGui.RemoteEvent local mouse = owner:GetMouse() mouse.Button1Down:Connect(function() rem:FireServer(mouse.Hit.Position, true)  end)  while wait(1/30) do rem:FireServer(mouse.Hit.Position) end", owner.PlayerGui)



rem.OnServerEvent:Connect(function(plr, pos, shoot)
hat.Position = hat.Position:Lerp(owner.Character.HumanoidRootPart.CFrame * CFrame.new(-3,-2.25,0).Position,.1)
hat.CFrame = CFrame.new(hat.Position, pos)

if shoot then
local locator = Instance.new("Part", script)
locator.Locked = true
locator.Anchored = true
locator.Transparency = 1
locator.CanCollide = false
locator.Position = pos

local boom = Instance.new("Explosion", script)
boom.Position = pos
boom.BlastRadius = 1

local rope = Instance.new("RopeConstraint", locator)
rope.Attachment1 = Instance.new("Attachment", locator)
local attpos = Instance.new("Attachment", hat)
attpos.Position = Vector3.new(0,.7,-.75)
rope.Attachment0 = attpos
rope.Visible = true
rope.Color = BrickColor.new("New Yeller")
rope.Thickness = .15

wait(.25)
locator:Destroy()
rope:Destroy()

end
end)