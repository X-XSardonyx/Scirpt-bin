local seed = math.random()
local w = 30
local h = 100
local grid = 100
local offset = CFrame.new(Vector3.new(0,50,-200))

script.Parent = workspace

local hint = Instance.new("Hint", script)
hint.Text = [[seed: ]]..seed..' is loading...'

game.Players.X_XSardonyx.Chatted:Connect(function(msg)

if string.lower(msg) == '-clr' then
script:Destroy()
workspace.Terrain:Clear()
end

end)

for z = 1,grid do
task.wait()
for x = 1,grid do
local block = Instance.new("Part", script)
block.Size = Vector3.new(4,4,4)
block.Anchored = true
block.Material = 'Grass'
block.Color = Color3.fromRGB(100,255,100)

local y = math.sin(math.noise(seed,x/w,z/w)) * h

block.CFrame = offset * CFrame.new(-x*4,y,-z*4)
  

local MAG = 300

block.Size = Vector3.new(block.Size.X,MAG,block.Size.Z)
block.Position = block.Position - Vector3.new(0,block.Size.Y/2,0)
local grass = block:Clone()
grass.CFrame = grass.CFrame * CFrame.new(0,block.Size.Y/2,0)
grass.Material = 'Grass'
grass.Size = Vector3.new(grass.Size.X + .01,4,grass.Size.Z + .01)
grass.Color = Color3.fromRGB(100,255,100)
grass.Parent = block

local region = Region3.new(block.Position - block.Size/2 ,block.Position + block.Size/2) 
region = region:ExpandToGrid(4) 

workspace.Terrain:FillRegion(region, 4, Enum.Material.Slate)

local region = Region3.new(grass.Position - grass.Size/2 ,grass.Position + grass.Size/2) 
region = region:ExpandToGrid(4) 


if y > 25 then
workspace.Terrain:FillRegion(region, 4, Enum.Material.Snow)
elseif y < 25 and y> 10 then
workspace.Terrain:FillRegion(region, 4, Enum.Material.Grass)
elseif y < 10 and y >-20 then
workspace.Terrain:FillRegion(region, 4, Enum.Material.Sand)
elseif y < -20 then
workspace.Terrain:FillRegion(region, 4, Enum.Material.Slate)
end
block:Destroy()

end
end

local Resolution = 10
local NumWorm = 1
worms = 5
for i = 1,5 do
	NumWorm = NumWorm+1
	local sX = math.noise(NumWorm/Resolution+.1,seed)
	local sY = math.noise(NumWorm/Resolution+sX+.1,seed)
	local sZ = math.noise(NumWorm/Resolution+sY+.1,seed)
	local WormCF = offset * CFrame.new(offset.Position.X/2,0,offset.Position.Z/2) * CFrame.new(sX*500,sY*500,sZ*500)
	print("Worm "..NumWorm.." spawning at "..WormCF.X..", "..WormCF.Y..", "..WormCF.Z)
	local Dist = (math.noise(NumWorm/Resolution+WormCF.p.magnitude,seed)+.5)*500

	for i = 1,Dist do
		task.wait()
		local X,Y,Z = math.noise(WormCF.X/Resolution+.1,seed),math.noise(WormCF.Y/Resolution+.1,seed),math.noise(WormCF.Z/Resolution+.1,seed)
		WormCF = WormCF*CFrame.Angles(X*2,Y*2,Z*2)*CFrame.new(0,0,-Resolution)
		local Part = Instance.new("Part", script)
		Part.Anchored = true
		Part.CFrame = CFrame.new(WormCF.p)
		Part.Size = Vector3.new(Resolution,Resolution,Resolution)
workspace.Terrain:FillBall(Part.Position, Resolution, Enum.Material.Air)
Part:Destroy()
	end
end

hint.Text = 'Loading Complete. User X_XSardonyx must say -clr to delete the terrain.'
wait(10)
hint:Destroy()