local tool = Instance.new("Tool", owner.Character)
tool.Name = ' '
local handle = Instance.new("Part", tool)
handle.Size = Vector3.new(.75,.75,.75)
handle.Material = 'Glass'
handle.Transparency = .9999
handle.CastShadow = false
handle.Name = 'Handle'
handle.Massless = true
local orbit = Instance.new("Part")
orbit.Size = Vector3.new(1.5,1.5,1.5)
orbit.CanCollide = false
orbit.Material = 'Glass'
orbit.Transparency = .0111
orbit.BrickColor = BrickColor.new("Really black")
orbit.Massless = true

local mesh = Instance.new("SpecialMesh", orbit)
mesh.Scale = Vector3.new(-1.5,1.5,1.5)
mesh.MeshType = 'FileMesh'

local weld = Instance.new("Weld", orbit)
weld.Part1 = handle
weld.Part0 = orbit

tool.Equipped:Connect(function()
orbit.Parent = script

end)

tool.Unequipped:Connect(function()
orbit.Parent = nil
end)


game:GetService("RunService").Heartbeat:Connect(function()
tool.Grip = tool.Grip * CFrame.Angles(math.rad(1),math.rad(1),math.rad(1))
end)


handle.Touched:Connect(function(part)

if not part:IsDescendantOf(owner.Character) and part.Parent ~= workspace then
part:BreakJoints()
game:GetService("TweenService"):Create(part, TweenInfo.new(1), {Transparency = 1, Size = Vector3.new(0,0,0), CFrame = part.CFrame * tool.Grip}):Play()
game:GetService("Debris"):AddItem(part, 1)
end

end)