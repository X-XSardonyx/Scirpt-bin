local size = 800
local terrain = workspace.Terrain
offset = Vector3.new(10000,7000,10000)

--{material, frequency, size}

local sky = Instance.new("Part", script)
sky.Anchored = true
sky.CFrame = CFrame.new(offset) * CFrame.Angles(math.rad(90),0,0)

local mesh = Instance.new("SpecialMesh", sky)
mesh.MeshId = 'rbxassetid://'..1185246
mesh.MeshType = 'FileMesh'
mesh.TextureId = 'rbxassetid://'..7123762364
mesh.Scale = Vector3.new(-5000,5000,5000)

ores = {
{'Water', 200, 25},
{'Air', 30, 50},
{'Rock', 250, 50},
{'CrackedLava', 10, 50}
}

model = Instance.new("Model", script)

function part(shape,anchored, transparency, size, cframe, color, locked, cancollide,material, name)

local prt = Instance.new("Part", model)
prt.Size = size
prt.Anchored = anchored
prt.CanCollide = cancollide
prt.Locked = locked
prt.Shape = shape
prt.Transparency = transparency
prt.Size = size
prt.Color = color
prt.CFrame = cframe
prt.Material = material
prt.Name = name
end
 
part("Cylinder",true,0,Vector3.new(1,18,18),CFrame.new(0,0.5,-30) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(-90)),Color3.new(0.97254902124405,0.97254902124405,0.97254902124405),false,true,"Cobblestone","Part")
part("Cylinder",true,0,Vector3.new(0.10000002384186,10,10),CFrame.new(0,2.0499999523163,-30) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(-90)),Color3.new(0.97254902124405,0.97254902124405,0.97254902124405),false,true,"Neon","Pad")
part("Ball",true,0,Vector3.new(10,10,10),CFrame.new(0,9.1000003814697,-30) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(0)),Color3.new(0.48627451062202,0.61176472902298,0.419607847929),false,false,"Sand","PLAN")
part("Cylinder",true,0,Vector3.new(1,14,14),CFrame.new(0,1.5,-30) * CFrame.Angles(math.rad(0),math.rad(0),math.rad(-90)),Color3.new(0.38823530077934,0.37254902720451,0.38431373238564),false,true,"Cobblestone","Part")

Planet = model.PLAN
Pad = model.Pad

game:GetService("RunService").Heartbeat:Connect(function()

Planet.CFrame = Planet.CFrame * CFrame.Angles(0,math.rad(2),0)

end)

Pad.Touched:Connect(function(part)
if part.Parent:FindFirstChildOfClass("Humanoid") then
if game:GetService("Players"):GetPlayerFromCharacter(part.Parent) then

plr = game:GetService("Players"):GetPlayerFromCharacter(part.Parent)

plr.Character:SetPrimaryPartCFrame(CFrame.new(offset+Vector3.new(0,size+10,0)))

end
end
end)

terrain:FillBall(offset,size,'Grass')
wait(5)
terrain:FillBall(offset,size-50,'Sand')

for i,v in pairs(ores) do
for i = 1,v[2] do
pos = offset + Vector3.new(math.random(-size/1.5,size/1.5),math.random(-size/1.5,size/1.5),math.random(-size/1.5,size/1.5))

terrain:FillBall(pos,v[3],v[1])

end
end


owner.Chatted:Connect(function(msg)

msg = string.lower(msg)

if msg == '-clearterrain' then

terrain:FillBall(offset, 800, 'Air')

end

end)