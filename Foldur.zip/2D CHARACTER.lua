local parts = {}
local board
for i,v in pairs(workspace:GetDescendants()) do
if v:IsA("BoolValue") then
table.insert(parts, v)
end
end

local colors = {

{BrickColor.new("Really red"), BrickColor.new("Deep orange"), BrickColor.new("New Yeller")},
{BrickColor.new("Lime green"), BrickColor.new("Cyan"), BrickColor.new("Really blue")},
{BrickColor.new("Magenta"), BrickColor.new("Pink"), BrickColor.new("Black")}

}

if parts["SUSSY2DLOADED"] then

board = parts["SUSSY2DLOADED"].Parent

else

board = Instance.new("Part", script)
board.Size = Vector3.new(10,10,0)
board.Anchored = true
board.CanCollide = false
board.CFrame = CFrame.new(30,6,20)
board.Locked = true
board.BrickColor = BrickColor.new("Pearl")

Instance.new("SurfaceGui", board)

local val = Instance.new("BoolValue", board)
val.Name = 'SUSSY2DLOADED'
val.Value = true

end

local Customization = Instance.new("ScreenGui", owner.PlayerGui)
local frame = Instance.new("Frame", Customization)
frame.Size = UDim2.new(.25,0,.5,0)
frame.Position = UDim2.new(.75,0,0,0)
frame.BorderSizePixel = 0
frame.BackgroundColor3 = BrickColor.new("Institutional white").Color


local Character = Instance.new("Frame", board.SurfaceGui)
Character.Size = UDim2.new(.1,0,.1,0)
Character.BorderSizePixel = 0
Character.Position = UDim2.new(.45,0,.45,0)
Character.BackgroundColor3 = BrickColor.Random().Color

local tag = Instance.new("TextBox", board.SurfaceGui)
tag.BackgroundTransparency = 1
tag.TextScaled = true
tag.Size = UDim2.new(.2,0,.25,0)
tag.Text = owner.Name
tag.Font = 'Code'

for y = 1,3 do
for x = 1,3 do
local button = Instance.new("TextButton", frame)
button.Size = UDim2.new(1 / 3,0,1/3,0)
button.BorderSizePixel = 0
button.Position = UDim2.new(1 / 3 * y - 1/3,0,1 / 3 * x - 1/3,0)
button.BackgroundColor3 = colors[x][y].Color
button.Text = ''
button.MouseButton1Click:Connect(function()
Character.BackgroundColor3 = button.BackgroundColor3
end)
end
end

local rem = Instance.new("RemoteEvent", owner.Backpack)
rem.Name = 'MOVEMENT'

NLS([[

local rem = script.Parent
local ui = game:GetService("UserInputService")
local cam = workspace.CurrentCamera

ui.InputBegan:Connect(function(input)
rem:FireServer(input.KeyCode, true)
end)
ui.InputEnded:Connect(function(input)
rem:FireServer(input.KeyCode, false)
end)
ui.InputChanged:Connect(function(input)
rem:FireServer(input.KeyCode, true)
end)

game:GetService("RunService").RenderStepped:Connect(function()
cam.CFrame = CFrame.new(CFrame.new(30,6,20) * CFrame.new(0,0,-15).Position, CFrame.new(30,6,20).Position)
end)

]], rem)

local wdown = false
local adown = false
local sdown = false
local ddown = false

rem.OnServerEvent:Connect(function(plr, key, Down)
if key == Enum.KeyCode.W and Down == true then
wdown = true
elseif key == Enum.KeyCode.A and Down == true then
adown = true
elseif key == Enum.KeyCode.S and Down == true then
sdown = true
elseif key == Enum.KeyCode.D and Down == true then
ddown = true
elseif key == Enum.KeyCode.W and Down == false then
wdown = false
elseif key == Enum.KeyCode.A and Down == false then
adown = false
elseif key == Enum.KeyCode.S and Down == false then
sdown = false
elseif key == Enum.KeyCode.D and Down == false then
ddown = false
end
end)


game:GetService("RunService").Heartbeat:Connect(function()
if wdown == true then
Character.Position = Character.Position + UDim2.new(0,0,0,-10)
elseif adown == true then
Character.Position = Character.Position + UDim2.new(0,-10,0,0)
elseif sdown == true then
Character.Position = Character.Position + UDim2.new(0,0,0,10)
elseif ddown == true then
Character.Position = Character.Position + UDim2.new(0,10,0,0)
end

local X = math.clamp(Character.Position.X.Offset,0,board.SurfaceGui.CanvasSize.X - (board.SurfaceGui.CanvasSize.X / 10))
local Y = math.clamp(Character.Position.Y.Offset,0,board.SurfaceGui.CanvasSize.Y - (board.SurfaceGui.CanvasSize.Y / 5))
Character.Position = UDim2.new(0,X,0,Y)

tag.Position = Character.Position - UDim2.new(.125 / 2,0,0,0)

end)

owner.Character.Parent = nil