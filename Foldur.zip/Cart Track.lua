local size = Vector3.new(15,1,25)
local spawn = owner.Character.HumanoidRootPart.CFrame * CFrame.new(0,-2.5,0)
lastpos = spawn
tracks = {}

for i = 1,100 do
local part = Instance.new("SpawnLocation", script)
part.Anchored = true
part.Locked = true
part.Enabled = false
part.Size = size + Vector3.new(0,0,.5)
part.BrickColor = BrickColor.new("Black")
part.Material = 'Concrete'

part.CFrame = lastpos * CFrame.new(0,0,-size.Z/2) * CFrame.Angles(0,math.rad(math.random(-15,15)),0) * CFrame.new(0,0,-size.Z/2)
lastpos = part.CFrame
table.insert(tracks, part.CFrame * CFrame.new(0,1,0))

border1 = Instance.new("SpawnLocation", part)
border1.Enabled = false
border1.Size = Vector3.new(1,2,part.Size.Z)
border1.Anchored = true
border1.CFrame = part.CFrame * CFrame.new(size.X/2-.5,1.5,0)
border1.BrickColor = BrickColor.new("Ghost Grey")
border1.Material = 'Concrete'

local border2 = border1:Clone()
border2.Parent = part
border2.CFrame = part.CFrame * CFrame.new(-size.X/2-.5,1.5,0)

task.wait()
end

local cart = Instance.new("Seat", script)
cart.Anchored = true
cart.Size = Vector3.new(2,1,4)
cart.CanCollide = false
cart.CFrame = spawn
cart.Transparency = 1

local carpart = Instance.new("Part", cart)

carpart.CanCollide = false

local weld = Instance.new("Weld", carpart)
weld.Part1 = carpart
weld.Part0 = cart
weld.C0 = CFrame.Angles(0,math.rad(180),0)

mesh = Instance.new("SpecialMesh", carpart)
mesh.MeshId = 'rbxassetid://430711151'
mesh.TextureId = 'rbxassetid://430711155'
mesh.MeshType = 'FileMesh'
mesh.Scale = Vector3.new(5,5,5)
mesh.Offset = Vector3.new(0,.5,0)

local bbg = Instance.new("BillboardGui", script)
bbg.Adornee = cart
bbg.StudsOffset = Vector3.new(0,3,0)
bbg.Size = UDim2.fromScale(5,2.5)

local frame = Instance.new("TextLabel", bbg)
frame.Size = UDim2.new(1,0,1,0)
frame.BackgroundTransparency = 1
frame.Text = [[SIT
↓]]
frame.TextScaled = true
frame.TextColor = BrickColor.new("Institutional white")
frame.Font = 'Fantasy'

repeat task.wait() bbg.StudsOffset = Vector3.new(0,5,0) + Vector3.new(0,math.sin(tick()*5),0) until cart.Occupant

local occu = cart.Occupant

bbg:Destroy()

color = false

for i = 1,size.X do
local line = Instance.new("SpawnLocation", script)
line.Size = Vector3.new(1,1,1)
line.CFrame = lastpos * CFrame.new(-size.X/2,0.1,0) * CFrame.new(i-1,0,0)
line.Anchored = true
line.Enabled = false
line.Material = 'SmoothPlastic'

color = not color

if color then
line.BrickColor = BrickColor.new("Really black")
else
line.BrickColor = BrickColor.new("Institutional white")
end

end

for i,v in pairs(tracks) do
if cart.Occupant then

game:GetService("TweenService"):Create(cart, TweenInfo.new(.25, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {CFrame = v}):Play()

wait(.25)

else

cart:Sit(occu)

end
end