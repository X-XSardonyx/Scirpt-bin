local tool = Instance.new("Tool", game.Players.X_XSardonyx.Backpack)
tool.Name = 'EXPLOSION'

local DB = false

local handle = Instance.new("Part", tool)
handle.Name = 'Handle'
handle.Size = Vector3.new(1,6,1)
local mesh = Instance.new("SpecialMesh", handle)
mesh.MeshType = Enum.MeshType.FileMesh
mesh.Scale = Vector3.new(.035,.035,.035)
mesh.MeshId = "rbxassetid://6966030497"
mesh.Offset = Vector3.new(0,1.8,0)
mesh.TextureId = 'rbxassetid://636922344'


local sounds = {Chant = 'rbxassetid://6893647090',Explode = 'rbxassetid://6397383389'}

tool.Activated:Connect(function()
if DB == false then
DB = true

local folder = Instance.new("BoolValue", Workspace)

local hrp = tool.Parent.HumanoidRootPart
local hum = tool.Parent.Humanoid
local speed = hum.WalkSpeed
local jpower = hum.JumpPower

local FF = Instance.new("ForceField", hum.Parent)
FF.Visible = false

hrp.Anchored = true

hum.JumpPower = 0
hum.WalkSpeed = 0

local cf = tool.Parent.HumanoidRootPart.CFrame * CFrame.new(0,0,-30)
local ball1 = Instance.new("Part", folder)
ball1.Locked = true
ball1.Size = Vector3.new(5,5,5)
ball1.CFrame = cf * CFrame.new(0,20,0)
ball1.Shape = 'Ball'
ball1.Anchored = true
ball1.CanCollide = false
ball1.Material = 'Neon'
ball1.BrickColor = BrickColor.new("Maroon")

local Sound = Instance.new("Sound", ball1)
Sound.SoundId = sounds.Chant
Sound.Volume = 10
Sound:Play()
Sound.Looped = false
Sound.MaxDistance = 1000000

local beampart1 = Instance.new("Part", folder)
beampart1.Locked = true
beampart1.Anchored = true
beampart1.CanCollide = false
beampart1.Size = Vector3.new(25,0,0)
beampart1.CFrame = cf * CFrame.new(0,7,0)
beampart1.Shape = 'Cylinder'
beampart1.BrickColor = BrickColor.new("Maroon")
beampart1.Material = 'Neon'
beampart1.Orientation = beampart1.Orientation + Vector3.new(0,0,90)

for i = 1,10 do
beampart1.Size = beampart1.Size:Lerp(Vector3.new(20,2,2), .1)
wait()
end

local beams = {}

for i = 1,15 do
local beameffect1 = Instance.new("Part", folder)
beameffect1.Locked = true
beameffect1.Shape = 'Cylinder'
beameffect1.Anchored = true
beameffect1.CFrame = beampart1.CFrame * CFrame.new(math.random(-10,10),0,0)
beameffect1.BrickColor = BrickColor.new("Maroon")
beameffect1.CanCollide = false
beameffect1.Material = 'Neon'
beameffect1.Size = Vector3.new(0,1,1)

table.insert(beams, beameffect1)

for i = 1,10 do
beameffect1.Size = beameffect1.Size:Lerp(Vector3.new(0,math.random(5,50),math.random(5,50)), .1)
wait()
end

wait(.5)


end

wait(.1)
wait()


for i = 1,15 do
for i,v in pairs(beams) do
v.Size = v.Size:Lerp(Vector3.new(0,0,0), .5)
beampart1.Size = beampart1.Size:Lerp(Vector3.new(0,20,0), .2)
end
wait()
end

wait(.1)

local boom = Instance.new("Explosion", Workspace)
boom.Position = cf.Position
boom.BlastRadius = 15
boom.Visible = false

local Sound3 = Instance.new("Sound", Workspace)
Sound3.SoundId = sounds.Explode
Sound3.TimePosition = .2
Sound3.Volume = 10
Sound3:Play() 
Sound3.Looped = false
Sound3.MaxDistance = 1000000

local ring1 = Instance.new("Part", folder)
ring1.Locked = true
ring1.Anchored = true
ring1.CanCollide = false
ring1.BrickColor = BrickColor.new("Maroon")
ring1.Material = 'Neon'
ring1.Size = Vector3.new(1,25,1)
ring1.CFrame = cf
local ringmesh = Instance.new("SpecialMesh", ring1)
ringmesh.MeshType = Enum.MeshType.FileMesh
ringmesh.Scale = Vector3.new(.1,.1,.1)
ringmesh.MeshId = 'rbxassetid://4558726590'

local ring2 = Instance.new("Part", folder)
ring2.Locked = true
ring2.Anchored = true
ring2.CanCollide = false
ring2.BrickColor = BrickColor.new("Maroon")
ring2.Material = 'Neon'
ring2.Size = Vector3.new(1,25,1)
ring2.CFrame = cf
local ringmesh2 = Instance.new("SpecialMesh", ring2)
ringmesh2.MeshType = Enum.MeshType.FileMesh
ringmesh2.Scale = Vector3.new(.1,.1,.1)
ringmesh2.MeshId = 'rbxassetid://471124075'

beampart1:Destroy()
ball1:Destroy()

for i = 1,40 do
ringmesh.Scale = ringmesh.Scale:Lerp(Vector3.new(1,2,1), .1)
ring1.Transparency = ring1.Transparency + .05
ringmesh2.Scale = ringmesh2.Scale:Lerp(Vector3.new(2,2,2), .1)
ring2.Transparency = ring2.Transparency + .05
local boomeffect = Instance.new("Part", folder)
boomeffect.Size = Vector3.new(math.random(1,20), 20,20)
boomeffect.Anchored = true
boomeffect.CanCollide = false
boomeffect.BrickColor = BrickColor.new("Maroon")
boomeffect.Shape = 'Ball'
boomeffect.Locked = true
boomeffect.Material = 'Neon'
boomeffect.Transparency = .75
boomeffect.CFrame = cf * CFrame.new(math.random(-15,15),math.random(-15,15),math.random(-15,15))
game:GetService("Debris"):AddItem(boomeffect, .2)
wait(.1)
end

for i,v in pairs(beams) do
v:Destroy()
end


hum.JumpPower = jpower
hum.WalkSpeed = speed
FF:Destroy()

ring1:Destroy()
ring2:Destroy()

DB = false
folder:Destroy()
hrp.Anchored = false
end
end)

tool.Equipped:Connect(function()

local Sound3 = Instance.new("Sound", Handle)
Sound3.SoundId = 'rbxassetid://762570073'
Sound3.Volume = 10
Sound3:Play() 
Sound3.Looped = false
Sound3.MaxDistance = 1000000

end)


while wait() do

local ring2 = Instance.new("Part", handle)
ring2.Anchored = true
ring2.CanCollide = false
ring2.BrickColor = BrickColor.new("Persimmon")
ring2.Material = 'Neon'
ring2.Size = Vector3.new(1,1,1)
ring2.Locked = true

ring2.CFrame = handle.CFrame * CFrame.new(0,-3,0)

ring2.Orientation = Vector3.new(0,0,0)

local ringmesh2 = Instance.new("SpecialMesh", ring2)
ringmesh2.MeshType = Enum.MeshType.FileMesh
ringmesh2.Scale = Vector3.new(.1,.1,.1)
ringmesh2.MeshId = 'rbxassetid://2855433036'

for i = 1,10 do

ringmesh2.Scale = ringmesh2.Scale:Lerp(Vector3.new(1,1,1), .1)
ring2.Transparency = ring2.Transparency + .1

wait()

end

ring2:Destroy()


end