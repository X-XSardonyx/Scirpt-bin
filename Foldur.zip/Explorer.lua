local part = Instance.new("Part", script)
part.Size = Vector3.new(10,7.5,0)
part.Anchored = true
part.CanCollide = true
part.CanTouch = false
part.Locked = true
part.Transparency = 1
part.CFrame = owner.Character.PrimaryPart.CFrame * CFrame.new(0,2,-10) * CFrame.Angles(0,math.rad(180),0)

local gui = Instance.new("SurfaceGui", part)

gui.Adornee = part

local Frame = Instance.new("ScrollingFrame", gui)
Frame.BackgroundTransparency = .5
Frame.BackgroundColor = BrickColor.new("Really black")
Frame.BorderSizePixel = 0
Frame.Size = UDim2.new(1,0,1,0)
Frame.CanvasSize = UDim2.new(0,0,5,0)
Frame.ScrollingDirection = Enum.ScrollingDirection.Y

currentitem = workspace
Max = game

function refresh()
Frame:ClearAllChildren()

local parent = Instance.new("TextButton", Frame)
parent.Size = UDim2.new(1,0,0,50)
parent.Text = 'Parent'
parent.TextScaled = true
parent.BorderSizePixel = 0

currentparent = currentitem.Parent

parent.MouseButton1Click:Connect(function()
if currentitem.Parent ~= Max then

currentitem = currentparent
refresh()
end
end)

for i,item in pairs(currentitem:GetChildren()) do

if i <= 59 then

local button = Instance.new("TextButton", Frame)
button.Size = UDim2.new(1,0,0,50)
button.Text = item.Name..'  '..item.ClassName
button.TextScaled = true
button.BorderSizePixel = 0
button.Position = UDim2.new(0,0,0,i*50)
button.BackgroundColor3 = Color3.fromHSV(i/59,1,1)
button.MouseButton1Click:Connect(function()


currentitem = item
refresh()
end)
button.MouseButton2Click:Connect(function()
item:Destroy()
refresh()
end)
end
end

end
refresh()