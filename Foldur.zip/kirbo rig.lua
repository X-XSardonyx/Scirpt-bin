local StarterCharacter = Instance.new("Model", script)
StarterCharacter.Name = "X_X"
local Torso = Instance.new("Part")
Torso.Name = "Torso"
Torso.BottomSurface = Enum.SurfaceType.Smooth
Torso.CanCollide = false
Torso.TopSurface = Enum.SurfaceType.Smooth
Torso.Color = Color3.fromRGB(232, 186, 200)
Torso.Size = Vector3.new(2, 2, 2)
Torso.Parent = StarterCharacter

HumanoidRootPart = Torso:Clone()
HumanoidRootPart.Parent = StarterCharacter
HumanoidRootPart.Transparency = 1
HumanoidRootPart.Name = 'HumanoidRootPart'

local LeftShoulder = Instance.new("Motor6D")
LeftShoulder.Name = "Left Shoulder"
LeftShoulder.C1 = CFrame.new(-1, 0.40000009536743, 0)
LeftShoulder.C0 = CFrame.new(0, 0.40000009536743, 0)
LeftShoulder.Parent = Torso
local RightShoulder = Instance.new("Motor6D")
RightShoulder.Name = "Right Shoulder"
RightShoulder.C1 = CFrame.new(1, 0.40000009536743, 0)
RightShoulder.C0 = CFrame.new(0, 0.40000009536743, 0)
RightShoulder.Parent = Torso
local RightHip = Instance.new("Motor6D")
RightHip.Name = "Right Hip"
RightHip.C1 = CFrame.new(0.5, -0.70000004768372, 0)
RightHip.C0 = CFrame.new(0, 0.25, 0)
RightHip.Parent = Torso
local LeftHip = Instance.new("Motor6D")
LeftHip.Name = "Left Hip"
LeftHip.C1 = CFrame.new(-0.5, -0.70000004768372, 0)
LeftHip.C0 = CFrame.new(0, 0.25, 0)
LeftHip.Parent = Torso
local RightLeg = Instance.new("Part")
RightLeg.Name = "Right Leg"
RightLeg.BottomSurface = Enum.SurfaceType.Smooth
RightLeg.CanCollide = false
RightLeg.TopSurface = Enum.SurfaceType.Smooth
RightLeg.Color = Color3.fromRGB(151, 0, 0)
RightLeg.Size = Vector3.new(1, 0.5, 1.6000000238419)
RightLeg.Parent = StarterCharacter
local RightArm = Instance.new("Part")
RightArm.Name = "Right Arm"
RightArm.BottomSurface = Enum.SurfaceType.Smooth
RightArm.CanCollide = false
RightArm.TopSurface = Enum.SurfaceType.Smooth
RightArm.Color = Color3.fromRGB(232, 186, 200)
RightArm.Size = Vector3.new(1, 1, 1)
RightArm.Parent = StarterCharacter
local LeftLeg = Instance.new("Part")
LeftLeg.Name = "Left Leg"
LeftLeg.BottomSurface = Enum.SurfaceType.Smooth
LeftLeg.CanCollide = false
LeftLeg.TopSurface = Enum.SurfaceType.Smooth
LeftLeg.Color = Color3.fromRGB(151, 0, 0)
LeftLeg.Size = Vector3.new(1, 0.5, 1.6000000238419)
LeftLeg.Parent = StarterCharacter
local LeftArm = Instance.new("Part")
LeftArm.Name = "Left Arm"
LeftArm.BottomSurface = Enum.SurfaceType.Smooth
LeftArm.CanCollide = false
LeftArm.TopSurface = Enum.SurfaceType.Smooth
LeftArm.Color = Color3.fromRGB(232, 186, 200)
LeftArm.Size = Vector3.new(1, 1, 1)
LeftArm.Parent = StarterCharacter
LeftShoulder.Part1 = Torso
LeftShoulder.Part0 = LeftArm
RightShoulder.Part1 = Torso
RightShoulder.Part0 = RightArm
RightHip.Part1 = Torso
RightHip.Part0 = RightLeg
LeftHip.Part1 = Torso
LeftHip.Part0 = LeftLeg
local root = Instance.new("Motor6D", HumanoidRootPart)
root.Part1 = HumanoidRootPart
root.Part0 = Torso
root.C0 = CFrame.new(0,.4,0)

owner.Character = StarterCharacter

Instance.new("Humanoid", StarterCharacter)

local face = Instance.new("Decal", Torso)

face.Texture = 'rbxassetid://'..1676553712

for i,v in pairs(StarterCharacter:GetChildren()) do
if v:IsA("BasePart") then
Instance.new("SpecialMesh", v).MeshType = 'Sphere'
v.CanCollide = false
end
end

HumanoidRootPart.CanCollide = true

StarterCharacter.PrimaryPart = HumanoidRootPart

StarterCharacter:SetPrimaryPartCFrame(owner.Character.HumanoidRootPart.CFrame)

NORMS = {
LA = LeftShoulder.C0,
RA = RightShoulder.C0,
LL = LeftHip.C0,
RL = RightHip.C0,
Root = root.C0
}

sine = 1

local poyo = Instance.new("Sound", HumanoidRootPart)
poyo.MaxDistance = 50
poyo.SoundId = 'rbxassetid://'..2870109642
poyo.Volume = 1

game:GetService("RunService").Heartbeat:Connect(function()
sine = sine + .1
if HumanoidRootPart.Velocity.Magnitude < 1 then
root.C0 = root.C0:Lerp(NORMS.Root * CFrame.new(0,math.sin(sine*2)/10,0), .15)
LeftShoulder.C0 = LeftShoulder.C0:Lerp(NORMS.LA * CFrame.new(0,math.sin(sine)/10,0), .15)
RightShoulder.C0 = RightShoulder.C0:Lerp(NORMS.RA * CFrame.new(0,math.sin(sine)/10,0), .15)
LeftHip.C0 = LeftHip.C0:Lerp(NORMS.LL * CFrame.new(0,math.sin(-sine*2)/10,0), .15)
RightHip.C0 = RightHip.C0:Lerp(NORMS.RL * CFrame.new(0,math.sin(-sine*2)/10,0), .15)
else
root.C0 = root.C0:Lerp(NORMS.Root * CFrame.new(0,math.sin(sine*2)/10,0), .15)
LeftShoulder.C0 = LeftShoulder.C0:Lerp(NORMS.LA * CFrame.new(0,math.sin(sine)/10,0), .15)
RightShoulder.C0 = RightShoulder.C0:Lerp(NORMS.RA * CFrame.new(0,math.sin(sine)/10,0), .15)
LeftHip.C0 = LeftHip.C0:Lerp(NORMS.LL * CFrame.new(0,-(-.25+math.sin(sine*2)/4),math.sin(-sine*2)) * CFrame.Angles(math.rad(math.sin(sine*2)*45),0,0), .15)
RightHip.C0 = RightHip.C0:Lerp(NORMS.RL * CFrame.new(0,-(-.25+math.sin(sine*2)/4),math.sin(sine*2)) * CFrame.Angles(math.rad(math.sin(-sine*2)*45),0,0), .15)
end

Torso.Mesh.Scale = Torso.Mesh.Scale:Lerp(Vector3.new(1,1,1), .05)
Torso.Mesh.Offset = Torso.Mesh.Offset:Lerp(Vector3.new(0,0,0), .05)

LeftArm.Mesh.Scale = LeftArm.Mesh.Scale:Lerp(Vector3.new(1,1,1), .05)
LeftArm.Mesh.Offset = LeftArm.Mesh.Offset:Lerp(Vector3.new(0,0,0), .05)

RightArm.Mesh.Scale = RightArm.Mesh.Scale:Lerp(Vector3.new(1,1,1), .05)
RightArm.Mesh.Offset = RightArm.Mesh.Offset:Lerp(Vector3.new(0,0,0), .05)

if StarterCharacter:FindFirstChildWhichIsA("Tool") then
tool = StarterCharacter:FindFirstChildWhichIsA("Tool")
if tool:FindFirstChild("Handle") then
RightShoulder.C0 = NORMS.RA * CFrame.Angles(math.rad(-90),0,0)
end
end

end)

DB = false

local rem = Instance.new("RemoteEvent", owner.Character)
rem.Name = 'RemEvent'
rem.OnServerEvent:Connect(function()
if not DB then
DB = true
poyo:Play()
face.Texture = 'rbxassetid://'..277684935
Torso.Mesh.Scale = Vector3.new(1,.5,1)
Torso.Mesh.Offset = Vector3.new(0,-.25,0)

LeftArm.Mesh.Scale = Vector3.new(1,.5,1)
LeftArm.Mesh.Offset = Vector3.new(0,-.25,0)

RightArm.Mesh.Scale = Vector3.new(1,.5,1)
RightArm.Mesh.Offset = Vector3.new(0,-.25,0)

wait(.5)
face.Texture = 'rbxassetid://'..1676553712
DB = false
end
end)

NLS([[local rem = owner.Character.RemEvent

game:GetService("UserInputService").InputBegan:Connect(function(input, gp)
if gp == false then
if input.KeyCode == Enum.KeyCode.E then
rem:FireServer()
end
end
end)]], owner.Character)