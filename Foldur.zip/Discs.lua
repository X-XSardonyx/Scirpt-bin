local musicids = {225497763, 4004540442, 4646253758, 3348708659, 6538555783, 479575803,6430790294,4589610012,2631240760,5341713393,436118735,573736432}
local discs = {}


for i,v in pairs(musicids) do
local Disc = Instance.new("Tool", owner.Backpack)
Disc.Name = v
local Handle = Instance.new("Part", Disc)
Handle.Size = Vector3.new(.1,1.5,1.5)
Handle.Shape = 'Cylinder'
Handle.Material = 'SmoothPlastic'
Handle.Name = 'Handle'
Handle.BrickColor = BrickColor.Random()
Handle.Massless = true
local Middle = Instance.new("Part", Handle)
Middle.Shape = 'Cylinder'
Middle.Material = 'SmoothPlastic'
Middle.Name = 'Middle'
Middle.BrickColor = BrickColor.new("Black")
Middle.Size = Vector3.new(.11,.5,.5)
Middle.Massless = true
local weld = Instance.new("Weld", Middle)
weld.Part1 = Handle
weld.Part0 = Middle

local config = Instance.new("Configuration", Disc)
config.Name = 'config'

local songname = Instance.new("StringValue", config)
songname.Value = game:GetService("MarketplaceService"):GetProductInfo(v).Name
songname.Name = 'covername'

local soundid = Instance.new("IntValue", config)
soundid.Value = v
soundid.Name = 'soundid'

local cover = Instance.new("IntValue", config)
cover.Value = 144080495
cover.Name = 'coverid'

table.insert(discs, Disc)

end

--Disc Customisation
discs[10].Handle.BrickColor = BrickColor.new("Really blue")
discs[12].Handle.BrickColor = BrickColor.new("Institutional white")
discs[1].Handle.Middle.Material = 'Neon' discs[1].Handle.Middle.BrickColor = BrickColor.new("Institutional white")

local db = 0
local anticrashhandle1 = discs[1].Handle
game:GetService'RunService'.Heartbeat:Connect(function()
if db == 11 then
db = 0
else
db = db + .001
end
anticrashhandle1.Color = Color3.fromHSV(db,1,1)
end)
