local CurrentSocialCredits = 0

local questions = {
{"who is the most toxic person on the Void Script Builder?", {"X_XSardonyx", "Youngmacka", "Nothingis", "G1aster", "0X", "aldo", "Denispitu"},4},
{"Who is the owner of Void Script Builder?", {'Tusk', "VoidPurple", "Cupcake", "Gru 😳"}, 1},
{"Who is the most cringe?", {"G1aster", "Nothingis", "Aldo", "X_XSardonyx", "Goku children💀", "Denispitu"}, 5},
{"Which is the worst script?", {"Re-Char", "Clown van", "Mass kill", "Server crash", "Part spam"}, 4},
{"Who iz da sus imposter?", {'G1aster 😭', "YoungMacka 🤡", "Qwerty 😳", "X_XSardonyx 💀","Nothingis 🤬", '⛓🖤⛓Denispitu⛓🖤⛓'}, 1},
{"What is your opinion on bobux?!?! 😳", {"Yez 😊", 'NO!?! 💀🤬'}, 1},
{"Who is the best box of goldfish crackers?",{'Lucas 🤰', "YoungMacka 🤡", "Qwerty 😳", "X_XSardonyx 💀","Nothingis 🤬", '⛓🖤⛓Denispitu⛓🖤⛓'}, 6},
{"Who has the best fedora?", {"Lucas 😩","Lucas 😩","Lucas 😩","Lucas 😩","Lucas 😩","Lucas 🤪"}, 1}
}

local part = Instance.new("Part", script)
part.Size = Vector3.new(10,10,0)
part.Anchored = true
part.CanCollide = true
part.CanTouch = false
part.Locked = true
part.Transparency = 1
part.CFrame = owner.Character.PrimaryPart.CFrame * CFrame.new(0,3.5,-10) * CFrame.Angles(0,math.rad(180),0)

local gui = Instance.new("SurfaceGui", part)
gui.Adornee = part

local bg = Instance.new("ScrollingFrame", gui)
bg.Size = UDim2.new(1,0,1,0)
bg.BorderSizePixel = 0
bg.ZIndex = -100
bg.ScrollingDirection = Enum.ScrollingDirection.X
bg.CanvasSize = UDim2.new(0,0,0,0)
bg.BackgroundColor = BrickColor.new("Really red")

local Display = Instance.new("TextBox", gui)
Display.Size = UDim2.new(.2,0,.1,0)
Display.Position = UDim2.new(.8,0,.9,0)
Display.BackgroundTransparency = 1
Display.Text = CurrentSocialCredits..' Social Credits'
Display.TextSize = 50
Display.TextXAlignment = 'Right'
Display.TextColor = BrickColor.new("Institutional white")

local bgsound = Instance.new("Sound", part)
bgsound.SoundId = 'rbxassetid://7962696122'
bgsound.Volume = .25
bgsound.Looped = true
bgsound.MaxDistance = 100
bgsound:Play()

local sfx = Instance.new("Sound", part)
sfx.SoundId = 'rbxassetid://7962696122'
sfx.Volume = 1
sfx.MaxDistance = 100

local sfx2 = Instance.new("Sound", part)
sfx2.SoundId = 'rbxassetid://7962696122'
sfx2.Volume = 1
sfx2.MaxDistance = 100

function good()
CurrentSocialCredits = CurrentSocialCredits + 100

sfx.SoundId = 'rbxassetid://'..6150774030
sfx:Play()

local tb = Instance.new("TextBox", bg)
tb.Size = UDim2.new(0,100,0,25)
tb.Position = UDim2.new(math.random(2,8)/10,0,math.random(2,8)/10,0)
tb.BackgroundTransparency = 1
tb.Size = UDim2.new(.25,0,.25,0)
tb.Text = '+100 Social Credits'
tb.TextScaled = true
tb.TextColor = BrickColor.new("Institutional white")

game:GetService("Debris"):AddItem(tb, 3)

local velo = Vector3.new(0,-10,0)

coroutine.wrap(function()
repeat
task.wait()
velo = velo:Lerp(Vector3.new(2,10,0), .1)
tb.Position = tb.Position + UDim2.new(0,velo.X,0,velo.Y)
until not tb
end)()
end

function bad()
CurrentSocialCredits = CurrentSocialCredits - 100
sfx.SoundId = 'rbxassetid://'..7274041889
sfx:Play()

sfx2.SoundId = 'rbxassetid://'..6717089252
sfx2:Play()

local tb = Instance.new("TextBox", bg)
tb.Size = UDim2.new(0,100,0,50)
tb.Position = UDim2.new(math.random(2,8)/10,0,math.random(2,8)/10,0)
tb.BackgroundTransparency = 1
tb.Size = UDim2.new(.25,0,.25,0)
tb.Text = '-100 Social Credits'
tb.TextScaled = true
tb.TextColor = BrickColor.new("Institutional white")

game:GetService("Debris"):AddItem(tb, 3)

local direction = math.random(-5,5)

local velo = Vector3.new(0,-10,0)

coroutine.wrap(function()
repeat
task.wait()
velo = velo:Lerp(Vector3.new(direction,10,0), .05)
tb.Position = tb.Position + UDim2.new(0,velo.X,0,velo.Y)
until not tb
end)()
end

function Quiz()

Display.Text = CurrentSocialCredits..' Social Credits'

local question = questions[math.random(1,#questions)]

answers = question[2] 

local question_text = Instance.new("TextBox", bg)
question_text.Size = UDim2.new(1,0,0,50)
question_text.Text = question[1]
question_text.TextScaled = true
question_text.BorderSizePixel = 0
question_text.BackgroundTransparency = 1

for i,v in pairs(answers) do

local button = Instance.new("TextButton", bg)
button.Size = UDim2.new(1,0,0,50)
button.Text = ''
button.BorderSizePixel = 0
button.Position = UDim2.new(0,0,0,i*50)
button.BackgroundTransparency = 1

local txt = Instance.new("TextBox", button)
txt.Size = UDim2.new(1,0,1,0)
txt.BackgroundTransparency = 1
txt.ZIndex = -1
txt.TextScaled = true
txt.Text = v

button.MouseButton1Click:Connect(function()
bg:ClearAllChildren()
if question[3] == i then
good()
else
bad()
end
wait(2)
Quiz()
end)

end

end

Quiz()

owner.Chatted:Connect(function(msg)
msg = string.split(string.lower(msg), ' ')
if msg[1] == '-add' then
CurrentSocialCredits = CurrentSocialCredits + msg[2]
end
end)