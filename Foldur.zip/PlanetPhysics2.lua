local radius = 10
offset = CFrame.new(0,60,100)

local planet = Instance.new("Part", script)
planet.Size = Vector3.new(radius*2,radius*2,radius*2)
planet.Shape = 'Ball'
planet.Anchored = true
planet.CanCollide = false
planet.Material = 'Grass'
planet.BrickColor = BrickColor.new("Camo")
planet.CFrame = offset

local humanoid = owner.Character.Humanoid

humanoid.PlatformStand = true

owner.Chatted:Connect(function(msg)
msg = string.split(string.lower(msg), ' ')
if msg[1] and msg[2] then
if msg[1] == '-size' then
radius = msg[2]
planet.Size = Vector3.new(radius*2,radius*2,radius*2)
elseif msg[1] == '-pos' then
CF = string.split(msg[2], ',')
offset = CFrame.new(CF[1],CF[2],CF[3])
planet.CFrame = offset
end
end
end)

for i,v in pairs(owner.Character:GetDescendants()) do
if v:IsA("Motor6D") then
local weld = Instance.new("Weld", v.Parent)
weld.Part1 = v.Part1
weld.Part0 = v.Part0
weld.C0 = v.C0
weld.C1 = v.C1
weld.Name = v.Name
v:Destroy()
elseif v:IsA("Humanoid") then
v.DisplayName = ' '
end
end

--Anim Defaults
AnimDefaults = {
Head = owner.Character.Torso.Neck.C0,
Torso = owner.Character.HumanoidRootPart.RootJoint.C0,
Larm = owner.Character.Torso["Left Shoulder"].C0,
Rarm = owner.Character.Torso["Right Shoulder"].C0,
Lleg = owner.Character.Torso["Left Hip"].C0,
Rleg = owner.Character.Torso["Right Hip"].C0
}
--Setting Joints
Head = owner.Character.Torso.Neck
Torso = owner.Character.HumanoidRootPart.RootJoint
Larm = owner.Character.Torso["Left Shoulder"]
Rarm = owner.Character.Torso["Right Shoulder"]
Lleg = owner.Character.Torso["Left Hip"]
Rleg = owner.Character.Torso["Right Hip"]

sine = 1

game:GetService("RunService").Heartbeat:Connect(function()
sine = sine + .1

if humanoid.MoveDirection.Magnitude > 0 then

Torso.C0 = Torso.C0:Lerp(AnimDefaults.Torso * CFrame.new(0,0,math.sin(sine*2)/5), .1)
Rarm.C0 = Rarm.C0:Lerp(AnimDefaults.Rarm *  CFrame.Angles(0,math.rad(math.sin(sine) * 30), -math.rad(math.sin(sine ) * 45)), .1)
Larm.C0 = Larm.C0:Lerp(AnimDefaults.Larm *  CFrame.Angles(0,math.rad(math.sin(sine) * 30), -math.rad(math.sin(sine ) * 45)), .1)
Lleg.C0 = Lleg.C0:Lerp(AnimDefaults.Lleg *  CFrame.Angles(0,-math.rad(0), math.rad(math.sin(sine) * 45)), .1)
Rleg.C0 = Rleg.C0:Lerp(AnimDefaults.Rleg *  CFrame.Angles(0,-math.rad(0), math.rad(math.sin(sine) * 45)), .1)
else
Torso.C0 = Torso.C0:Lerp(AnimDefaults.Torso * CFrame.new(0,0,math.sin(sine)/5), .1)
Larm.C0 = Larm.C0:Lerp(AnimDefaults.Larm *  CFrame.new(0,-.25 + math.sin(sine)/10,0) * CFrame.Angles(0,math.rad(10), math.rad(10)), .1)
Rarm.C0 = Rarm.C0:Lerp(AnimDefaults.Rarm *  CFrame.new(0,-.25 + math.sin(sine)/10,0) * CFrame.Angles(0,math.rad(10), math.rad(10)), .1)
Lleg.C0 = Lleg.C0:Lerp(AnimDefaults.Lleg * CFrame.new(0,math.sin(-sine)/10,0) * CFrame.Angles(0,math.rad(15),0), .2)
Rleg.C0 = Rleg.C0:Lerp(AnimDefaults.Rleg * CFrame.new(0,math.sin(-sine)/10,0) *  CFrame.Angles(0,math.rad(0),0), .2)
end
end)


Value = Instance.new("ObjectValue", owner.Character)
Value.Value = planet

NLS([[

local rem = script.Parent

cam = workspace.CurrentCamera

HumanoidRootPart = owner.Character.HumanoidRootPart

orien = CFrame.Angles(0,0,0)

W = false
S = false
A = false
D = false

jumpDB = false
humanoid = owner.Character.Humanoid
planet = script.Parent.Value
Pac = Instance.new("Part")
Y = 0
script = planet.Parent
local pos = Instance.new("BodyPosition", HumanoidRootPart)
pos.MaxForce = Vector3.new(math.huge,math.huge,math.huge)
pos.P = 150000
pos.D = 1000

local gy = Instance.new("BodyGyro", HumanoidRootPart)
gy.MaxTorque= Vector3.new(math.huge,math.huge,math.huge)
gy.P = 150000
gy.D = 1000

game:GetService("UserInputService").InputBegan:Connect(function(input, gp)
if not gp then
input = input.KeyCode
if input == Enum.KeyCode.W then
W = true
repeat
task.wait()
orien = orien * CFrame.Angles(math.rad(-(owner.Character.Humanoid.WalkSpeed/16*2)/(planet.Size.X/30)),0,0)

until W == false
elseif input == Enum.KeyCode.S then
S = true
repeat
task.wait()

orien = orien * CFrame.Angles(math.rad((owner.Character.Humanoid.WalkSpeed/16*2)/(planet.Size.X/30)),0,0)

until S == false
elseif input == Enum.KeyCode.A then
A = true
repeat
task.wait()

orien = orien * CFrame.Angles(0,math.rad(4),0)

until A == false

elseif input == Enum.KeyCode.D then
D = true
repeat
task.wait()

orien = orien * CFrame.Angles(0,math.rad(-4),0)

until D == false

end
end
end)

game:GetService("UserInputService").InputEnded:Connect(function(input, gp)
input = input.KeyCode
if input == Enum.KeyCode.W then
W = false
elseif input == Enum.KeyCode.A then
A = false
elseif input == Enum.KeyCode.S then
S = false
elseif input == Enum.KeyCode.D then
D = false
end
end)

coroutine.wrap(function()
while true do
task.wait()
local radius = planet.Size.X/2
offset = planet.CFrame
coroutine.wrap(function()
if humanoid.Jump then
if not jumpDB then
jumpDB = true
for i = 1,10 do
Y = Y + i/5
task.wait()
end
repeat task.wait() until Y <.1
jumpDB = false
end
end


end)()

Y = math.clamp(Y-.5,0,10)

Pac.CFrame = offset * orien * CFrame.new(0,radius+2.5 + Y,0)

pos.Position = Pac.Position
gy.CFrame = Pac.CFrame

end
end)()

]], Value)