charts={
expurgation={[[https://raw.githubusercontent.com/X-XSardonyx/VSB-Scripts/main/expurgation-hard.json]], 6900844331, "Expurgation"},
happy={[[https://raw.githubusercontent.com/X-XSardonyx/VSB-Scripts/main/really-happy-hard.json]], 7795670300, "Really Happy"},
roses={[[https://raw.githubusercontent.com/ninjamuffin99/Funkin/master/assets/preload/data/roses/roses.json]], 6337428158, "Roses"},
fresh={[[https://raw.githubusercontent.com/ninjamuffin99/Funkin/master/assets/preload/data/fresh/fresh.json]] ,6025191328,"Fresh"},
winterhorrorland={[[https://raw.githubusercontent.com/ninjamuffin99/Funkin/master/assets/preload/data/winter-horrorland/winter-horrorland.json]] ,6275837083,'Winter Horrorland'},
south={[[https://raw.githubusercontent.com/ninjamuffin99/Funkin/master/assets/preload/data/south/south.json]] ,6038765924 ,'South'},
nonsence={[[https://raw.githubusercontent.com/X-XSardonyx/VSB-Scripts/main/nonsence.json]], 7102185418 ,"nonsense"},
commonsense={[[https://raw.githubusercontent.com/X-XSardonyx/VSB-Scripts/main/Common%20sense.json]], 7112426008, 'Common Sense'},
opheebop={[[https://raw.githubusercontent.com/Radhew/Salt-Engine/master/assets/preload/data/opheebop/opheebop.json]], 6730593959, 'Opheebop'},
bsmilf={[[https://raw.githubusercontent.com/kckarnige/fnf-week-7-code/main/src/assets/data/milf/milf.json]], 7071427516, 'B-Side Milf'},
endless={[[https://raw.githubusercontent.com/CryBitDev/Sonic.exe-source-1.5/master/assets/preload/data/endless/endless-hard.json]] ,7313871314 ,"Endless"},
sunshine={[[https://raw.githubusercontent.com/wildythomas/mmmbob/main/assets/preload/data/sunshine/sunshine.json]] , 6822649446 ,'Sunshine'},
withered={[[https://raw.githubusercontent.com/wildythomas/mmmbob/main/assets/preload/data/withered/withered.json]] , 6822655743 ,'Withered'},
run={[[https://raw.githubusercontent.com/wildythomas/mmmbob/main/assets/preload/data/run/run.json]], 6822647318, 'RUN'},
release={[[https://raw.githubusercontent.com/Rageminer996/Smoke-Em-Out-Struggle-Mod/main/assets/preload/data/release/release.json]], 6767491531, 'Release'},
nerves={[[https://raw.githubusercontent.com/Rageminer996/Smoke-Em-Out-Struggle-Mod/main/assets/preload/data/nerves/nerves.json]], 6763964321, 'Nerves'},
headache={[[https://raw.githubusercontent.com/Rageminer996/Smoke-Em-Out-Struggle-Mod/main/assets/preload/data/headache/headache.json]], 6765405147,'Headache'},
fading={[[https://raw.githubusercontent.com/Rageminer996/Smoke-Em-Out-Struggle-Mod/main/assets/preload/data/fading/fading.json]], 6770738952 , 'Fading'},
magelo={[[https://fnf-songs.errortp.repl.co/megalostrikeback.html]], 6745517883,'Magelostrikeback'},
otherfriends={[[https://raw.githubusercontent.com/theevity1/VS-Spinel/master/assets/preload/data/other-friends/other-friends.json]], 7490567703, 'Other Friends'},
flippyroll={[[https://raw.githubusercontent.com/Yirius125/FNF-VsFliqpy-1.5-Full-Week-Engine/main/assets/preload/data/flippy-roll/flippy-roll.json]], 7047986662, 'Flippy-Roll'},
finaldestination={[[https://raw.githubusercontent.com/GithubSPerez/shaggy-matt/main/assets/preload/data/final-destination/final-destination-god.json]], 7057969804 , 'Final Destination'},
nonsensical={[[https://raw.githubusercontent.com/X-XSardonyx/VSB-Scripts/main/nonsensical.json]], 7361704969, "Nonsensical"},
playtime={[[https://raw.githubusercontent.com/X-XSardonyx/VSB-Scripts/main/Playtime.json]], 7838052823,'Playtime'},
nohero={[[https://raw.githubusercontent.com/X-XSardonyx/VSB-Scripts/main/no-hero.json]], 7951754097, 'No-Hero'},
change={[[https://raw.githubusercontent.com/X-XSardonyx/VSB-Scripts/main/you'll-make-the-change-hard.json]], 8055850993, "Youll Make The Change"},
MONOCHROME = {[[https://raw.githubusercontent.com/Yoshubs/Hypnos-Lullaby/master/assets/preload/data/monochrome/monochrome.json]], 7860856702, "Monochrome"},
SUPERIDOL={[[https://raw.githubusercontent.com/X-XSardonyx/VSB-Scripts/main/super-idol-hard.json]], 6945045428,'Super Idol 105*'}

}

speed = 1

TS = game:GetService("TweenService")

script.Parent = owner.Character

AnimSpeed = TweenInfo.new(
	.1,
	Enum.EasingStyle.Linear
)

frame = Instance.new("Frame", Instance.new("ScreenGui", owner.PlayerGui))
frame.Size = UDim2.new(.25,0,.75,0)
frame.BackgroundTransparency = .9
frame.Position = UDim2.new(.375,0,.125,0)
num = 0

NUM = 0

for i,v in pairs(charts) do
NUM = NUM + 1
end

currentchart = nil

for I,v in pairs(charts) do
num = num + 1
button = Instance.new("TextButton",frame)
button.Size = UDim2.new(1,0,1/NUM,0)
button.BackgroundTransparency = .5
button.BackgroundColor = BrickColor.new("Really black")
button.TextColor = BrickColor.new("Institutional white")
button.TextScaled = true
button.BorderSizePixel = 0
button.Text = v[3]

button.Position = UDim2.new(0,0,num/NUM,0) - UDim2.new(0,0,1/NUM,0)

button.MouseButton1Click:Connect(function()
frame.Parent:Destroy()
currentchart = v
end)

end

repeat task.wait() until currentchart ~= nil

GKEY = 0

HTTP = game:GetService("HttpService")
Data = HTTP:JSONDecode(HTTP:GetAsync(currentchart[1]))
print(Data.song.song)
keys = Data.song.notes

local sound = Instance.new("Sound", owner.Character.HumanoidRootPart)
sound.SoundId = 'rbxassetid://'..currentchart[2]
sound.Volume = 1
sound.Pitch = speed
sound.MaxDistance = 100

for i,v in pairs(owner.Character:GetDescendants()) do
if v:IsA("Motor6D") then
local weld = Instance.new("Weld", v.Parent)
weld.Part1 = v.Part1
weld.Part0 = v.Part0
weld.C0 = v.C0
weld.C1 = v.C1
weld.Name = v.Name
v:Destroy()
end
end


Head = owner.Character.Torso.Neck
Torso = owner.Character.HumanoidRootPart.RootJoint
Larm = owner.Character.Torso["Left Shoulder"]
Rarm = owner.Character.Torso["Right Shoulder"]
Lleg = owner.Character.Torso["Left Hip"]
Rleg = owner.Character.Torso["Right Hip"]

AnimDefaults = {
Head = owner.Character.Torso.Neck.C0,
Torso = owner.Character.HumanoidRootPart.RootJoint.C0,
Larm = owner.Character.Torso["Left Shoulder"].C0,
Rarm = owner.Character.Torso["Right Shoulder"].C0,
Lleg = owner.Character.Torso["Left Hip"].C0,
Rleg = owner.Character.Torso["Right Hip"].C0
}

Torso.C0 = AnimDefaults.Torso
Head.C0 = AnimDefaults.Head
Larm.C0 = AnimDefaults.Larm
Rarm.C0 = AnimDefaults.Rarm
Lleg.C0 = AnimDefaults.Lleg
Rleg.C0 = AnimDefaults.Rleg

if Data.song.song == "you'll-make-the-change" then

local shield = Instance.new("Part", script)
shield.Size = Vector3.new(4,4,4)
shield.Material = 'Neon'
shield.BrickColor = BrickColor.new("Pink")
shield.Shape = 'Ball'
shield.Anchored = true
shield.CanCollide = false
shield.Transparency = .25

local cut1 = Instance.new("Part", script)
cut1.Size= Vector3.new(5,5,5)
cut1.Anchored = true
cut1.CFrame = shield.CFrame * CFrame.new(0,0,1.5)


local cut2 = Instance.new("Part", script)
cut2.Size= Vector3.new(3.5,3.5,3.5)
cut2.Anchored = true
cut2.Shape = 'Ball'

union = shield:SubtractAsync({cut1,cut2})
union.Parent = script
union.CanCollide = false
union.Massless = true
union.Anchored = false

shield:Destroy()
cut1:Destroy()
cut2:Destroy()

weld = Instance.new("Weld", union)
weld.Part1 = union
weld.Part0 = owner.Character["Right Arm"]
weld.C0 = CFrame.new(0,-2,0) * CFrame.Angles(math.rad(-90),0,0)

game:GetService("RunService").Heartbeat:Connect(function()
weld.C0 = weld.C0 * CFrame.Angles(0,0,math.rad(1))
end)

elseif Data.song.song == 'Monochrome' then


for i,v in pairs(owner.Character:GetDescendants()) do
if v:IsA("BasePart") then
v.BrickColor = BrickColor.new("Institutional white")
v.Material = 'SmoothPlastic'
elseif v:IsA("SpecialMesh") then
v.TextureId = ''
elseif v:IsA("CharacterMesh") then
v:Destroy()
end
end


for i,v in pairs({owner.Character["Left Arm"],owner.Character["Right Arm"],owner.Character["Left Leg"],owner.Character["Right Leg"]}) do
mesh = Instance.new("BlockMesh", v)
mesh.Scale = Vector3.new(1,.5,1)
mesh.Offset = Vector3.new(0,.5,0)
end

mesh = Instance.new("BlockMesh", owner.Character.Torso)

local sky = Instance.new("SpecialMesh", owner.Character.HumanoidRootPart)
sky.Scale = Vector3.new(-15,15,15)
sky.Offset = Vector3.new(0,2.2,0)
sky.MeshType = 'FileMesh'
sky.MeshId = 'rbxassetid://1185246'
sky.Parent.BrickColor = BrickColor.new("Really black")
sky.Parent.Transparency = 0

owner.Character.Head:FindFirstChildOfClass("Decal").Texture = 'rbxassetid://8037280807'

for i,v in pairs({owner.Character["Left Arm"],owner.Character["Right Arm"],owner.Character["Left Leg"],owner.Character["Right Leg"]}) do
local part1 = Instance.new("Part", v)
part1.Size = Vector3.new(.9,.05,.9)
part1.CanCollide = false
part1.Material = 'Granite'
part1.BrickColor = BrickColor.new("Persimmon")
part1.Locked = true
weld = Instance.new("Weld", part1)
weld.Part1 = part1
weld.Part0 = v

local part2 = Instance.new("Part", v)
part2.Size = Vector3.new(.25,1,.25)
part2.CanCollide = false
part2.Material = 'Concrete'
part2.BrickColor = BrickColor.new("Institutional white")
part2.Locked = true
weld2 = Instance.new("Weld", part2)
weld2.Part1 = part2
weld2.Part0 = v
end
elseif Data.song.song == 'Nonsense' or Data.song.song == 'Nonsensical' then
sine = 1

baseTorso = AnimDefaults.Torso

game:GetService("RunService").Heartbeat:Connect(function()
sine = sine + .1
Torso.C0 = baseTorso * CFrame.new(0,0,3+math.sin(sine/2)/2)
end)


elseif Data.song.song == 'Fading' or Data.song.song == 'Release' then
Instance.new("Smoke", owner.Character.HumanoidRootPart)

for i,v in pairs(owner.Character:GetDescendants()) do
if v:IsA("BasePart") then
v.BrickColor = BrickColor.new("Institutional white")
v.Material = 'SmoothPlastic'
v.Transparency = .5
elseif v:IsA("SpecialMesh") then
v.TextureId = ''
elseif v:IsA("Shirt") or v:IsA("Pants") then
v:Destroy()
end
end

owner.Character.HumanoidRootPart.Transparency = 1

end


UP = {

Head = AnimDefaults.Head * CFrame.Angles(0,0,math.rad(20)),
Torso = AnimDefaults.Torso * CFrame.Angles(0,0,math.rad(10)),
Larm = AnimDefaults.Larm * CFrame.Angles(0,0,math.rad(20)),
Rarm = AnimDefaults.Rarm * CFrame.Angles(0,0,math.rad(105)),
Lleg = AnimDefaults.Lleg * CFrame.Angles(0,0,math.rad(10)),
Rleg = AnimDefaults.Rleg * CFrame.Angles(0,0,math.rad(10))

}

LEFT = {

Head = AnimDefaults.Head * CFrame.Angles(0,0,math.rad(-10)),
Torso = AnimDefaults.Torso * CFrame.Angles(0,0,math.rad(-15)),
Larm = AnimDefaults.Larm * CFrame.Angles(0,0,math.rad(20)),
Rarm = AnimDefaults.Rarm * CFrame.Angles(0,math.rad(30),math.rad(105)),
Lleg = AnimDefaults.Lleg * CFrame.Angles(0,0,math.rad(-10)),
Rleg = AnimDefaults.Rleg * CFrame.Angles(0,0,math.rad(-10))

}

DOWN = {

Torso = AnimDefaults.Torso,
Head = AnimDefaults.Head,
Rarm = AnimDefaults.Rarm * CFrame.Angles(0,math.rad(45), math.rad(80)),
Larm = AnimDefaults.Larm *  CFrame.new(-.5,-.25,.5) * CFrame.Angles(0,math.rad(130), math.rad(80)),
Lleg = AnimDefaults.Lleg * CFrame.new(0,0,0) * CFrame.Angles(0,math.rad(15),0),
Rleg = AnimDefaults.Rleg * CFrame.new(0,0,0) *  CFrame.Angles(0,math.rad(0),0)
}

RIGHT = {

Torso = AnimDefaults.Torso * CFrame.new(0,0,0),
Rarm = AnimDefaults.Rarm * CFrame.new(.5,0,.5) * CFrame.Angles(0,math.rad(-90), math.rad(90)),
Larm = AnimDefaults.Larm *  CFrame.new(0,-.25,0) * CFrame.Angles(0,math.rad(10), math.rad(10)),
Lleg = AnimDefaults.Lleg * CFrame.new(0,0,0) * CFrame.Angles(0,math.rad(15),0),
Rleg = AnimDefaults.Rleg * CFrame.new(0,0,0) *  CFrame.Angles(0,math.rad(0),0),
Head = AnimDefaults.Head
}

posing=false

function key(num)
posing = true

Head.C0 = AnimDefaults.Head
Larm.C0 = AnimDefaults.Larm
Rarm.C0 = AnimDefaults.Rarm
Lleg.C0 = AnimDefaults.Lleg
Rleg.C0 = AnimDefaults.Rleg



if num == 0 then
if Data.song.song == 'Nonsense' or Data.song.song == 'Nonsensical' then
return
else
TS:create(Head, AnimSpeed, {C0 = LEFT.Head}):Play()
TS:create(Larm, AnimSpeed, {C0 = LEFT.Larm}):Play()
TS:create(Rarm, AnimSpeed, {C0 = LEFT.Rarm}):Play()
TS:create(Lleg, AnimSpeed, {C0 = LEFT.Lleg}):Play()
TS:create(Rleg, AnimSpeed, {C0 = LEFT.Rleg}):Play()
TS:create(Torso, AnimSpeed, {C0 = LEFT.Torso}):Play()
end

elseif num == 1 then
if Data.song.song == 'Nonsense' or Data.song.song == 'Nonsensical' then
return
else
TS:create(Head, AnimSpeed, {C0 = UP.Head}):Play()
TS:create(Larm, AnimSpeed, {C0 = UP.Larm}):Play()
TS:create(Rarm, AnimSpeed, {C0 = UP.Rarm}):Play()
TS:create(Lleg, AnimSpeed, {C0 = UP.Lleg}):Play()
TS:create(Rleg, AnimSpeed, {C0 = UP.Rleg}):Play()
TS:create(Torso, AnimSpeed, {C0 = UP.Torso}):Play()
end



elseif num == 2 then
if Data.song.song == 'Nonsense' or Data.song.song == 'Nonsensical' then
return
else
TS:create(Head, AnimSpeed, {C0 = DOWN.Head}):Play()
TS:create(Larm, AnimSpeed, {C0 = DOWN.Larm}):Play()
TS:create(Rarm, AnimSpeed, {C0 = DOWN.Rarm}):Play()
TS:create(Lleg, AnimSpeed, {C0 = DOWN.Lleg}):Play()
TS:create(Rleg, AnimSpeed, {C0 = DOWN.Rleg}):Play()
TS:create(Torso, AnimSpeed, {C0 = DOWN.Torso}):Play()
end


elseif num == 3 then
if Data.song.song == 'Nonsense' or Data.song.song == 'Nonsensical' then
return
else
TS:create(Head, AnimSpeed, {C0 = RIGHT.Head}):Play()
TS:create(Larm, AnimSpeed, {C0 = RIGHT.Larm}):Play()
TS:create(Rarm, AnimSpeed, {C0 = RIGHT.Rarm}):Play()
TS:create(Lleg, AnimSpeed, {C0 = RIGHT.Lleg}):Play()
TS:create(Rleg, AnimSpeed, {C0 = RIGHT.Rleg}):Play()
TS:create(Torso, AnimSpeed, {C0 = RIGHT.Torso}):Play()
end

end
end


sound:Play()

for i = 1, #keys do

if keys[i]["mustHitSection"] then
Torso.C0 = AnimDefaults.Torso
Head.C0 = AnimDefaults.Head
Larm.C0 = AnimDefaults.Larm
Rarm.C0 = AnimDefaults.Rarm
Lleg.C0 = AnimDefaults.Lleg
Rleg.C0 = AnimDefaults.Rleg
end

		sectionkeys = keys[i]["sectionNotes"]
		bpm = keys[i]["bpm"] or 0
		if not keys[i]["mustHitSection"] then
		for b = 1, #sectionkeys do
			local what = sectionkeys[b]
			coroutine.wrap(function()
				task.wait(what[1]/1000/speed)
				if what[2] == 0 then
					key(0)
				end
				if what[2] == 1 then
					key(1)
				end
				if what[2] == 2 then
					key(2)
				end
				if what[2] == 3 then
					key(3)
				end
			end)()
		end
		else
		for b = 1, #sectionkeys do
			local what = sectionkeys[b]
			coroutine.wrap(function()
				task.wait(what[1]/1000)
				if what[2] == 4 then
					key(4)
				end
				if what[2] == 5 then
					key(5)
				end
				if what[2] == 6 then
					key(6)
				end
				if what[2] == 7 then
					key(7)
				end
			end)
		end
		end	
	end
