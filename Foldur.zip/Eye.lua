local char = Workspace.X_XSardonyx

local eye1 = Instance.new("Part", char)
local eye2 = Instance.new("Part", char)

local mesh1 = Instance.new("SpecialMesh", eye1)
local mesh2 = Instance.new("SpecialMesh", eye2)


local weld1 = Instance.new("Weld", eye1)
local weld2 = Instance.new("Weld", eye2)

weld1.Part1 = char.Head
weld1.Part0 = eye1
weld1.C0 = CFrame.new(0,-5,0)

weld2.Part1 = eye1
weld2.Part0 = eye2
weld2.C0 = CFrame.new(0,0,.35)



eye1.Size = Vector3.new(4,4,1)
eye2.Size = Vector3.new(3.25,3.5,.5)

mesh1.MeshType = 'Sphere'
mesh2.MeshType = 'Sphere'

eye1.Material = 'SmoothPlastic'
eye2.Material = 'Neon'

eye1.BrickColor = BrickColor.new("Really black")

while wait() do
for i = 1,10 do
eye2.Color = eye2.Color:Lerp(BrickColor.new("Really red").Color, .15)
eye2.Size = eye2.Size:Lerp(Vector3.new(3.25,1,.5), .15)
wait()
end
wait()
for i = 1,10 do
eye2.Color = eye2.Color:Lerp(BrickColor.new("Deep orange").Color, .15)
wait()
end
wait()
for i = 1,10 do
eye2.Color = eye2.Color:Lerp(BrickColor.new("New Yeller").Color, .15)
eye2.Size = eye2.Size:Lerp(Vector3.new(3.25,3.5,.5), .15)
wait()
end
wait()
for i = 1,10 do
eye2.Color = eye2.Color:Lerp(BrickColor.new("Lime green").Color, .15)
wait()
end
wait()
for i = 1,10 do
eye2.Color = eye2.Color:Lerp(BrickColor.new("Really blue").Color, .15)
wait()
end
wait()
for i = 1,10 do
eye2.Color = eye2.Color:Lerp(BrickColor.new("Magenta").Color, .15)
wait()
end
end