local rem = Instance.new("RemoteEvent", script)
script.Parent = owner.Character
terrain = workspace.Terrain

rem.OnServerEvent:Connect(function(plr, pos, cut)
if cut == true then
terrain:FillBall(pos, 10, 'Air')
else
terrain:FillBall(pos, 10, 'Sand')
end
end)


NLS([[

local rem = script.Parent

local mouse = owner:GetMouse()

Cut = Instance.new("Tool", owner.Backpack)
Cut.Name = 'Terrain Cut'
Cut.RequiresHandle = false
Cut.CanBeDropped = false

Build = Instance.new("Tool", owner.Backpack)
Build.Name = 'Terrain Build'
Build.RequiresHandle = false
Build.CanBeDropped = false

mousedown = false

mouse.Button1Down:Connect(function()
mousedown = true

repeat
if Cut.Parent == owner.Character then
rem:FireServer(mouse.Hit.Position, true)
end

if Build.Parent == owner.Character then
rem:FireServer(mouse.Hit.Position, false)
end
task.wait()
until mousedown == false
end)

mouse.Button1Up:Connect(function()
mousedown = false
end)
]], rem)

local torch = Instance.new("Tool", owner.Backpack)
torch.Name = 'Torch'
torch.Grip = CFrame.new(0,-.75,0)

local torch_stick = Instance.new("Part", torch)
torch_stick.Name = 'Handle'
torch_stick.BrickColor = BrickColor.new("CGA brown")
torch_stick.Material = 'SmoothPlastic'
torch_stick.Size = Vector3.new(.25,2,.25)
torch_stick.Massless = true

local flame = Instance.new("Part", torch_stick)
flame.Size = Vector3.new(.25,.25,.25)
flame.Material = 'Neon'
flame.BrickColor = BrickColor.new("New Yeller")
flame.Massless = true

weld = Instance.new("Weld", flame)
weld.Part1 = flame
weld.Part0 = torch_stick
weld.C0 = CFrame.new(0,1.125,0)

Instance.new("Fire", flame)
local light = Instance.new("PointLight", flame)
light.Range = 100

HealTool = Instance.new("Tool", owner.Backpack)
HealTool.Name = 'Heal'

local Glow = Instance.new("Part", HealTool)
Glow.Size = Vector3.new(.25,1,.25)
Glow.Name = 'Handle'
Glow.Material = 'Neon'
Glow.BrickColor = BrickColor.new("Lime green")
Glow.Massless = true

local rem = Instance.new("RemoteEvent", HealTool)

rem.OnServerEvent:Connect(function(plr, hum)
hum.Health = hum.Health + 3
end)

NLS([[
local rem = script.Parent

local mouse = owner:GetMouse()

mousedown = false

mouse.Button1Down:Connect(function()
mousedown = true

repeat
if mouse.Target then
if mouse.Target.Parent:FindFirstChildOfClass("Humanoid") then
rem:FireServer(mouse.Target.Parent:FindFirstChildOfClass("Humanoid"))
end
end

task.wait()
until mousedown == false
end)

mouse.Button1Up:Connect(function()
mousedown = false
end)]], rem)

--Character editing

for i,v in pairs(owner.Character:GetChildren()) do
if v:IsA("Shirt") or v:IsA("Pants") or v:IsA("CharacterMesh") or v:IsA("ShirtGraphic") then
v:Destroy()
end
end

local shirt = Instance.new("Shirt", owner.Character)
shirt.ShirtTemplate = 'rbxassetid://7295037724'

local pants = Instance.new("Pants", owner.Character)
pants.PantsTemplate = 'rbxassetid://7295038774'

Helmet = Instance.new("Part", owner.Character.Head)
Helmet.Size = Vector3.new(2,2,2)
Helmet.Shape = 'Ball'
Helmet.Material = 'SmoothPlastic'
Helmet.Transparency = .75
Helmet.BrickColor = BrickColor.new("Pearl")
Helmet.CanCollide = false
Helmet.Massless = true

HM = Helmet:Clone()
HM.Parent= script
HM.Size = Vector3.new(1.75,1.75,1.75)

CLON = Helmet:SubtractAsync{HM}
CLON.Parent = owner.Character.Head

Helmet:Destroy()
HM:Destroy()

Helmet = CLON

weld = Instance.new("Weld", Helmet)
weld.Part1 = Helmet
weld.Part0 = owner.Character.Head
weld.C0 = CFrame.new(0,.15,0)

local backpackM = Instance.new("Part", owner.Character:FindFirstChild("Torso") or owner.Character:FindFirstChild("UpperTorso"))
backpackM.Size = Vector3.new(1.75,1.75,1.1)
backpackM.Color = Color3.fromRGB(207,90,0)
backpackM.CanCollide = false
backpackM.Massless = true

local mesh = Instance.new("SpecialMesh", backpackM)
mesh.MeshId = 'rbxasset://Fonts//Torso.mesh'
mesh.MeshType = 'FileMesh'
mesh.Scale = Vector3.new(.75,1,1)

weld = Instance.new("Weld", backpackM)
weld.Part1 = backpackM
weld.Part0 = owner.Character:FindFirstChild("Torso") or owner.Character:FindFirstChild("UpperTorso")
weld.C0 = CFrame.new(0,0,1) * CFrame.Angles(0,math.rad(180),0)

local backpack = Instance.new("Part", owner.Character:FindFirstChild("Torso") or owner.Character:FindFirstChild("UpperTorso"))
backpack.Size = Vector3.new(1.75,1.75,1)
backpack.BrickColor = BrickColor.new("Really black")
backpack.CanCollide = false
backpack.Massless = true

local mesh = Instance.new("SpecialMesh", backpack)
mesh.MeshId = 'rbxasset://Fonts//Torso.mesh'
mesh.MeshType = 'FileMesh'
mesh.Scale = Vector3.new(.8,.1,1.05)

weld = Instance.new("Weld", backpack)
weld.Part1 = backpack
weld.Part0 = owner.Character:FindFirstChild("Torso") or owner.Character:FindFirstChild("UpperTorso")
weld.C0 = CFrame.new(0,.75,1)

local backpack = Instance.new("Part", owner.Character:FindFirstChild("Torso") or owner.Character:FindFirstChild("UpperTorso"))
backpack.Size = Vector3.new(1.75,1.75,1)
backpack.BrickColor = BrickColor.new("Really black")
backpack.CanCollide = false
backpack.Massless = true

local mesh = Instance.new("SpecialMesh", backpack)
mesh.MeshId = 'rbxasset://Fonts//Torso.mesh'
mesh.MeshType = 'FileMesh'
mesh.Scale = Vector3.new(.8,.1,1.05)

weld = Instance.new("Weld", backpack)
weld.Part1 = backpack
weld.Part0 = owner.Character:FindFirstChild("Torso") or owner.Character:FindFirstChild("UpperTorso")
weld.C0 = CFrame.new(0,-.75,1)

local max02 = 30000
local Current02 = max02
local o2_usage = 10

local gui = Instance.new("SurfaceGui", backpackM)
local tb = Instance.new("TextBox", gui)
tb.Size = UDim2.new(1,0,1,0)
tb.BackgroundTransparency = 1
tb.TextScaled = true
tb.Text = 'Oxygen Levels: '..[[

]]..Current02..'/'..max02..[[

(]]..(Current02/max02*100)..'%)'

while true do
task.wait(1/o2_usage)
Current02 = math.clamp(Current02-1,0,max02)

tb.Text = 'Oxygen Levels: '..[[

]]..Current02..'/'..max02..[[

(]]..math.round((Current02/max02*100))..'%)'

if math.round((Current02/max02*100)) < 10 then
owner.Character.Humanoid.WalkSpeed = 16
owner.Character.Humanoid.JumpPower = 90

else
owner.Character.Humanoid.WalkSpeed = 30
owner.Character.Humanoid.JumpPower = 75
end

end