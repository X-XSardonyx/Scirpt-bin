for i,v in pairs(owner.Character:GetDescendants()) do
if v:IsA("Motor6D") then
local weld = Instance.new("Weld", v.Parent)
weld.Part1 = v.Part1
weld.Part0 = v.Part0
weld.C0 = v.C0
weld.C1 = v.C1
weld.Name = v.Name
v:Destroy()
end
end

Attack = false

script.Parent = owner.Character

--Anim Defaults
AnimDefaults = {
Head = owner.Character.Torso.Neck.C0,
Torso = owner.Character.HumanoidRootPart.RootJoint.C0,
Larm = owner.Character.Torso["Left Shoulder"].C0,
Rarm = owner.Character.Torso["Right Shoulder"].C0,
Lleg = owner.Character.Torso["Left Hip"].C0,
Rleg = owner.Character.Torso["Right Hip"].C0
}
--Setting Joints
Head = owner.Character.Torso.Neck
Torso = owner.Character.HumanoidRootPart.RootJoint
Larm = owner.Character.Torso["Left Shoulder"]
Rarm = owner.Character.Torso["Right Shoulder"]
Lleg = owner.Character.Torso["Left Hip"]
Rleg = owner.Character.Torso["Right Hip"]


--Idle

game:GetService("RunService").Heartbeat:Connect(function()
if owner.Character.HumanoidRootPart.Velocity.Magnitude < .1 then
Torso.C0 = Torso.C0:Lerp(AnimDefaults.Torso * CFrame.new(0,0,math.sin(tick() / 5) / 5) * CFrame.Angles(math.rad(math.random(-2,2)),math.rad(math.random(-2,2)),math.rad(math.random(-2,2))), .5)
Head.C0 = Head.C0:Lerp(AnimDefaults.Head * CFrame.Angles(math.rad(math.random(-5,5)),math.rad(math.random(-5,5)),math.rad(math.random(-5,5))), .5)
Larm.C0 = Larm.C0:Lerp(AnimDefaults.Larm * CFrame.new(0,0,0) * CFrame.Angles(math.rad(-15),0,0) * CFrame.Angles(math.rad(math.random(-5,5)),math.rad(math.random(-5,5)),math.rad(math.random(-5,5))), .5)
Rarm.C0 = Rarm.C0:Lerp(AnimDefaults.Rarm * CFrame.new(0,0,0) * CFrame.Angles(math.rad(-15),0,0) * CFrame.Angles(math.rad(math.random(-5,5)),math.rad(math.random(-5,5)),math.rad(math.random(-5,5))), .5)
Lleg.C0 = Lleg.C0:Lerp(AnimDefaults.Lleg * CFrame.Angles(0,math.rad(15),0) * CFrame.Angles(math.rad(math.random(-5,5)),math.rad(math.random(-5,5)),math.rad(math.random(-5,5))), .5)
Rleg.C0 = Rleg.C0:Lerp(AnimDefaults.Rleg * CFrame.Angles(0,0,math.rad(0)) * CFrame.Angles(math.rad(math.random(-5,5)),math.rad(math.random(-5,5)),math.rad(math.random(-5,5))), .5)
end
end)

game:GetService("RunService").Heartbeat:Connect(function()
if owner.Character.HumanoidRootPart.Velocity.X ~= 0 or owner.Character.HumanoidRootPart.Velocity.Z ~= 0 and owner.Character.HumanoidRootPart.Velocity.Y < .1 and mode == 1  then
Torso.C0 = Torso.C0:Lerp(AnimDefaults.Torso * CFrame.Angles(math.rad(math.random(-5,5)),math.rad(math.random(-5,5)),math.rad(math.random(-5,5))), .5)
Lleg.C0 = Lleg.C0:Lerp(AnimDefaults.Lleg * CFrame.Angles(0,0,math.rad(math.sin(tick() * 5) * 30)) * CFrame.Angles(math.rad(math.random(-5,5)),math.rad(math.random(-5,5)),math.rad(math.random(-5,5))), .5)
Rleg.C0 = Rleg.C0:Lerp(AnimDefaults.Rleg * CFrame.Angles(0,0,math.rad(math.sin(tick() * 5) * 30)) * CFrame.Angles(math.rad(math.random(-5,5)),math.rad(math.random(-5,5)),math.rad(math.random(-5,5))), .5)
Rarm.C0 = Rarm.C0:Lerp(AnimDefaults.Rarm * CFrame.Angles(0,0,math.rad(-math.sin(tick() * 5) * 30)) * CFrame.Angles(math.rad(math.random(-5,5)),math.rad(math.random(-5,5)),math.rad(math.random(-5,5))), .5)
Larm.C0 = Larm.C0:Lerp(AnimDefaults.Larm * CFrame.Angles(0,0,math.rad(-math.sin(tick() * 5) * 30)) * CFrame.Angles(math.rad(math.random(-5,5)),math.rad(math.random(-5,5)),math.rad(math.random(-5,5))), .5)
Head.C0 = Head.C0:Lerp(AnimDefaults.Head * CFrame.Angles(math.rad(math.random(-5,5)),math.rad(math.random(-5,5)),math.rad(math.random(-5,5))), .5)
end
end)