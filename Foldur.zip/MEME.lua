function(BOTTOMTEXT, id, MUSIC)
local memescreen = Instance.new("Part", workspace)
memescreen.Size = Vector3.new(10,10,0)
memescreen.CanCollide = false
memescreen.Anchored = true
memescreen.Material = 'SmoothPlastic'
memescreen.BrickColor = BrickColor.new("Institutional white")
memescreen.Locked = true
memescreen.CFrame = CFrame.new(0,5,10)

local sound = Instance.new("Sound", memescreen)
sound.SoundId = 'rbxassetid://'..MUSIC
sound.Volume = 2
sound.Looped = true
sound.MaxDistance = 50
sound:Play()

local gui = Instance.new("SurfaceGui", memescreen)

local bottomtext = Instance.new("TextBox", gui)
bottomtext.Position = UDim2.new(0,0,.75,0)
bottomtext.Size = UDim2.new(1,0,.25,0)
bottomtext.BackgroundColor3 = BrickColor.new("Really black").Color
bottomtext.BorderSizePixel = 0
bottomtext.ZIndex = 2
bottomtext.TextScaled = true
bottomtext.TextColor = BrickColor.new("Institutional white")
bottomtext.Text = BOTTOMTEXT


local topbar = Instance.new("Frame", gui)
topbar.Position = UDim2.new(0,0,0,0)
topbar.Size = UDim2.new(1,0,.1,0)
topbar.BackgroundColor3 = BrickColor.new("Really black").Color
topbar.BorderSizePixel = 0

local leftbar = Instance.new("Frame", gui)
leftbar.Position = UDim2.new(0,0,0,0)
leftbar.Size = UDim2.new(.1,0,1,0)
leftbar.BackgroundColor3 = BrickColor.new("Really black").Color
leftbar.BorderSizePixel = 0

local rightbar = Instance.new("Frame", gui)
rightbar.Position = UDim2.new(.9,0,0,0)
rightbar.Size = UDim2.new(.1,0,1,0)
rightbar.BackgroundColor3 = BrickColor.new("Really black").Color
rightbar.BorderSizePixel = 0


local meme = Instance.new("ImageLabel", gui)
meme.Image = 'rbxassetid://'..id
meme.Position = UDim2.new(.1,0,.1,0)
meme.Size = UDim2.new(.8,0,.65,0)

end

meme("Bad Ending: Everything was deleted and all that was left was a void", 7202143730, 7201796207)