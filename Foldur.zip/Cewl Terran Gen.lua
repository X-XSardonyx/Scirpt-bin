local seed = math.random()
local w = 30
local h = 50
local grid = 40
local gridsize = 4
local offset = CFrame.new(Vector3.new(0,40,-200))
waterlevel = -3

local grass = {"Sand", {BrickColor.new("Camo"), BrickColor.new("Dark green"), BrickColor.new("Forest green"), BrickColor.new("Shamrock")}}

print(seed)

for z = 1,grid do
wait()
for x = 1,grid do
local block = Instance.new("SpawnLocation", script)
block.Size = Vector3.new(gridsize,gridsize,gridsize)
block.Enabled = false
block.Anchored = true

local y = math.sin(math.noise(seed,x/w,z/w)) * h

block.CFrame = offset * CFrame.new(x*gridsize,y,z*gridsize)

if y> 5 then
block.BrickColor= grass[2][math.random(1,#grass[2])]
block.Material = grass[1]

if math.random(-15,15) == 15 then
bark = Instance.new("SpawnLocation", script)
bark.Size = Vector3.new(block.Size.X/3,block.Size.X*gridsize,block.Size.Z/3)
bark.Enabled = false
bark.Material = 'Wood'
bark.Anchored = true
bark.BrickColor = BrickColor.new("CGA brown")
bark.CFrame = block.CFrame * CFrame.new(0,bark.Size.Y/2,0) * CFrame.Angles(0,math.rad(math.random(-360,360)),0)

for i = 1,math.random(2,5) do
local bush = Instance.new("SpawnLocation", script)
bush.Size = Vector3.new(block.Size.X*2,block.Size.X*2,block.Size.X*2)
bush.Material = 'Grass'
bush.CanCollide = false
bush.Enabled = false
bush.Anchored = true
bush.Transparency = .25
bush.BrickColor = grass[2][math.random(1,#grass[2])]
bush.CFrame = bark.CFrame * CFrame.new(0,bark.Size.Y/2,0) * CFrame.Angles(math.rad(math.random(-360,360)),math.rad(math.random(-360,360)),math.rad(math.random(-360,360)))

end
end

elseif y < 5 then
block.Material = 'Sand'
block.Color = BrickColor.new("Pastel brown").Color:Lerp(BrickColor.new("Really black").Color, y%1/10)

if math.random(-20,20) == 20 then
for i = 1,math.random(1,3) do
stone = Instance.new("SpawnLocation", script)
siz = math.random(0,5)
stone.Size = Vector3.new(block.Size.X/siz,block.Size.Y/siz,block.Size.Z/siz)
stone.Enabled = false
stone.Material = 'Slate'
stone.Anchored = true
stone.Color = BrickColor.new("Pearl").Color:Lerp(BrickColor.new("Really black").Color, math.random(1,10)/15)
stone.CFrame = block.CFrame * CFrame.new(0,stone.Size.Y-(siz/2),0)
stone.CFrame = stone.CFrame  * CFrame.Angles(math.rad(math.random(-360,360)),math.rad(math.random(-360,360)),math.rad(math.random(-360,360)))
end
end
end

end
end
local water = Instance.new("SpawnLocation", script)
water.Size = Vector3.new(grid * gridsize,2,grid * gridsize)
water.Anchored = true
water.CanCollide = false
water.CFrame = offset * CFrame.new(grid*gridsize/2,waterlevel,grid*gridsize/2)
water.Material = 'Glass'
water.Color = BrickColor.new("Really blue").Color
water.Transparency = .75
water.Reflectance = .5

sine = 1

game:GetService("RunService").Heartbeat:Connect(function()
sine = sine + 1
water.CFrame = offset * CFrame.new(grid*gridsize/2,waterlevel,grid*gridsize/2) * CFrame.Angles(math.rad(math.sin(sine/30)),0,math.rad(math.cos(sine/30)))
end)