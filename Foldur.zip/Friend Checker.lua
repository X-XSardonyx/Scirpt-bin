local astro = Instance.new("Part", script)
astro.Size = Vector3.new(10,10,0)
astro.CanCollide = false
astro.Anchored = true
astro.CFrame = CFrame.new(0,5,-10)
astro.Material = 'SmoothPlastic'
astro.BrickColor = BrickColor.new("Institutional white")
astro.Locked = true
local gui = Instance.new("SurfaceGui", astro)

local recieve = Instance.new("RemoteEvent", owner.PlayerGui)
recieve.Name = 'GETFRIENDS'

NLS("owner.PlayerGui.GETFRIENDS:FireServer(owner:GetFriendsOnline())  while wait(5) do owner.PlayerGui.GETFRIENDS:FireServer(owner:GetFriendsOnline()) end", owner.PlayerGui)


recieve.OnServerEvent:Connect(function(plr ,data)
gui:ClearAllChildren()
for i,person in pairs(data) do
local frame = Instance.new("TextBox", gui)
frame.Size = UDim2.new(1,0,0,30)
frame.Position = UDim2.new(0,0,0,30 * (i - 1))
frame.BackgroundTransparency = 1
frame.TextXAlignment = 'Left'
frame.TextSize = 15
frame.Text = person.DisplayName

local char = Instance.new("TextBox", frame)
char.Text = 'User ID: ['..person.VisitorId..']'
char.Position = UDim2.new(.75,0,0,0)
char.Size = UDim2.new(.25,0,1,0)
char.TextScaled = true
char.BackgroundTransparency = 1

local char = Instance.new("TextBox", frame)
char.Text = 'User Name: ['..person.UserName..']'
char.Position = UDim2.new(.5,0,0,0)
char.Size = UDim2.new(.25,0,1,0)
char.TextScaled = true
char.BackgroundTransparency = 1

local char = Instance.new("TextBox", frame)
char.Text = 'Last Online: ['..person.LastOnline..']'
char.Position = UDim2.new(.25,0,0,0)
char.Size = UDim2.new(.25,0,1,0)
char.TextScaled = true
char.BackgroundTransparency = 1

wait()

end
end)

