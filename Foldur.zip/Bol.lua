local ball = Instance.new("Part", script)
ball.Size = Vector3.new(10,10,10)
ball.Locked = true
ball.Material = 'SmoothPlastic'
ball.Reflectance = 1
ball.CFrame = owner.Character.HumanoidRootPart.CFrame
ball.Shape = 'Ball'

local event = Instance.new("RemoteEvent", owner.Backpack)
local mousepos = Instance.new("RemoteEvent", owner.Backpack)
mousepos.Name = 'MOUSEPOS'

Instance.new("ObjectValue", owner.Backpack).Value = ball

local rot = Instance.new("Part", script)
rot.Size = Vector3.new(0,0,0)
rot.Locked = true
rot.Transparency = 1
rot.CanCollide = false
rot.Anchored = true

local rope = Instance.new("RopeConstraint", rot)
rope.Attachment0 = Instance.new("Attachment", ball)
rope.Attachment1 = Instance.new("Attachment", rot)
rope.Visible = true
rope.Color = BrickColor.new("Pearl")
rope.Length = ball.Size.X * 10
rope.Enabled = false
rope.Thickness = ball.Size.X / 2

owner.Character.Parent = game.Lighting


NLS('workspace.CurrentCamera.CameraSubject = owner.Backpack.Value.Value local event = owner.Backpack.RemoteEvent local hum = owner.Character.Humanoid while wait(1/30) do event:FireServer(hum.MoveDirection) end', owner.Backpack)

NLS('local event = owner.Backpack.MOUSEPOS owner:GetMouse().Button1Down:Connect(function() event:FireServer("down", owner:GetMouse().Hit.Position)  end) owner:GetMouse().Button1Up:Connect(function() event:FireServer("up", owner:GetMouse().Hit.Position)  end)', owner.Backpack)

event.OnServerEvent:Connect(function(plr, speed)
ball.Velocity = ball.Velocity + speed * 10
end)

mousepos.OnServerEvent:Connect(function(plr, direction, pos)
if direction == 'down' then
rot.Position = pos
rope.Enabled = true
elseif direction == 'up' then
rot.Position = pos
rope.Enabled = false

end
end)