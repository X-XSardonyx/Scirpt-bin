local object = workspace.MODEL

local start = [[model = Instance.new("Model", script)


function part(shape,anchored, transparency, size, cframe, color, locked, cancollide,material, name)

local prt = Instance.new("Part", model)
prt.Size = size
prt.Anchored = anchored
prt.CanCollide = cancollide
prt.Locked = locked
prt.Shape = shape
prt.Transparency = transparency
prt.Size = size
prt.Color = color
prt.CFrame = cframe
prt.Material = material
prt.Name = name
end

function wedge(anchored, transparency, size, cframe, color, locked, cancollide, material, name)

local prt = Instance.new("WedgePart", model)
prt.Size = size
prt.Anchored = anchored
prt.CanCollide = cancollide
prt.Locked = locked
prt.Transparency = transparency
prt.Size = size
prt.Color = color
prt.CFrame = cframe
prt.Material = material
prt.Name = name
end

function corner(anchored, transparency, size, cframe, color, locked, cancollide, material, name)

local prt = Instance.new("CornerWedgePart", model)
prt.Size = size
prt.Anchored = anchored
prt.CanCollide = cancollide
prt.Locked = locked
prt.Transparency = transparency
prt.Size = size
prt.Color = color
prt.CFrame = cframe
prt.Material = material
prt.Name = name
end

function seat(anchored, transparency, size, cframe, color, locked, cancollide, material, name)

local prt = Instance.new("Seat", model)
prt.Size = size
prt.Anchored = anchored
prt.CanCollide = cancollide
prt.Locked = locked
prt.Transparency = transparency
prt.Size = size
prt.Color = color
prt.CFrame = cframe
prt.Material = material
prt.Name = name
end

function truss(anchored, transparency, size, cframe, color, locked, cancollide, material, name)
local prt = Instance.new("TrussPart", model)
prt.Size = size
prt.Anchored = anchored
prt.CanCollide = cancollide
prt.Locked = locked
prt.Transparency = transparency
prt.Size = size
prt.Color = color
prt.CFrame = cframe
prt.Material = material
prt.Name = name
end]]

for i,v in pairs(object:GetDescendants()) do
if v:IsA("Part") then
start = start..[[

part(]]

start = start..'"'..v.Shape.Name..'",'
if v.Anchored then 
start = start..'true'
else
start = start..'false'
end

start = start..','..v.Transparency..',Vector3.new('..v.Size.X..','..v.Size.Y..','..v.Size.Z..'),CFrame.new('..v.Position.X..','..v.Position.Y..','..v.Position.Z..') * CFrame.Angles(math.rad('..v.Orientation.X..'),math.rad('..v.Orientation.Y..'),math.rad('..v.Orientation.Z..'))'..','..'Color3.new('..v.Color.R..','..v.Color.G..','..v.Color.B..')'

if v.Locked then 
start = start..',true'
else
start = start..',false'
end

if v.CanCollide then 
start = start..',true,'
else
start = start..',false,'
end


start = start..'"'..v.Material.Name..'","'..v.Name..'")'

elseif v:IsA("WedgePart") then
start = start..[[

wedge(]]

if v.Anchored then 
start = start..'true'
else
start = start..'false'
end

start = start..','..v.Transparency..',Vector3.new('..v.Size.X..','..v.Size.Y..','..v.Size.Z..'),CFrame.new('..v.Position.X..','..v.Position.Y..','..v.Position.Z..') * CFrame.Angles(math.rad('..v.Orientation.X..'),math.rad('..v.Orientation.Y..'),math.rad('..v.Orientation.Z..'))'..','..'Color3.new('..v.Color.R..','..v.Color.G..','..v.Color.B..')'

if v.Locked then 
start = start..',true'
else
start = start..',false'
end

if v.CanCollide then 
start = start..',true,'
else
start = start..',false,'
end

start = start..'"'..v.Material.Name..'","'..v.Name..'")'

elseif v:IsA("CornerWedgePart") then
start = start..[[

corner(]]

if v.Anchored then 
start = start..'true'
else
start = start..'false'
end

start = start..','..v.Transparency..',Vector3.new('..v.Size.X..','..v.Size.Y..','..v.Size.Z..'),CFrame.new('..v.Position.X..','..v.Position.Y..','..v.Position.Z..') * CFrame.Angles(math.rad('..v.Orientation.X..'),math.rad('..v.Orientation.Y..'),math.rad('..v.Orientation.Z..'))'..','..'Color3.new('..v.Color.R..','..v.Color.G..','..v.Color.B..')'

if v.Locked then 
start = start..',true'
else
start = start..',false'
end

if v.CanCollide then 
start = start..',true,'
else
start = start..',false,'
end

start = start..'"'..v.Material.Name..'","'..v.Name..'")'


elseif v:IsA("Seat") then
start = start..[[

seat(]]

if v.Anchored then 
start = start..'true'
else
start = start..'false'
end

start = start..','..v.Transparency..',Vector3.new('..v.Size.X..','..v.Size.Y..','..v.Size.Z..'),CFrame.new('..v.Position.X..','..v.Position.Y..','..v.Position.Z..') * CFrame.Angles(math.rad('..v.Orientation.X..'),math.rad('..v.Orientation.Y..'),math.rad('..v.Orientation.Z..'))'..','..'Color3.new('..v.Color.R..','..v.Color.G..','..v.Color.B..')'

if v.Locked then 
start = start..',true'
else
start = start..',false'
end

if v.CanCollide then 
start = start..',true,'
else
start = start..',false,'
end

start = start..'"'..v.Material.Name..'","'..v.Name..'")'

elseif v:IsA("TrussPart") then
start = start..[[

truss(]]

if v.Anchored then 
start = start..'true'
else
start = start..'false'
end

start = start..','..v.Transparency..',Vector3.new('..v.Size.X..','..v.Size.Y..','..v.Size.Z..'),CFrame.new('..v.Position.X..','..v.Position.Y..','..v.Position.Z..') * CFrame.Angles(math.rad('..v.Orientation.X..'),math.rad('..v.Orientation.Y..'),math.rad('..v.Orientation.Z..'))'..','..'Color3.new('..v.Color.R..','..v.Color.G..','..v.Color.B..')'

if v.Locked then 
start = start..',true'
else
start = start..',false'
end

if v.CanCollide then 
start = start..',true,'
else
start = start..',false,'
end

start = start..'"'..v.Material.Name..'","'..v.Name..'")'


end
end


local gui = Instance.new("ScreenGui", script)

local frame = Instance.new("TextBox", gui)
frame.Size = UDim2.new(.25,0,.25,0)
frame.Position = UDim2.new(0,0,.5,0)
frame.TextEditable = false
frame.TextScaled = true
frame.Text = start
frame.ClearTextOnFocus = false