--mesh = 4718140957
--music = 5123974898

local loudness = 10


local toilet = Instance.new("Part", script)
local light = Instance.new("PointLight", toilet)
local weld = Instance.new("Weld", toilet)
local sound = Instance.new("Sound", owner.Character.HumanoidRootPart)
light.Range = 30
light.Brightness = 5
sound.MaxDistance = 100
sound.Volume = 5
sound.SoundId = 'rbxassetid://610086544 '
sound.Looped = true
sound:Play()
toilet.Size = Vector3.new(8,8,8)
toilet.CanCollide = false
toilet.Massless = true
toilet.Material = 'SmoothPlastic'
toilet.CastShadow = false

weld.Part1 = toilet
weld.Part0 = owner.Character.HumanoidRootPart
weld.C0 = CFrame.new(0,15,0)

local name = Instance.new("BillboardGui", toilet)
name.Size = UDim2.fromScale(2,4)
name.StudsOffset = Vector3.new(0,10,0)
name.MaxDistance = 200
local tb = Instance.new("TextBox", name)
tb.Size = UDim2.new(1,0,1,0)
tb.BackgroundTransparency = 1
tb.TextSize = 15
tb.TextYAlignment = 'Top'
tb.TextColor = BrickColor.White()
tb.Text = '😳 Block 😳'

local shell = Instance.new("Part", toilet)
shell.Size = Vector3.new(10,10,10)
shell.CanCollide = false
shell.Massless = true
shell.Material = 'ForceField'
shell.Color = toilet.Color
shell.CastShadow = false

local weld1 = Instance.new("Weld", shell)
weld1.Part1 = shell
weld1.Part0 = toilet


game:GetService("RunService").Heartbeat:Connect(function()
weld.C0 = weld.C0 * CFrame.Angles(0,math.rad(5),0)
weld1.C0 = weld1.C0 * CFrame.Angles(0,math.rad(-10),0)
toilet.Size = toilet.Size:Lerp(Vector3.new(loudness / 50,loudness / 50,loudness / 50), .1)
shell.Size = toilet.Size + Vector3.new(3,3,3)
end)

local NLS = NLS([[
local sound = owner.Character.HumanoidRootPart.Sound
local rem = script:WaitForChild("RemoteEvent")
while wait(1/30) do
rem:FireServer(sound.PlaybackLoudness)
end
]], owner.PlayerGui)

local rem = Instance.new("RemoteEvent", NLS)

rem.OnServerEvent:Connect(function(plr, VOL)
loudness = VOL
end)