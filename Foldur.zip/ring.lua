local num = 10

val = Instance.new("ObjectValue", owner.Character)

val.Value = script

parts = {}

sound = Instance.new("Sound", owner.Character.HumanoidRootPart)
sound.SoundId = 'rbxassetid://743466274'
sound.MaxDistance = 100
sound.Volume = 2
sound.Looped = true
sound:Play()

for i = 1,num do
local part = Instance.new("Part", script)
part.CanCollide = false
part.Material = 'SmoothPlastic'
part.Size = Vector3.new(5,1,1)
part.CFrame = CFrame.new(0,100000,0)
part:SetNetworkOwner(owner)

local att1 = Instance.new("Attachment", part)
local att2 = Instance.new("Attachment", part)

att1.CFrame = CFrame.new(2.5,0,0)
att2.CFrame = CFrame.new(-2.5,0,0)

local trail = Instance.new("Trail", part)
trail.Attachment1 = att1
trail.Attachment0 = att2
trail.Texture = 'rbxassetid://'..7509141236
trail.Lifetime = 1
table.insert(parts, part)

end

NLS([[

sound = owner.Character.HumanoidRootPart.Sound
model = script.Parent.Value

amplify = 1
spin_speed = 1

for i,v in pairs(model:GetChildren()) do

local pos = Instance.new("BodyPosition", v)
pos.MaxForce = Vector3.new(math.huge,math.huge,math.huge)
pos.P = 150000
pos.D = 1000

local gy = Instance.new("BodyGyro", v)
gy.MaxTorque= Vector3.new(math.huge,math.huge,math.huge)
gy.P = 150000
gy.D = 1000

circle = 2*math.pi

siz = Vector3.new(1,1,1)

spin = 1

game:GetService("RunService").RenderStepped:Connect(function()

spin = spin + spin_speed/100

siz = siz:Lerp(Vector3.new(sound.PlaybackLoudness,sound.PlaybackLoudness,sound.PlaybackLoudness), .01)

X = math.sin(i*(circle/#model:GetChildren())+spin)*((siz.X/20)*amplify)
Z = math.cos(i*(circle/#model:GetChildren())+spin)*((siz.X/20)*amplify)

CF = CFrame.new(owner.Character.HumanoidRootPart.Position + Vector3.new(X,0,Z),owner.Character.HumanoidRootPart.Position)

pos.Position = CF.Position
gy.CFrame = CF

end)

end

owner.Chatted:Connect(function(msg)
local message = string.split(msg, ' ')
if string.lower(message[1]) =='-amplify' then
amplify = message[2]
elseif string.lower(message[1]) =='-spin' then
spin_speed = message[2]
end
end)

]],val)

owner.Chatted:Connect(function(msg)
local message = string.split(msg, ' ')
if string.lower(message[1]) =='-music' then
sound:Stop()
sound.SoundId = 'rbxassetid://'..message[2]
sound:Play()
elseif string.lower(message[1]) =='-volume' then
sound.Volume = message[2]
elseif string.lower(message[1]) =='-pitch' then
sound.Pitch = message[2]
end
end)