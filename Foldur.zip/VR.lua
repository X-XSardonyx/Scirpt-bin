local joint1 = Instance.new("Part", script)
joint1.Anchored = true
joint1.CanCollide = false
joint1.Transparency = 1
joint1.Size = Vector3.new(0,0,0)

local joint2 = Instance.new("Part", script)
joint2.Anchored = true
joint2.CanCollide = false
joint2.Transparency = 1
joint2.Size = Vector3.new(0,0,0)

local newbody = Instance.new("Model", script)

owner.Character["Left Arm"]:Destroy()
owner.Character["Right Arm"]:Destroy()

local LEFTARM = Instance.new("Part", newbody)
LEFTARM.Size = Vector3.new(1,2,1)
LEFTARM.BrickColor = owner.Character:FindFirstChildWhichIsA("BodyColors").LeftArmColor
LEFTARM.Material = 'SmoothPlastic'
LEFTARM.Name = 'Left Arm'
LEFTARM.CanCollide = false

local RIGHTARM = Instance.new("Part", newbody)
RIGHTARM.Size = Vector3.new(1,2,1)
RIGHTARM.BrickColor = owner.Character:FindFirstChildWhichIsA("BodyColors").RightArmColor
RIGHTARM.Material = 'SmoothPlastic'
RIGHTARM.Name = 'Right Arm'
RIGHTARM.CanCollide = false

Instance.new("Humanoid", newbody)

if owner.Character:FindFirstChildWhichIsA("Shirt") then
owner.Character:FindFirstChildWhichIsA("Shirt"):Clone().Parent = newbody
end


local weld = Instance.new("Weld", joint1)
weld.Part1 = LEFTARM
weld.Part0 = joint1
weld.C0 = CFrame.new(0,-1,-1) * CFrame.Angles(math.rad(90),0,0)

local weld2 = Instance.new("Weld", joint2)
weld2.Part1 = RIGHTARM
weld2.Part0 = joint2
weld2.C0 = CFrame.new(0,-1,-1) * CFrame.Angles(math.rad(90),0,0)

local rem = Instance.new("RemoteEvent", owner.PlayerGui)
rem.Name = 'ARMS'

NLS("local event = owner.PlayerGui.ARMS local mouse = owner:GetMouse() while wait(1/30) do event:FireServer(mouse.Hit.Position) end", owner.PlayerGui)

rem.OnServerEvent:Connect(function(plr, pos)

joint1.Position = owner.Character.HumanoidRootPart.CFrame * CFrame.new(-1.25,1.5,0).Position
joint1.CFrame = joint1.CFrame:Lerp(CFrame.new(joint1.Position, pos),.25)

joint2.Position = owner.Character.HumanoidRootPart.CFrame * CFrame.new(1.25,1.5,0).Position
joint2.CFrame = joint2.CFrame:Lerp(CFrame.new(joint2.Position, pos),.25)

end)

