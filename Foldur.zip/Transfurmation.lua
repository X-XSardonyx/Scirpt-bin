script.Parent = workspace
script.Name = 'TRANS_FUR_MATION BY X_XSARDONYX'

local ts = game:GetService("TweenService")
local transformspeed = TweenInfo.new(1)

local COLOR = BrickColor.new("Deep orange")
local MATERIAL = 'SmoothPlastic'

local puddle = Instance.new("Part", script)
puddle.Parent = script
puddle.Size = Vector3.new(.1,5,5)
puddle.Material = 'SmoothPlastic'
puddle.BrickColor = COLOR
puddle.Shape = 'Cylinder'
puddle.CFrame = workspace.Baseplate.CFrame * CFrame.new(0,workspace.Baseplate.Size.Y / 2,0) * CFrame.Angles(0,0,math.rad(90))
puddle.Anchored = true
puddle.CanCollide = false

puddle.Touched:Connect(function(hit)

if game:GetService("Players"):GetPlayerFromCharacter(hit.Parent) then
if not hit.Parent:FindFirstChild("TFMDONE") and hit.Parent:FindFirstChildWhichIsA("Humanoid").RigType == Enum.HumanoidRigType.R6 then
Instance.new("BoolValue", hit.Parent).Name = 'TFMDONE'

if hit.Parent.HumanoidRootPart:FindFirstChild("WELDGRAB") then
hit.Parent.HumanoidRootPart:FindFirstChild("WELDGRAB"):Destroy()
end

for i,v in pairs(hit.Parent:GetChildren()) do
if v.ClassName == 'Hat' or v.ClassName == 'Accessory' or v.ClassName == 'CharacterMesh' then
v:Destroy()
end
end

local part1 = Instance.new("Part", hit.Parent["Left Leg"])
local part2 = Instance.new("Part", hit.Parent["Right Leg"])
part1.Size = Vector3.new(part1.Parent.Size.X + .1,0,part1.Parent.Size.Z+ .1)
part1.BrickColor = puddle.BrickColor
part1.CanCollide = false
part1.Material = 'SmoothPlastic'
local weld1 = Instance.new("Weld", part1)
weld1.Part1 = part1.Parent
weld1.Part0 = part1
weld1.C0 = CFrame.new(0,1,0)

part2.Size = Vector3.new(part1.Parent.Size.X + .1,0,part1.Parent.Size.Z+ .1)
part2.BrickColor = puddle.BrickColor
part2.CanCollide = false
part2.Material = 'SmoothPlastic'
local weld2 = Instance.new("Weld", part2)
weld2.Part1 = part2.Parent
weld2.Part0 = part2
weld2.C0 = CFrame.new(0,1,0)

for j = 1,50 do

ts:Create(part1, transformspeed, {Size = part1.Parent.Size + Vector3.new(.01,.01,.01)}):Play()
ts:Create(weld1, transformspeed, {C0 = CFrame.new(0,0,0)}):Play()

ts:Create(part2, transformspeed, {Size = part2.Parent.Size + Vector3.new(.01,.01,.01)}):Play()
ts:Create(weld2, transformspeed, {C0 = CFrame.new(0,0,0)}):Play()


wait()
end

local part3 = Instance.new("Part", hit.Parent.Torso)
part3.Size = Vector3.new(part3.Parent.Size.X + .1,0,part3.Parent.Size.Z+ .1)
part3.BrickColor = puddle.BrickColor
part3.CanCollide = false
part3.Material = 'SmoothPlastic'
local weld3 = Instance.new("Weld", part3)
weld3.Part1 = part3.Parent
weld3.Part0 = part3
weld3.C0 = CFrame.new(0,1,0)

for j = 1,50 do

ts:Create(part3, transformspeed, {Size = part3.Parent.Size + Vector3.new(.01,.01,.01)}):Play()
ts:Create(weld3, transformspeed, {C0 = CFrame.new(0,0,0)}):Play()

wait()
end

local part4 = Instance.new("Part", hit.Parent["Left Arm"])
part4.Size = Vector3.new(part4.Parent.Size.X + .1,0,part4.Parent.Size.Z+ .1)
part4.BrickColor = puddle.BrickColor
part4.CanCollide = false
part4.Material = 'SmoothPlastic'
local weld4 = Instance.new("Weld", part4)
weld4.Part1 = part4.Parent
weld4.Part0 = part4
weld4.C0 = CFrame.new(-.5,-1,0)

local part5 = Instance.new("Part", hit.Parent["Right Arm"])
part5.Size = Vector3.new(part5.Parent.Size.X + .1,0,part5.Parent.Size.Z+ .1)
part5.BrickColor = puddle.BrickColor
part5.CanCollide = false
part5.Material = 'SmoothPlastic'
local weld5 = Instance.new("Weld", part5)
weld5.Part1 = part5.Parent
weld5.Part0 = part5
weld5.C0 = CFrame.new(.5,-1,0)

for j = 1,50 do

ts:Create(part4, transformspeed, {Size = part4.Parent.Size + Vector3.new(.01,.01,.01)}):Play()
ts:Create(weld4, transformspeed, {C0 = CFrame.new(0,0,0)}):Play()

ts:Create(part5, transformspeed, {Size = part5.Parent.Size + Vector3.new(.01,.01,.01)}):Play()
ts:Create(weld5, transformspeed, {C0 = CFrame.new(0,0,0)}):Play()


wait()
end


local part6 = Instance.new("Part", hit.Parent["Head"])
part6.Size = Vector3.new(part6.Parent.Size.X + .1,0,part6.Parent.Size.Z+ .1)
part6.BrickColor = puddle.BrickColor
part6.CanCollide = false
part6.Material = 'SmoothPlastic'
local weld6 = Instance.new("Weld", part6)
weld6.Part1 = part6.Parent
weld6.Part0 = part6
weld6.C0 = CFrame.new(0,.5,0)

Instance.new("SpecialMesh", part6).Scale = Vector3.new(1.3,1.3,1.3)

Instance.new("Decal", part6).Texture = 'rbxassetid://1174493634'

for j = 1,50 do

ts:Create(part6, transformspeed, {Size = part6.Parent.Size + Vector3.new(.01,.01,.01)}):Play()
ts:Create(weld6, transformspeed, {C0 = CFrame.new(0,0,0)}):Play()

end

local Tail = Instance.new("Part", hit.Parent.Torso)
Tail.Size = Vector3.new(2,2,2)
Tail.CanCollide = false
Tail.BrickColor = puddle.BrickColor
local mesh = Instance.new("SpecialMesh", Tail)
mesh.MeshId = 'rbxassetid://4521910144'


local TAILWELD = Instance.new("Weld", Tail)
TAILWELD.Part1 = TAILWELD.Parent
TAILWELD.Part0 = TAILWELD.Parent.Parent
TAILWELD.C0 = CFrame.new(0,-1.5,1.5) * CFrame.Angles(0,math.rad(180),0)

--5437810334

local Ears = Instance.new("Part", hit.Parent.Head)
Ears.Size = Vector3.new(2,2,2)
Ears.CanCollide = false
Ears.BrickColor = puddle.BrickColor
local mesh = Instance.new("SpecialMesh", Ears)
mesh.MeshId = 'rbxassetid://5437810334'


local EARSWELD = Instance.new("Weld", Ears)
EARSWELD.Part1 = EARSWELD.Parent
EARSWELD.Part0 = EARSWELD.Parent.Parent
EARSWELD.C0 = CFrame.new(0,.75,0)

local ARM1 = Instance.new("Weld", hit.Parent["Left Arm"])
ARM1.Part1 = ARM1.Parent
ARM1.Part0 = hit.Parent.Torso
ARM1.C0 = hit.Parent.Torso["Left Shoulder"].C0
ARM1.C1 = hit.Parent.Torso["Left Shoulder"].C1

local ARM2 = Instance.new("Weld", hit.Parent["Right Arm"])
ARM2.Part1 = ARM2.Parent
ARM2.Part0 = hit.Parent.Torso
ARM2.C0 = hit.Parent.Torso["Right Shoulder"].C0
ARM2.C1 = hit.Parent.Torso["Right Shoulder"].C1

local ARM1C0 = ARM1.C0
local ARM2C0 = ARM2.C0

for i = 1,10 do

ARM1.C0 = ARM1.C0:Lerp(ARM1C0 * CFrame.Angles(0,math.rad(-25),math.rad(-50)), .125)
ARM2.C0 = ARM2.C0:Lerp(ARM2C0 * CFrame.Angles(0,math.rad(25),math.rad(50)), .125)

wait()

end

end
end

end)