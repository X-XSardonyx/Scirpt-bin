owner.Character.Parent = owner
local rem = Instance.new("RemoteEvent", owner.PlayerGui)
owner.Character.Humanoid.RequiresNeck = false
owner.Character.Humanoid.BreakJointsOnDeath = false


--489415447

for i,v in pairs(owner.Character:GetDescendants()) do
if v:IsA("BasePart") or v:IsA("Decal") then
v.Transparency = 1
end
end

--Effects

local effects = {}

local colors = {'Maroon', 'Persimmon', 'Really red'}
for i = 1,5 do
local orb = Instance.new("Part")
orb.Anchored = true
orb.Material = 'Glass'
orb.BrickColor = BrickColor.new(colors[math.random(1,#colors)])
orb.Size = Vector3.new(math.random(5,10) / 10,math.random(5,10) / 10,math.random(5,10) / 10)
orb.CanCollide = false
orb.Locked = true
orb.Shape = 'Ball'
table.insert(effects, orb)
end

for i = 1,5 do
local orb = Instance.new("WedgePart")
orb.Anchored = true
orb.Material = 'Glass'
orb.BrickColor = BrickColor.new(colors[math.random(1,#colors)])
orb.Size = Vector3.new(math.random(5,10) / 10,math.random(5,10) / 10,math.random(5,10) / 10)
orb.CanCollide = false
orb.Locked = true
table.insert(effects, orb)
end

for i = 1,5 do
local orb = Instance.new("Part")
orb.Anchored = true
orb.Material = 'Glass'
orb.Locked = true
orb.BrickColor = BrickColor.new(colors[math.random(1,#colors)])
orb.Size = Vector3.new(math.random(5,10) / 10,math.random(5,10) / 10,math.random(5,10) / 10)
orb.CanCollide = false
table.insert(effects, orb)
end

--MainScript :>

E = Instance.new("Folder", script)
E.Name = 'SUS'

local hum = Instance.new("Part", E)
hum.CanCollide = true
hum.Anchored = false
hum.Size = Vector3.new(2,2,1)
hum.Material = 'SmoothPlastic'
hum.Name = 'focus'
hum.BrickColor = BrickColor.Red()
hum.Locked = true
hum.Archivable = false
hum.Name = 'Torso'
hum.BrickColor = BrickColor.new("Really black")
hum.Transparency = 0

local head = Instance.new("Part", E)
head.CanCollide = false
head.Anchored = false
head.BrickColor = BrickColor.new("Really black")
head.Size = Vector3.new(1.25,1.25,1.25)
head.Material = 'SmoothPlastic'
head.Locked = true
head.Archivable = false
head.Name = 'Head'
head.Transparency = 0

local hmesh = Instance.new("SpecialMesh", head)
hmesh.Scale = Vector3.new(.025,.025,.025)
hmesh.MeshId = 'rbxassetid://6741699892'
hmesh.MeshType = 'FileMesh'

local fhead1 = Instance.new("Part", head)
fhead1.CanCollide = false
fhead1.Anchored = false
fhead1.BrickColor = BrickColor.new("Institutional white")
fhead1.Size = Vector3.new(1.25,1.25,1.25)
fhead1.Material = 'SmoothPlastic'
fhead1.Locked = true
fhead1.Archivable = false
fhead1.Name = ''
fhead1.Transparency = 0
fhead1:SetNetworkOwner(owner)
fhead1.Massless = true

local hmesh = Instance.new("SpecialMesh", fhead1)
hmesh.Scale = Vector3.new(.0225,.0225,.0225)
hmesh.MeshId = 'rbxassetid://6741699892'
hmesh.MeshType = 'FileMesh'

local weld = Instance.new("Weld", fhead1)
weld.Part1 = fhead1
weld.Part0 = head

local fhead2 = Instance.new("Part", head)
fhead2.CanCollide = false
fhead2.Anchored = false
fhead2.BrickColor = BrickColor.new("Really red")
fhead2.Size = Vector3.new(1.25,1.25,1.25)
fhead2.Material = 'SmoothPlastic'
fhead2.Locked = true
fhead2.Archivable = false
fhead2.Name = ''
fhead2.Transparency = 0
fhead2:SetNetworkOwner(owner)
fhead2.Massless = true

local hmesh = Instance.new("SpecialMesh", fhead2)
hmesh.Scale = Vector3.new(.02,.02,.02)
hmesh.MeshId = 'rbxassetid://6741699892'
hmesh.MeshType = 'FileMesh'

local weld = Instance.new("Weld", fhead2)
weld.Part1 = fhead2
weld.Part0 = head
weld.C0 = CFrame.Angles(0,math.rad(90),0)


local la = Instance.new("Part", E)
la.CanCollide = true
la.Anchored = false
la.Size = Vector3.new(1,2,1)
la.Material = 'SmoothPlastic'
la.Locked = true
la.Archivable = false
la.BrickColor = BrickColor.new("Really black")
la.Name = 'Left Arm'
la.Transparency = .0

local ra = Instance.new("Part", E)
ra.CanCollide = true
ra.Anchored = false
ra.Size = Vector3.new(1,2,1)
ra.Material = 'SmoothPlastic'
ra.BrickColor = BrickColor.new("Really black")
ra.Locked = true
ra.Archivable = false
ra.Name = 'Right Arm'
ra.Transparency = 0

local ll = Instance.new("Part", E)
ll.CanCollide = true
ll.Anchored = false
ll.BrickColor = BrickColor.new("Really black")
ll.Size = Vector3.new(1,2,1)
ll.Material = 'SmoothPlastic'
ll.Locked = true
ll.Archivable = false
ll.Name = 'Left Leg'
ll.Transparency = .0

local rl = Instance.new("Part", E)
rl.CanCollide = true
rl.Anchored = false
rl.Size = Vector3.new(1,2,1)
rl.BrickColor = BrickColor.new("Really black")
rl.Material = 'SmoothPlastic'
rl.Locked = true
rl.Archivable = false
rl.Name = 'Right Leg'
rl.Transparency = .0

local newvalue = Instance.new("ObjectValue", owner.Character)
newvalue.Value = script
newvalue.Name = 'OWO'


local sound = Instance.new("Sound", hum)
sound.MaxDistance = 100
sound.Looped = true
sound.SoundId = 'rbxassetid://5194389266'
sound.Pitch = .85
sound.Volume = 2
sound:Play()

for i,v in pairs(E:GetChildren()) do
if v:IsA("BasePart") then
v:SetNetworkOwner(owner)
v.CanCollide = false
end
end


NLS([[owner.Character.Parent = workspace 

for i,v in pairs(owner.Character:GetDescendants()) do
if v:IsA("Motor6D") then
local weld = Instance.new("Weld", v.Parent)
weld.Part1 = v.Part1
weld.Part0 = v.Part0
weld.C0 = v.C0
weld.C1 = v.C1
weld.Name = v.Name
v:Destroy()
end
end

script.Parent = owner.Character

--Anim Defaults
AnimDefaults = {
Head = owner.Character.Torso.Neck.C0,
Torso = owner.Character.HumanoidRootPart.RootJoint.C0,
Larm = owner.Character.Torso["Left Shoulder"].C0,
Rarm = owner.Character.Torso["Right Shoulder"].C0,
Lleg = owner.Character.Torso["Left Hip"].C0,
Rleg = owner.Character.Torso["Right Hip"].C0
}
--Setting Joints
Head = owner.Character.Torso.Neck
Torso = owner.Character.HumanoidRootPart.RootJoint
Larm = owner.Character.Torso["Left Shoulder"]
Rarm = owner.Character.Torso["Right Shoulder"]
Lleg = owner.Character.Torso["Left Hip"]
Rleg = owner.Character.Torso["Right Hip"]

owner.Character.HumanoidRootPart.Anchored = true

local sin = 1
for i = 1,10 do
Head.C0 = CFrame.new(math.random(-5,5),math.random(-5,5),math.random(-5,5))
Torso.C0 = CFrame.new(math.random(-5,5),math.random(-5,5),math.random(-5,5))
Larm.C0 = CFrame.new(math.random(-5,5),math.random(-5,5),math.random(-5,5))
Rarm.C0 = CFrame.new(math.random(-5,5),math.random(-5,5),math.random(-5,5))
Lleg.C0 = CFrame.new(math.random(-5,5),math.random(-5,5),math.random(-5,5))
Rleg.C0 = CFrame.new(math.random(-5,5),math.random(-5,5),math.random(-5,5))
wait()
end
local limbs = {} 

for i,v in pairs(owner.Character.OWO.Value.SUS:GetChildren()) do
if v:IsA("BasePart") then
table.insert(limbs, v)

local force1 = Instance.new("BodyPosition", v)
force1.MaxForce = Vector3.new(math.huge,math.huge,math.huge)
force1.P = 150000
force1.D = 1000

local force2 = Instance.new("BodyGyro", v)
force2.MaxTorque = Vector3.new(math.huge,math.huge,math.huge)
force2.P = 150000
force2.D = 1000
end
end
game:GetService("RunService").RenderStepped:Connect(function()
for i,v in pairs(limbs) do
if v.Name == 'Head' then
local CF = owner.Character:FindFirstChild(v.Name).CFrame * CFrame.Angles(0,math.rad(180),0)
v.BodyPosition.Position = CF.Position
v.BodyGyro.CFrame = CF

else
local CF = owner.Character:FindFirstChild(v.Name).CFrame * CFrame.Angles(0,0,0)
v.BodyPosition.Position = CF.Position
v.BodyGyro.CFrame = CF
end
end
end)
wait(.5)

game:GetService("RunService").Heartbeat:Connect(function()
sin = sin + 1

if owner.Character.HumanoidRootPart.Velocity.Magnitude > 1 then
Torso.C0 = Torso.C0:Lerp(AnimDefaults.Torso * CFrame.Angles(math.rad(math.random(-25,25)),math.rad(math.random(-25,25)),math.rad(math.random(-25,25))), .1)
Lleg.C0 = Lleg.C0:Lerp(AnimDefaults.Lleg * CFrame.Angles(0,0,math.rad(math.sin(tick() * 5) * 30)) * CFrame.Angles(math.rad(math.random(-25,25)),math.rad(math.random(-25,25)),math.rad(math.random(-25,25))), .1)
Rleg.C0 = Rleg.C0:Lerp(AnimDefaults.Rleg * CFrame.Angles(0,0,math.rad(math.sin(tick() * 5) * 30)) * CFrame.Angles(math.rad(math.random(-25,25)),math.rad(math.random(-25,25)),math.rad(math.random(-25,25))), .1)
Rarm.C0 = Rarm.C0:Lerp(AnimDefaults.Rarm * CFrame.Angles(0,0,math.rad(-math.sin(tick() * 5) * 30)) * CFrame.Angles(math.rad(math.random(-25,25)),math.rad(math.random(-25,25)),math.rad(math.random(-25,25))), .1)
Larm.C0 = Larm.C0:Lerp(AnimDefaults.Larm * CFrame.Angles(0,0,math.rad(-math.sin(tick() * 5) * 30)) * CFrame.Angles(math.rad(math.random(-25,25)),math.rad(math.random(-25,25)),math.rad(math.random(-25,25))), .1)
Head.C0 = Head.C0:Lerp(AnimDefaults.Head * CFrame.Angles(math.rad(math.random(-25,25)),math.rad(math.random(-25,25)),math.rad(math.random(-25,25))), .1)
elseif owner.Character.HumanoidRootPart.Velocity.Magnitude < 1 then
Lleg.C0 = Lleg.C0:Lerp(AnimDefaults.Lleg * CFrame.new(0,math.sin(tick()) / 8 ,0) * CFrame.Angles(math.rad(-0.057), 0, math.rad(15.011)) * CFrame.Angles(math.rad(math.random(-25,25)),math.rad(math.random(-25,25)),math.rad(math.random(-25,25))), .1)
Rleg.C0 = Rleg.C0:Lerp(AnimDefaults.Rleg * CFrame.new(1, 0 + math.sin(tick()) / 8, 0) * CFrame.Angles(0, 0, math.rad(-30.023)) * CFrame.Angles(math.rad(math.random(-25,25)),math.rad(math.random(-25,25)),math.rad(math.random(-25,25))), .1)
Rarm.C0 = Rarm.C0:Lerp(AnimDefaults.Rarm * CFrame.new(0, math.sin(tick()) / 4, 0.3) * CFrame.Angles(0, math.rad(44.977), math.rad(165.012)) * CFrame.Angles(math.rad(math.random(-25,25)),math.rad(math.random(-25,25)),math.rad(math.random(-25,25))), .2)
Larm.C0 = Larm.C0:Lerp(AnimDefaults.Larm * CFrame.new(0,math.sin(tick()) / 4,0) * CFrame.Angles(math.rad(-15.011), 0, 0) * CFrame.Angles(math.rad(math.random(-25,25)),math.rad(math.random(-25,25)),math.rad(math.random(-25,25))), .2)
Head.C0 = Head.C0:Lerp(AnimDefaults.Head * CFrame.Angles(0, 0, math.rad(0)) * CFrame.Angles(math.rad(math.random(-25,25)),math.rad(math.random(-25,25)),math.rad(math.random(-25,25))), .1)
Torso.C0 = Torso.C0:Lerp(AnimDefaults.Torso * CFrame.new(0, 0, 2 + math.sin(tick()) / 4) * CFrame.Angles(math.rad(math.random(-25,25)),math.rad(math.random(-25,25)),math.rad(math.random(-25,25))), .1)
end
end)

wait(.25)
owner.Character.HumanoidRootPart.Anchored = false

]], owner.PlayerGui)

game:GetService("RunService").Heartbeat:Connect(function()
local effect = effects[math.random(1,#effects)]
effect.Transparency = 0
effect.Parent = script
effect.CFrame = hum.CFrame * CFrame.new(math.random(-5,5),math.random(-5,5),math.random(-5,5)) * CFrame.Angles(math.random(-5,5),math.random(-5,5),math.random(-5,5))

game:GetService("TweenService"):Create(effect, TweenInfo.new(.25), {CFrame = hum.CFrame, Transparency = 1}):Play()
for i,v in pairs(E:GetChildren()) do
if v:IsA("BasePart") then
v:SetNetworkOwner(owner)
end
end

wait(.25)
effect.Parent = nil
end)